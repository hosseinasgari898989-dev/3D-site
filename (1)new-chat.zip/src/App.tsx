import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion, useScroll, useSpring } from "framer-motion";
import { ArrowUp } from "lucide-react";
import Nav from "@/components/Nav";
import SourceModal from "@/components/SourceModal";
import Hero from "@/sections/Hero";
import Formula from "@/sections/Formula";
import Architecture from "@/sections/Architecture";
import Prompts from "@/sections/Prompts";
import Playground from "@/sections/Playground";
import Bugs from "@/sections/Bugs";
import Audit from "@/sections/Audit";
import ScrollTheatre from "@/sections/ScrollTheatre";
import Closing from "@/sections/Closing";

/* ════════════════════════════════════════════════════════════════════════════
   THE 3D FORMULA · App.tsx
   ترکیبِ بخش‌ها + سه سرویسِ سراسری: نورِ ماوس، نویزِ چاپی، میان‌بُرِ «پشتِ کد».
   هر سه با cleanup کامل (قانون §۰۹) و هر سه reduced-motion-safe (§۰۸).
   ════════════════════════════════════════════════════════════════════════════ */

/** نورِ نرمی که ماوس را دنبال می‌کند — فقط transform، بدون re-render */
function PointerLight() {
  const el = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const fine = window.matchMedia("(hover: hover) and (pointer: fine)");
    if (!fine.matches) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    let raf = 0;
    let x = window.innerWidth * 0.7;
    let y = window.innerHeight * 0.3;
    let tx = x;
    let ty = y;
    const loop = () => {
      x += (tx - x) * 0.09;
      y += (ty - y) * 0.09;
      if (el.current) el.current.style.transform = `translate3d(${x - 260}px, ${y - 260}px, 0)`;
      raf = requestAnimationFrame(loop);
    };
    const on = (e: PointerEvent) => {
      tx = e.clientX;
      ty = e.clientY;
    };
    window.addEventListener("pointermove", on, { passive: true });
    raf = requestAnimationFrame(loop);
    return () => {
      window.removeEventListener("pointermove", on);
      cancelAnimationFrame(raf);
    };
  }, []);
  return (
    <div
      ref={el}
      aria-hidden
      className="pointer-events-none fixed left-0 top-0 z-[45] hidden h-[520px] w-[520px] rounded-full opacity-45 mix-blend-screen will-change-transform lg:block"
      style={{ background: "radial-gradient(circle, rgba(53,208,160,.14), rgba(255,179,71,.07) 42%, transparent 68%)" }}
    />
  );
}

function ToTop() {
  const { scrollYProgress } = useScroll();
  const ring = useSpring(scrollYProgress, { stiffness: 90, damping: 22, mass: 0.4 });
  const [show, setShow] = useState(false);
  useEffect(() => {
    let raf = 0;
    const on = () => {
      if (raf) return;
      raf = requestAnimationFrame(() => {
        raf = 0;
        setShow(window.scrollY > window.innerHeight * 0.9);
      });
    };
    on();
    window.addEventListener("scroll", on, { passive: true });
    return () => {
      window.removeEventListener("scroll", on);
      if (raf) cancelAnimationFrame(raf);
    };
  }, []);

  return (
    <AnimatePresence>
      {show && (
        <motion.button
          initial={{ opacity: 0, y: 18, rotateX: -35 }}
          animate={{ opacity: 1, y: 0, rotateX: 0 }}
          exit={{ opacity: 0, y: 18, rotateX: -35 }}
          transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
          style={{ transformPerspective: 800 }}
          onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
          className="fixed bottom-4 left-4 z-[52] grid h-12 w-12 place-items-center rounded-full border border-mist/18 bg-ink/75 text-sand backdrop-blur-md transition-colors duration-300 hover:border-amber/55 hover:text-amber md:bottom-6 md:left-6"
          aria-label="بازگشت به بالا"
        >
          <svg viewBox="0 0 44 44" className="absolute inset-0 h-full w-full -rotate-90">
            <motion.circle
              cx="22"
              cy="22"
              r="20"
              fill="none"
              stroke="#ffb347"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeDasharray={2 * Math.PI * 20}
              style={{ pathLength: ring }}
              opacity={0.85}
            />
          </svg>
          <ArrowUp size={16} />
        </motion.button>
      )}
    </AnimatePresence>
  );
}

export default function App() {
  const [source, setSource] = useState(false);

  // حذفِ لودرِ پیشِ بوت، بعد از اولین قابِ واقعی (قانون §۰۳: هیچ‌وقت صفحه‌ی سفید نه)
  useEffect(() => {
    let outer = 0;
    const inner = requestAnimationFrame(() => {
      outer = window.setTimeout(() => {
        const boot = document.getElementById("boot");
        if (!boot) return;
        boot.style.transition = "opacity .5s ease";
        boot.style.opacity = "0";
        window.setTimeout(() => boot.remove(), 520);
      }, 120);
    });
    return () => {
      cancelAnimationFrame(inner);
      window.clearTimeout(outer);
    };
  }, []);

  // میان‌بُر: Ctrl+Shift+0  یا  کلید 0  → «پشتِ کد»
  useEffect(() => {
    const on = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement | null;
      if (t && /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName)) return;
      if (e.key === "0" && (e.ctrlKey || e.metaKey) && e.shiftKey) {
        e.preventDefault();
        setSource((v) => !v);
      } else if (e.key.toLowerCase() === "k" && !e.ctrlKey && !e.metaKey) {
        setSource((v) => !v);
      } else if (e.key === "Escape") setSource(false);
    };
    window.addEventListener("keydown", on);
    return () => window.removeEventListener("keydown", on);
  }, []);

  return (
    <div className="relative min-h-screen">
      <div className="noise-layer" aria-hidden />
      <PointerLight />
      <Nav onOpenSource={() => setSource(true)} />

      <main>
        <Hero />
        <Formula />
        <Architecture />
        <Prompts />
        <Playground />
        <Bugs />
        <Audit />
        <ScrollTheatre />
      </main>

      <Closing onOpenSource={() => setSource(true)} />
      <SourceModal open={source} onClose={() => setSource(false)} />
      <ToTop />

      <span className="sr-only">
        BUGFREE_3D = (SCENE × DEPTH) + (SCROLL × MOTION) + (RULES ÷ COMPLEXITY) — ده قانون: موتور سه‌لایه، عمقِ CSS،
        بوتِ امنِ WebGL، متریالِ fresnel، حرکتِ زمان‌محور، اسکرولِ دوربین‌محور، بودجه‌ی کارایی، موبایل و RTL،
        پاک‌سازیِ effect، تحویلِ با شواهد.
      </span>
    </div>
  );
}
