import { useEffect, useState } from "react";
import { AnimatePresence, motion, useScroll, useSpring } from "framer-motion";
import { Boxes, Code2, Menu, Sparkle, X } from "lucide-react";
import { cn } from "@/utils/cn";

const LINKS = [
  { id: "formula", label: "فرمول", en: "FORMULA" },
  { id: "engine", label: "معماری", en: "ARCHITECTURE" },
  { id: "playground", label: "پلی‌گراند", en: "PLAYGROUND" },
  { id: "prompts", label: "پرامپت‌ها", en: "PROMPTS" },
  { id: "bugs", label: "ضد‌الگوها", en: "BUGS" },
  { id: "audit", label: "ممیزی", en: "AUDIT" },
  { id: "theatre", label: "تئاترِ اسکرول", en: "SCROLL" },
  { id: "faq", label: "پرسش‌ها", en: "FAQ" },
];

export default function Nav({ onOpenSource }: { onOpenSource: () => void }) {
  const { scrollYProgress } = useScroll();
  const bar = useSpring(scrollYProgress, { stiffness: 120, damping: 24, mass: 0.3 });
  const [solid, setSolid] = useState(false);
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState("formula");

  useEffect(() => {
    const onScroll = () => setSolid(window.scrollY > 40);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const els = LINKS.map((l) => document.getElementById(l.id)).filter(Boolean) as HTMLElement[];
    if (!els.length || typeof IntersectionObserver === "undefined") return;
    const io = new IntersectionObserver(
      (entries) => {
        const vis = entries
          .filter((e) => e.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (vis) setActive(vis.target.id);
      },
      { rootMargin: "-45% 0px -50% 0px", threshold: [0.01, 0.3, 0.6] }
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []);

  const go = (id: string) => {
    setOpen(false);
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <>
      <header
        className={cn(
          "fixed inset-x-0 top-0 z-50 transition-all duration-500",
          solid ? "border-b border-mist/10 bg-ink/72 backdrop-blur-xl" : "border-b border-transparent"
        )}
      >
        <div className="mx-auto flex h-16 w-full max-w-[1400px] items-center justify-between gap-4 px-4 md:h-[70px] lg:px-8">
          {/* brand */}
          <button onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })} className="group flex items-center gap-3">
            <span className="relative grid h-10 w-10 place-items-center rounded-xl border border-jade/35 bg-jade/10 transition-transform duration-500 group-hover:[transform:rotateY(180deg)] [transform-style:preserve-3d]">
              <Boxes size={17} className="text-jade" />
            </span>
            <span className="text-start leading-none">
              <span className="block text-[15px] font-black tracking-tight text-sand">فرمولِ سه‌بعدی</span>
              <span className="block font-mono text-[9.5px] tracking-[0.26em] text-mist/50">3D FORMULA · v4</span>
            </span>
          </button>

          {/* desktop links */}
          <nav className="hidden items-center gap-0.5 lg:flex">
            {LINKS.map((l) => (
              <button
                key={l.id}
                onClick={() => go(l.id)}
                className={cn(
                  "relative rounded-lg px-3.5 py-2 text-[13.5px] font-medium transition-colors duration-300",
                  active === l.id ? "text-sand" : "text-mist/65 hover:text-sand"
                )}
              >
                {l.label}
                {active === l.id && (
                  <motion.span
                    layoutId="navdot"
                    className="absolute inset-x-2 -bottom-0.5 h-px bg-linear-to-r from-transparent via-amber to-transparent"
                  />
                )}
              </button>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <button
              onClick={onOpenSource}
              className="hidden items-center gap-2 rounded-xl border border-mist/15 px-3 py-2 font-mono text-[11px] text-mist/75 transition-all duration-300 hover:border-amber/50 hover:text-amber md:flex"
              title="فرمولِ پشتِ کد را ببین — Ctrl+Shift+0"
            >
              <Code2 size={13} /> پشتِ کد
            </button>
            <button
              onClick={() => go("prompts")}
              className="relative hidden overflow-hidden rounded-xl bg-amber px-4 py-2 text-[13px] font-bold text-ink transition-transform duration-300 hover:scale-[1.04] active:scale-95 sm:block"
            >
              <span className="relative z-10">کپیِ پرامپت مادر</span>
              <span className="absolute inset-0 -translate-x-full bg-linear-to-r from-transparent via-white/45 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
            </button>
            <button
              onClick={() => setOpen((v) => !v)}
              className="grid h-10 w-10 place-items-center rounded-xl border border-mist/15 text-sand transition-colors hover:border-jade/45 hover:text-jade lg:hidden"
              aria-label="منو"
              aria-expanded={open}
            >
              {open ? <X size={18} /> : <Menu size={18} />}
            </button>
          </div>
        </div>
        {/* scroll progress = camera driver (قانون §۰۶) */}
        <div className="relative h-[2px] w-full bg-mist/5">
          <motion.div
            style={{ scaleX: bar }}
            className="h-full origin-right bg-linear-to-l from-jade via-sky to-amber"
          />
        </div>
      </header>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[55] lg:hidden"
          >
            <div className="absolute inset-0 bg-abyss/85 backdrop-blur-md" onClick={() => setOpen(false)} />
            <motion.nav
              initial={{ rotateX: -18, y: -18, opacity: 0 }}
              animate={{ rotateX: 0, y: 0, opacity: 1 }}
              exit={{ rotateX: -18, y: -18, opacity: 0 }}
              transition={{ duration: 0.42, ease: [0.16, 1, 0.3, 1] }}
              style={{ transformPerspective: 1200 }}
              className="panel absolute inset-x-3 top-[76px] rounded-3xl p-3 shadow-glow"
            >
              {LINKS.map((l, i) => (
                <motion.button
                  key={l.id}
                  initial={{ x: 24, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ delay: 0.05 + i * 0.045 }}
                  onClick={() => go(l.id)}
                  className="flex w-full items-center justify-between rounded-2xl px-4 py-3.5 text-start transition-colors hover:bg-jade/10"
                >
                  <span className="text-[15px] font-bold text-sand">{l.label}</span>
                  <span className="font-mono text-[10px] tracking-[0.22em] text-mist/45">{l.en}</span>
                </motion.button>
              ))}
              <button
                onClick={() => {
                  setOpen(false);
                  onOpenSource();
                }}
                className="mt-2 flex w-full items-center justify-center gap-2 rounded-2xl bg-amber/90 px-4 py-3 text-[14px] font-bold text-ink"
              >
                <Sparkle size={14} /> فرمولِ پشتِ کد
              </button>
            </motion.nav>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}

export { LINKS };
