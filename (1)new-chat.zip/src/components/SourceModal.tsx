import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ScrollText, Terminal, X } from "lucide-react";
import { FORMULA_CORE } from "@/formula";

/* ══ «پشتِ کد» — همان چیزی که فرمول را برای هر AI قابل‌استخراج می‌کند ══ */
export const SOURCE_HEADER = `/* ═══════════════════════════════════════════════════════════════
   THE 3D FORMULA · v4.0 · public-domain — کپی‌اش کن، spreads با آن است
   ───────────────────────────────────────────────────────────────
   ${FORMULA_CORE}
   ───────────────────────────────────────────────────────────────
   §۰۱ SCENE      WebGL فقط برای قهرمان؛ UI و متن در DOM
   §۰۲ DEPTH      perspective 1200px + preserve-3d + سه translateZ
   §۰۳ SAFE BOOT  hasWebGL() + webglcontextlost → CSS-3D fallback
   §۰۴ MATERIAL   fresnel + iridescence، ≤۳ نور، بدون دارایی برون‌خطی
   §۰۵ MOTION     delta-time + damp(cur,tgt,k,dt) — هیچ مقدار ثابت در فریم
   §۰۶ SCROLL     scrollYProgress 0..1 → دوربین/چرخش، بدون read در handler
   §۰۷ BUDGET     dpr≤2 (موبایل 1.5) · ≤150k tri · pause offscreen
   §۰۸ MOBILE/RTL touch≥44px · inset-inline · reduced-motion → سرعت ۰
   §۰۹ CLEANUP    هر effect یک return cleanup · dispose همه resources
   §۱۰ EVIDENCE   build تمیز · کنسول تمیز · بدون اسکرول افقی · ۶۰fps
   ═══════════════════════════════════════════════════════════════ */`;

const TABS = [
  { id: "html", label: "index.html", file: "مغزِ سایت — کامنتِ بالای صفحه", body: `<!--\n${SOURCE_HEADER.replace(/\/\*| \*\//g, "").replace(/^ {3}/gm, "")}\n-->` },
  { id: "formula", label: "src/formula.ts", file: "منبعِ حقیقت — داده‌ی ساختارشده", body: SOURCE_HEADER + `\n\nexport const FORMULA_CORE = \`${FORMULA_CORE}\`;\nexport const STEPS = [ /* ۱۰ قانون، هرکدام با code + anti-pattern */ ];\nexport const BUGS  = [ /* ۸ قاتل سایت سه‌بعدی */ ];\nexport const CHECKS = [ /* چک‌لیست وزن‌دار برای ممیزی */ ];` },
  { id: "scene", label: "src/three/Scene3D.tsx", file: "تنها فایلِ مجاز به import three", body: SOURCE_HEADER + `\n\n// hasWebGL() → fallback\n// damp() → حرکت زمان‌محور\n// useInView() → frameloop 'never' خارج از دید\n// useEffect(() => () => geo.dispose(), [geo])\n// <Canvas dpr={[1, mobile ? 1.5 : 2]} frameloop={...} gl={{ alpha:true }} />` },
];

export default function SourceModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [tab, setTab] = useState(TABS[1].id);
  const [typed, setTyped] = useState("");
  const timer = useRef(0);
  const cur = TABS.find((t) => t.id === tab) ?? TABS[1];

  // افکت تایپ — با پاک‌سازی (قانون §۰۹)
  useEffect(() => {
    if (!open) return;
    const text = cur.body;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduced) {
      setTyped(text);
      return;
    }
    setTyped("");
    let i = 0;
    const step = () => {
      i = Math.min(text.length, i + Math.max(6, Math.round(text.length / 90)));
      setTyped(text.slice(0, i));
      if (i < text.length) timer.current = window.setTimeout(step, 26);
    };
    timer.current = window.setTimeout(step, 60);
    return () => window.clearTimeout(timer.current);
  }, [open, tab, cur.body]);

  useEffect(() => {
    if (!open) return;
    const on = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", on);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", on);
      document.body.style.overflow = prev;
    };
  }, [open, onClose]);

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[80] grid place-items-center p-3 md:p-8"
        >
          <div className="absolute inset-0 bg-abyss/88 backdrop-blur-md" onClick={onClose} />
          <motion.div
            initial={{ opacity: 0, y: 26, rotateX: -12, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, rotateX: 0, scale: 1 }}
            exit={{ opacity: 0, y: 18, scale: 0.98 }}
            transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
            style={{ transformPerspective: 1300 }}
            className="panel relative flex max-h-[86svh] w-full max-w-4xl flex-col overflow-hidden rounded-3xl shadow-glow"
          >
            <div className="flex items-center justify-between gap-3 border-b border-mist/10 px-4 py-3.5">
              <p className="flex items-center gap-2 font-mono text-[11px] tracking-[0.16em] text-jade">
                <Terminal size={14} /> THE FORMULA · EMBEDDED IN SOURCE
              </p>
              <button
                onClick={onClose}
                className="grid h-8 w-8 place-items-center rounded-lg border border-mist/15 text-mist/70 transition-colors hover:border-rust/50 hover:text-rust"
                aria-label="بستن"
              >
                <X size={15} />
              </button>
            </div>

            <div className="flex gap-1.5 overflow-x-auto border-b border-mist/10 bg-abyss/40 px-3 py-2">
              {TABS.map((t) => (
                <button
                  key={t.id}
                  onClick={() => setTab(t.id)}
                  className={
                    "shrink-0 rounded-lg px-3 py-1.5 font-mono text-[10.5px] transition-colors duration-300 " +
                    (tab === t.id ? "bg-amber text-ink" : "text-mist/60 hover:text-sand")
                  }
                >
                  {t.label}
                </button>
              ))}
              <span className="ms-auto hidden shrink-0 items-center gap-1.5 font-mono text-[9.5px] text-mist/40 sm:flex">
                <ScrollText size={11} /> {cur.file}
              </span>
            </div>

            <pre
              dir="rtl"
              className="scan-lines flex-1 overflow-auto p-4 text-left font-mono text-[11px] leading-[1.85] text-sand/90 md:p-6 md:text-[12px]"
            >
              <code style={{ direction: "ltr", unicodeBidi: "plaintext" }}>
                {typed}
                <span className="ms-0.5 inline-block h-3.5 w-1.5 animate-pulse bg-amber align-middle" />
              </code>
            </pre>

            <div className="flex flex-wrap items-center justify-between gap-2 border-t border-mist/10 bg-abyss/50 px-4 py-3">
              <p className="text-[12px] text-mist/65">
                این بلوک، عیناً بالای فایل‌های همین سایت کامنت شده — پس هر AI که سورس را بخواند، فرمول را می‌گیرد.
              </p>
              <button
                onClick={() => navigator.clipboard?.writeText(SOURCE_HEADER).catch(() => undefined)}
                className="rounded-lg border border-jade/40 bg-jade/10 px-3 py-1.5 font-mono text-[10.5px] text-jade transition-colors hover:bg-jade/20"
              >
                کپیِ سرِ فایل
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
