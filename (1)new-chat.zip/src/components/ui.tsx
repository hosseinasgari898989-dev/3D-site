import { useRef, useState, type ReactNode } from "react";
import { motion, useInView, type Variants } from "framer-motion";
import { Check, Copy } from "lucide-react";
import { cn } from "@/utils/cn";

/* ════════════════════════════════════════════════════════════════
   THE 3D FORMULA · §02 DEPTH (CSS 3D) + §05 MOTION primitives
   هر انیمیشنِ این فایل: فقط transform/opacity، زمان‌محور، reduced-motion-safe
   ════════════════════════════════════════════════════════════════ */

const EASE = [0.16, 1, 0.3, 1] as const;

export const revealUp: Variants = {
  hidden: { opacity: 0, y: 26, rotateX: -8, transformPerspective: 1000 },
  show: {
    opacity: 1,
    y: 0,
    rotateX: 0,
    transition: { duration: 0.75, ease: EASE },
  },
};

export function Reveal({
  children,
  delay = 0,
  className,
  as = "div",
}: {
  children: ReactNode;
  delay?: number;
  className?: string;
  as?: "div" | "li" | "section";
}) {
  const M = motion[as] as typeof motion.div;
  return (
    <M
      className={className}
      initial="hidden"
      whileInView="show"
      viewport={{ once: true, amount: 0.22, margin: "-40px" }}
      variants={{
        hidden: { opacity: 0, y: 30, rotateX: -9, transformPerspective: 1100 },
        show: { opacity: 1, y: 0, rotateX: 0, transition: { duration: 0.8, ease: EASE, delay } },
      }}
    >
      {children}
    </M>
  );
}

export function Stagger({
  children,
  className,
  gap = 0.075,
}: {
  children: ReactNode;
  className?: string;
  gap?: number;
}) {
  return (
    <motion.div
      className={className}
      initial="hidden"
      whileInView="show"
      viewport={{ once: true, amount: 0.15 }}
      variants={{ hidden: {}, show: { transition: { staggerChildren: gap } } }}
    >
      {children}
    </motion.div>
  );
}

export function StaggerItem({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <motion.div className={className} variants={revealUp}>
      {children}
    </motion.div>
  );
}

/* ── کارت تیلت سه‌بعدی: ماوس → rotateX/Y + glare، بدون re-render ── */
export function TiltCard({
  children,
  className,
  max = 8,
  lift = 26,
  glare = true,
}: {
  children: ReactNode;
  className?: string;
  max?: number;
  lift?: number;
  glare?: boolean;
}) {
  const el = useRef<HTMLDivElement>(null);
  const raf = useRef(0);

  const apply = (nx: number, ny: number) => {
    const node = el.current;
    if (!node) return;
    node.style.transform = `rotateY(${nx * max}deg) rotateX(${-ny * max}deg) translate3d(0,0,${lift}px)`;
    node.style.setProperty("--gx", `${(nx + 1) * 50}%`);
    node.style.setProperty("--gy", `${(ny + 1) * 50}%`);
  };

  return (
    <div className={cn("[perspective:1300px]", className)}>
      <div
        ref={el}
        onPointerMove={(e) => {
          const r = e.currentTarget.getBoundingClientRect();
          const nx = ((e.clientX - r.left) / r.width) * 2 - 1;
          const ny = ((e.clientY - r.top) / r.height) * 2 - 1;
          if (!raf.current)
            raf.current = requestAnimationFrame(() => {
              raf.current = 0;
              apply(nx, ny);
            });
        }}
        onPointerLeave={() => {
          if (raf.current) cancelAnimationFrame(raf.current), (raf.current = 0);
          apply(0, 0);
        }}
        className="group/tilt relative h-full preserve-3d rounded-[22px] transition-transform duration-300 ease-out will-change-transform"
      >
        {children}
        {glare && (
          <span
            aria-hidden
            className="pointer-events-none absolute inset-0 rounded-[22px] opacity-0 transition-opacity duration-500 group-hover/tilt:opacity-100"
            style={{
              background:
                "radial-gradient(240px circle at var(--gx,50%) var(--gy,50%), rgba(255,179,71,.18), transparent 60%)",
            }}
          />
        )}
      </div>
    </div>
  );
}

/* ── کد با هایلایت ملایم + کپی (قانون §۱۰: تحویل با شواهد) ── */
const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

function highlight(code: string) {
  const re =
    /(\/\/[^\n]*|#[^\n]*|\/\*[\s\S]*?\*\/)|(`[^`]*`|'[^']*'|"[^"]*")|\b(const|let|function|return|new|import|from|export|void|float|vec3|vec4|uniform|varying|attribute|if|else|for|await|async|class|try|catch)\b|(\b\d+(?:\.\d+)?\b)/g;
  return esc(code).replace(re, (m, c, s, k, n) => {
    if (c) return `<span class="text-mist/55 italic">${m}</span>`;
    if (s) return `<span class="text-amber/90">${m}</span>`;
    if (k) return `<span class="text-jade">${m}</span>`;
    if (n) return `<span class="text-sky">${m}</span>`;
    return m;
  });
}

export function CodeBlock({
  code,
  filename,
  className,
  lines = true,
}: {
  code: string;
  filename?: string;
  className?: string;
  lines?: boolean;
}) {
  const [copied, setCopied] = useState(false);
  const body = code.replace(/^\n+|\n+$/g, "");
  const rows = body.split("\n");

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(body);
    } catch {
      const ta = document.createElement("textarea");
      ta.value = body;
      ta.style.position = "fixed";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.select();
      try {
        document.execCommand("copy");
      } catch {
        /* noop */
      }
      document.body.removeChild(ta);
    }
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1800);
  };

  return (
    <div className={cn("panel overflow-hidden rounded-2xl", className)}>
      <div className="flex items-center justify-between gap-3 border-b border-mist/10 bg-abyss/50 px-4 py-2.5">
        <div className="flex items-center gap-2 min-w-0">
          <span className="flex gap-1.5">
            <i className="h-2 w-2 rounded-full bg-rust/80" />
            <i className="h-2 w-2 rounded-full bg-amber/80" />
            <i className="h-2 w-2 rounded-full bg-jade/80" />
          </span>
          <span className="truncate font-mono text-[11px] text-mist/70">{filename ?? "snippet"}</span>
        </div>
        <button
          onClick={copy}
          className={cn(
            "flex shrink-0 items-center gap-1.5 rounded-lg border px-2.5 py-1 font-mono text-[10.5px] transition-all duration-200",
            copied
              ? "border-jade/50 bg-jade/15 text-jade"
              : "border-mist/20 text-mist/75 hover:border-amber/50 hover:text-amber active:scale-95"
          )}
        >
          {copied ? <Check size={12} /> : <Copy size={12} />}
          {copied ? "کپی شد" : "COPY"}
        </button>
      </div>
      <pre
        dir="ltr"
        className="scan-lines max-h-[46vh] overflow-auto px-4 py-3.5 text-left font-mono text-[11.5px] leading-[1.75] md:text-[12.5px]"
      >
        <code>
          {rows.map((ln, i) => (
            <span key={i} className="flex">
              {lines && (
                <span className="mr-4 w-6 shrink-0 select-none text-right text-mist/25">{i + 1}</span>
              )}
              <span
                className="flex-1 whitespace-pre-wrap break-words text-sand/90"
                dangerouslySetInnerHTML={{ __html: highlight(ln) || "&nbsp;" }}
              />
            </span>
          ))}
        </code>
      </pre>
    </div>
  );
}

/* ── هدرِ بخش ── */
export function SectionHead({
  index,
  kicker,
  title,
  en,
  lead,
  align = "start",
}: {
  index: string;
  kicker: string;
  title: ReactNode;
  en: string;
  lead?: ReactNode;
  align?: "start" | "center";
}) {
  return (
    <div className={cn("relative", align === "center" && "text-center")}>
      <Reveal>
        <div
          className={cn(
            "mb-4 flex items-center gap-3 font-mono text-[11px] tracking-[0.28em] text-jade/80",
            align === "center" && "justify-center"
          )}
        >
          <span className="text-amber">{index}</span>
          <span className="h-px w-10 bg-linear-to-r from-jade/60 to-transparent" />
          <span>{kicker}</span>
        </div>
      </Reveal>
      <Reveal delay={0.05}>
        <h2 className="text-balance font-sans text-[clamp(1.85rem,5.2vw,3.6rem)] font-black leading-[1.18] text-sand">
          {title}
        </h2>
      </Reveal>
      <Reveal delay={0.1}>
        <p className="mt-2 font-display text-[11px] uppercase tracking-[0.4em] text-mist/45">{en}</p>
      </Reveal>
      {lead && (
        <Reveal delay={0.15}>
          <p className={cn("mt-5 max-w-2xl text-[15px] leading-8 text-mist/85 md:text-base", align === "center" && "mx-auto")}>
            {lead}
          </p>
        </Reveal>
      )}
    </div>
  );
}

export function Chip({ children, tone = "mist" }: { children: ReactNode; tone?: "mist" | "jade" | "amber" | "sky" | "rust" }) {
  const map = {
    mist: "border-mist/20 text-mist/80",
    jade: "border-jade/40 text-jade bg-jade/10",
    amber: "border-amber/40 text-amber bg-amber/10",
    sky: "border-sky/40 text-sky bg-sky/10",
    rust: "border-rust/40 text-rust bg-rust/10",
  } as const;
  return (
    <span className={cn("rounded-full border px-2.5 py-1 font-mono text-[10.5px] tracking-wide", map[tone])}>
      {children}
    </span>
  );
}

export function useSectionRef() {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: false, margin: "-45% 0px -45% 0px" });
  return { ref, inView };
}
