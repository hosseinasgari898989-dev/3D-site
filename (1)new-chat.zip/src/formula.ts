/* ════════════════════════════════════════════════════════════════════════════
   THE 3D FORMULA — v4.0 — src/formula.ts
   ────────────────────────────────────────────────────────────────────────────
   این فایل، «منبع حقیقت» است. کل همین سایت از روی همین قوانین ساخته شده و
   هر هوش مصنوعی دیگری که این فایل (или «پرامپت مادر» پایین‌تر) را بخواند،
   باید دقیقاً همین خروجی را بسازد: سایت سه‌بعدی، بدون باگ، روی موبایل و دسکتاپ.

   BUGFREE_3D = ( SCENE × DEPTH ) + ( SCROLL × MOTION ) + ( RULES / COMPLEXITY )
   ════════════════════════════════════════════════════════════════════════════ */

export const FORMULA_CORE = `BUGFREE_3D = ( SCENE × DEPTH ) + ( SCROLL × MOTION ) + ( RULES ÷ COMPLEXITY )`;

export const FORMULA_LINES = [
  { key: "SCENE", fa: "یک بوم WebGL، کم‌هندسه، با تشخیص توان دستگاه و fallback" },
  { key: "DEPTH", fa: "سه لایه‌ی عمقِ واقعی: پس‌زمینه / میان‌بومی / نمایان — هر کدام با translateZ" },
  { key: "SCROLL", fa: "اسکرول = پیش‌برِ دوربین؛ یک عددِ ۰ تا ۱، بدون خواندن layout در هر فریم" },
  { key: "MOTION", fa: "زمان‌محور: clock.getDelta() + میرایی (damping) — نه tween بی‌پایان" },
  { key: "RULES", fa: "پاک‌سازی effect، dispose، clamp dpr، توقف رندر بیرون از دید، context-loss" },
  { key: "COMPLEXITY", fa: "مخرجِ کسر: هر فیچر اضافه، سه باگ جدید است. کم بساز، درست بساز" },
] as const;

export type Step = {
  n: string;
  title: string;
  en: string;
  body: string;
  code: string;
  fails: string;
};

export const STEPS: Step[] = [
  {
    n: "۰۱",
    title: "موتور را انتخاب کن — سه‌لایه",
    en: "ENGINE SELECTION",
    body:
      "هیچ‌وقت کل سایت را WebGL نکنید. فرمول سه‌لایه: (۱) WebGL/Three فقط برای قهرمان و اشیاء واقعی سه‌بعدی، (۲) CSS 3D برای چیدمان، کارت‌ها و ترنزیشن‌ها — رایگان، در دسترس، سئو‌پسند، (۳) Canvas2D یا SVG برای ذرات تزئینی. این تنها راهی است که هم «خفن» است هم «بدون باگ».",
    code: `// لایه‌بندیِ صحیح
<Canvas>        {/* WebGL: فقط قهرمان + بازی */}
<div layer-3d>  {/* CSS 3D: کارت، تایلمارک، اسکرول */}
<svg|canvas2d>  {/* تزئین: ذرات، خطوط، نویز */}`,
    fails: "باگِ مرگبار: منوی سایت را داخل صحنه‌ی three.js ساختن → غیرقابل‌کلیک، غیرقابل‌اسکرول، غیرقابل‌دسترسی.",
  },
  {
    n: "۰۲",
    title: "عمق را در DOM بساز، نه در توهم",
    en: "DEPTH REAL",
    body:
      "یک container با perspective: 1200px و بچه‌ها با transform-style: preserve-3d + translateZ. سه سطح: پس‌زمینه (translateZ(-240px))، میان‌بومی (۰)، نمایان (+۹۰px). چون پرسپکتیو واقعی است، با حرکت ماوس paralllax بدون یک خط ریاضی اتفاق می‌افتد.",
    code: `.stage { perspective: 1200px; perspective-origin: 50% 45%; }
.layer { transform-style: preserve-3d; will-change: transform; }
.layer--back  { transform: translateZ(-240px) scale(1.2); }
.layer--front { transform: translateZ(90px); }`,
    fails: "باگِ مرگبار: فراموشی preserve-3d روی والد → همه بچه‌ها «تخت» می‌شوند و هیچ عمقی نمی‌ماند.",
  },
  {
    n: "۰۳",
    title: " WebGL را امن شروع کن",
    en: "SAFE BOOT",
    body:
      "قبل از ساخت رندرر، capability را بسنج. اگر WebGL نبود، یا context از دست رفت، یک نسخه‌ی CSS-3D از همان صحنه نشان بده. هیچ‌وقت صفحه‌ی سفید نده. این قانون، ۹۰٪ «سایت سه‌بعدی من کار نمی‌کند»ها را حذف می‌کند.",
    code: `function hasWebGL() {
  try {
    const c = document.createElement('canvas');
    return !!(window.WebGLRenderingContext &&
      (c.getContext('webgl2') || c.getContext('webgl')));
  } catch { return false; }
}
renderer.domElement.addEventListener('webglcontextlost', (e) => {
  e.preventDefault(); setFallback(true);   // هرگز نمی‌میرد
});`,
    fails: "باگِ مرگبار: کرش روی آیفون/سافاری و iPad یا مرورگرهای با hardware acceleration خاموش.",
  },
  {
    n: "۰۴",
    title: "متریال ارزان، نور گران‌نخور",
    en: "MATERIAL & LIGHT",
    body:
      "بدون HDR خارجی و بدون Environment دانلودی: با Fresnel + iridescence در یک ShaderMaterialِ ۴۰ خطی، جنس «گران» بگیر. حداکثر ۳ نور. برای فلز، یک envMap از data-uri بساز (یا از MeshPhysicalMaterial با clearcoat). هیچ دارایی برون‌خطی = هیچ ۴۰۴ی = هیچ باگی.",
    code: `// fresnel: لبه‌ها روشن می‌شوند → حسِ شیشه/کریستال
float f = pow(1.0 - abs(dot(vN, V)), 3.2);
vec3 col = mix(baseColor, rimColor, f) + iridescence * 0.35;`,
    fails: "باگِ مرگبار: استفاده از HDR/تکسچر CDN که در build تک‌فایلی یا آفلاین ۴۰۴ می‌شود و صحنه سیاه می‌افتد.",
  },
  {
    n: "۰۵",
    title: "زمان‌محور باشد، نه فریم‌محور",
    en: "TIME-BASED MOTION",
    body:
      "در هر useFrame مقدار delta بگیر و با damping به سمت هدف برو: v += (target - v) * (1 - exp(-k * delta)). این کار روی دستگاه ۶۰Hz و ۱۲۰Hz و موبایلِ ۳۰fps یکسان به‌نظر می‌رسد و هرگز «سرعت دو برابر در iPad Pro» نمی‌دهد.",
    code: `const damp = (cur, tgt, k, dt) => cur + (tgt - cur) * (1 - Math.exp(-k * dt));
useFrame((s, dt) => {
  mesh.current.rotation.y = damp(mesh.current.rotation.y, pointer.x * 0.9, 4, dt);
  s.clock.getElapsedTime();
});`,
    fails: "باگِ مرگبار: rotation += 0.01 → روی نمایشگر ۱۲۰Hz سه برابر سریع‌تر می‌چرخد.",
  },
  {
    n: "۰۶",
    title: "اسکرول = دوربین",
    en: "SCROLL DRIVES CAMERA",
    body:
      "یک مقدار نرمال‌شده ۰ تا ۱ از اسکرول بگیر و به چرخش/مکان/فوکلس بده. هرگز داخل handler چیزی نخوان که layout بگیرد (offsetHeight…)؛ از IntersectionObserver یا مقدارِ از پیش اندازه‌گیری‌شده استفاده کن. در React: useScroll + useTransform از framer-motion.",
    code: `const { scrollYProgress } = useScroll();               // 0 → 1
const rotateX = useTransform(scrollYProgress, [0, 1], [0, 0.6]);
<motion.section style={{ rotateX, transformPerspective: 1100 }} />
// دوربین در three.js:
camera.position.z = 6 - scroll * 2.4;  // فقط write؛ هیچ read در این حلقه`,
    fails: "باگِ مرگبار: getBoundingClientRect در هر اسکرول‌ایونت → جانشینی (jank) و ۲۰fps روی موبایل.",
  },
  {
    n: "۰۷",
    title: "بودجه‌ی کارایی را امضا کن",
    en: "PERFORMANCE BUDGET",
    body:
      "قانونِ عددی: dpr ≤ 2 (موبایل ≤ 1.5) • صحنه ≤ ۱۵۰ هزار مثلث • تکسچر ≤ ۲ مگابایت • حداکثر ۴ material • ذرات با Points و یک geometry • هر چیزی که بیرون دید است: frameloop خاموش. اگر چیزی به ۶۰fps نرسد، حذفش کن — نه بهینه‌سازی، حذف.",
    code: `<Canvas dpr={[1, isMobile ? 1.5 : 2]}
        frameloop={visible ? 'always' : 'never'}
        gl={{ antialias: !isMobile, powerPreference: 'high-performance' }} />`,
    fails: "باگِ مرگبار: رندر بی‌وقفه در پس‌زمینه → باتری موبایل تمام می‌شود، تب throttle می‌شود، انیمیشن می‌لرزد.",
  },
  {
    n: "۰۸",
    title: "موبایل و RTL شهروند درجه‌یک‌اند",
    en: "MOBILE · RTL · A11Y",
    body:
      "طراحی از ۳۶۰px به بالا. در RTL از transform‌های بی‌طرف استفاده کن (rotate هر دو جهت یکی است؛ translateX را آگاهانه علامت بده) و فاصله‌ها را با margin-inline بده. لمسی: هدف ≥ ۴۴px، drag به‌جای hover. و همیشه: prefers-reduced-motion → چرخش متوقف، ذرات کم، اسکرول نرم خاموش.",
    code: `@media (prefers-reduced-motion: reduce) {
  .marquee-track, .float { animation: none !important; }
}
const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
speed = reduced ? 0 : speed;`,
    fails: "باگِ مرگبار: منوی دسکتاپی با hover:only روی موبایل؛ به‌هم‌ریختگی آینه‌ای در فارسی؛ اسکرول افقی اضافه.",
  },
  {
    n: "۰۹",
    title: "پاک‌سازی، یا حافظه می‌میرد",
    en: "CLEANUP OR DEATH",
    body:
      "هر effect که رندرر، observer، listener یا rAF می‌سازد، باید برگشتش را بدهد. در StrictMode دوبار اجرا می‌شود؛ اگر cleanup نداشته باشی، دو WebGL context می‌سازی و مرورگر اولین را می‌کُشد. geometry/material/texture را dispose کن. این قانون، باگِ «بعد از چند دقیقه لگ می‌گیرد» را ریشه‌کن می‌کند.",
    code: `useEffect(() => {
  const ro = new ResizeObserver(onResize); ro.observe(el);
  el.addEventListener('pointermove', onMove);
  const id = requestAnimationFrame(loop);
  return () => {                       // ← این خط، سایت را زنده نگه می‌دارد
    ro.disconnect();
    el.removeEventListener('pointermove', onMove);
    cancelAnimationFrame(id);
    renderer.setAnimationLoop(null);
    geometry.dispose(); material.dispose(); renderer.dispose();
  };
}, []);`,
    fails: "باگِ مرگبار: حذف نشدن listener در unmount → نشتی حافظه، کرش تب، «Too many active WebGL contexts».",
  },
  {
    n: "۱۰",
    title: "تحویل = چک‌لیست، نه حسِ خوب",
    en: "SHIP ON EVIDENCE",
    body:
      "هیچ‌وقت نگویید «تمام شد». این ده مورد باید سبز شوند: build بدون خطا • کنسول تمیز • بدون اسکرول افقی • LCP < ۲.۵s • ۶۰fps در اسکرول • touch targetها ≥ ۴۴ • fallback WebGL فعال • reduced-motion جواب می‌دهد • متن‌ها در DOM نه در canvas • RTL سالم. چک‌لیست پایین همین سایت را ببین و تیک بزن.",
    code: `npm run build && grep -r "TODO" src/  # باید خالی باشد
// Ctrl+Shift+0 → پنلِ دیباگِ همین سایت را باز کن`,
    fails: "باگِ مرگبار: تحویل بدون تست روی دستگاه واقعی؛ «روی لپ‌تاپ من که درست بود».",
  },
];

/* ─────────── ضد‌الگوها: قاتلان سایت سه‌بعدی ─────────── */
export const BUGS = [
  {
    id: "b1",
    symptom: "صفحه‌ی سفید روی موبایل، روی دسکتاپ سالم",
    cause: "ساختن رندرر بدون try/catch و بدون بررسی پشتیبانی WebGL.",
    fix: "hasWebGL() + <noscript> + فالبک CSS-3D از همان markup.",
  },
  {
    id: "b2",
    symptom: "بعد از ۲ دقیقه تب کرش می‌کند",
    cause: "نشتی حافظه: geometry/material ساخته می‌شود ولی dispose نمی‌شود.",
    fix: "یک useDisposable و useRef برای هر resource؛ dispose در cleanup.",
  },
  {
    id: "b3",
    symptom: "انیمیشن روی لپ‌تاپ ۱۲۰Hz دو برابر سریع است",
    cause: "افزودن مقدار ثابت در هر فریم به‌جای ضرب در delta.",
    fix: "همیشه dt: rotation.y += 0.4 * dt، و damping با exp(-k*dt).",
  },
  {
    id: "b4",
    symptom: "اسکرول می‌لرزد (jank)",
    cause: "خواندن scrollY + offsetHeight در scroll listener → layout thrash.",
    fix: "rAF-throttle یا useScroll؛ فقط transform/opacity بنویس.",
  },
  {
    id: "b5",
    symptom: "متن روی شیء سه‌بعدی تار یا بریده است",
    cause: "رندر متن داخل WebGL با تکسچرِ کم‌رزولوشن.",
    fix: "متن در DOM + transform هم‌زمان؛ یا drei/Text با فونت محلی.",
  },
  {
    id: "b6",
    symptom: "چیدمان فارسی آینه‌ای و به‌هم‌ریخته",
    cause: "استفاده از left/right و translateX ثابت‌علامت در RTL.",
    fix: "inset-inline / margin-inline؛ rotate بی‌طرف؛ dir=\"rtl\" روی html.",
  },
  {
    id: "b7",
    symptom: "«Too many active WebGL contexts»",
    cause: "چند <Canvas> هم‌زمان بدون محدودیت و بدون pause.",
    fix: "حداکثر ۱ تا ۲ context؛ frameloop='never' وقتی بیرون دید است.",
  },
  {
    id: "b8",
    symptom: "خروجی build تک‌فایلی، صحنه سیاه",
    cause: "تکسچر/HDR از path مطلق یا CDN که inline نشده.",
    fix: "یا data-uri/programmatic، یا assets در public/ با نسبی‌سازی.",
  },
];

/* ─────────── لایه‌های معماری (نمایش ایزومتریک) ─────────── */
export const LAYERS = [
  {
    id: "L4",
    name: "لایه‌ی تحویل",
    en: "BUILD · QA · PERF",
    tools: ["vite build", "Lighthouse", "Safari/iOS test"],
    z: 4,
    color: "#ffb347",
    note: "هیچ‌چیز بدون شواهد تحویل نمی‌شود.",
  },
  {
    id: "L3",
    name: "لایه‌ی حرکت",
    en: "MOTION SYSTEM",
    tools: ["framer-motion", "damping", "scroll progress"],
    z: 3,
    color: "#ff6b4a",
    note: "زمان‌محور، بی‌پایان‌نبودن، respect reduced-motion.",
  },
  {
    id: "L2",
    name: "لایه‌ی سه‌بعدی",
    en: "WEBGL · THREE",
    tools: ["@react-three/fiber", "ShaderMaterial", "Points"],
    z: 2,
    color: "#4fd1ff",
    note: "کم‌هندسه، بدون دارایی برون‌خطی، با فالبک.",
  },
  {
    id: "L1",
    name: "لایه‌ی چیدمان",
    en: "CSS 3D · TAILWIND",
    tools: ["perspective", "preserve-3d", "utility-first"],
    z: 1,
    color: "#35d0a0",
    note: "ساختار، تایپوگرافی، RTL، ریسپانسیو.",
  },
  {
    id: "L0",
    name: "لایه‌ی پایه",
    en: "REACT · VITE · TS",
    tools: ["React 19", "TypeScript", "StrictMode"],
    z: 0,
    color: "#94bcbc",
    note: "پایه‌ی محکم؛ StrictMode نشتی‌ها را لو می‌دهد.",
  },
];

/* ─────────── چک‌لیست آمادگی ─────────── */
export const CHECKS = [
  { id: "c1", label: "WebGL با try/catch + فالبک CSS-3D", w: 16, hint: "بیمه‌ی عمر صفحه" },
  { id: "c2", label: "هر effect یک cleanup دارد", w: 14, hint: "ضد نشتی حافظه" },
  { id: "c3", label: "dpr clamp و geometry budget", w: 12, hint: "۶۰fps روی موبایل" },
  { id: "c4", label: "delta-time در همه‌ی انیمیشن‌ها", w: 12, hint: "یکسان در ۶۰/۱۲۰Hz" },
  { id: "c5", label: "اسکرول فقط transform/ می‌نویسد", w: 11, hint: "بدون layout thrash" },
  { id: "c6", label: "رندر بیرونِ دید متوقف می‌شود", w: 9, hint: "باتری نجات" },
  { id: "c7", label: "prefers-reduced-motion رعایت شده", w: 8, hint: "دسترس‌پذیری" },
  { id: "c8", label: "RTL با inset-inline و rotate بی‌طرف", w: 8, hint: "فارسی سالم" },
  { id: "c9", label: "متن در DOM، نه در canvas", w: 6, hint: "سئو + خوانایی" },
  { id: "c10", label: "build تمیز، کنسول تمیز", w: 4, hint: "شاهدِ تحویل" },
];

/* ─────────── پرامپت‌ها: خروجیِ نهایی فرمول ─────────── */
export const MASTER_PROMPT = `تو یک مهندس ارشد گرافیک وب هستی. با «THE 3D FORMULA v4» یک سایت کاملاً سه‌بعدی، بدون باگ، ریسپانسیو و RTL‌ساز بساز.

فرمول (مغزِ کار، نه تزئینات):
BUGFREE_3D = (SCENE × DEPTH) + (SCROLL × MOTION) + (RULES ÷ COMPLEXITY)

پشته‌ی فناوری (اجباری):
- React 19 + Vite + TypeScript + Tailwind (utility-first، بدون CSS ماژول)
- three + @react-three/fiber فقط برای صحنه‌های واقعی سه‌بعدی (حداکثر ۲ بوم)
- framer-motion برای اسکرول/ریوال؛ lucide-react برای آیکون؛ فونت از Google Fonts با fallback سیستمی

۱۰ قانون ساخت:
01 سه لایه: WebGL (قهرمان) / CSS 3D (چیدمان، کارت‌ها) / Canvas2D-SVG (تزئین). هیچ UI متنی داخل WebGL نساز.
02 در DOM عمق بساز: .stage{perspective:1200px} + بچه‌ها preserve-3d و translateZ (-240 / 0 / +90).
03 WebGL را امن شروع کن: hasWebGL() با try/catch + listener رویداد webglcontextlost → فالبک CSS-3D. هرگز صفحه سفید نه.
04 متریال ارزان/نور گران: ShaderMaterial با fresnel + iridescence، حداکثر ۳ نور، بدون HDR/تکسچر برون‌خطی (build تک‌فایلی ۴۰۴ می‌گیرد).
05 زمان‌محور: همه‌جا delta. damping = cur + (tgt-cur)*(1-exp(-k*dt)). افزودن ثابت در هر فریم ممنوع.
06 اسکرول = دوربین: useScroll → scrollYProgress (0..1) → rotateX/position/camera.z. خواندن offsetHeight در handler ممنوع.
07 بودجه‌ی کارایی: dpr=[1, موبایل?1.5:2]، ≤150k مثلث، ≤4 material، ذرات با یک Points+BufferGeometry، frameloop='never' وقتی IntersectionObserver خارج از دید است.
08 موبایل/RTL/دسترس‌پذیری: mobile-first از ۳۶۰px، dir=rtl روی html، فاصله با margin-inline، آیکون‌های ≥۴۴px، drag به‌جای hover، prefers-reduced-motion → سرعت صفر.
09 پاک‌سازی: هر useEffect که observer/listener/rAF/renderer می‌سازد باید return cleanup داشته باشد؛ geometry/material/texture را dispose کن؛ در StrictMode باید دوبار‌اجرا امن باشد.
10 تحویل با شواهد: npm run build بدون خطا، کنسول تمیز، بدون اسکرول افقی، ۶۰fps در اسکرول، LCP<2.5s، هر section یک reveal با motion، هر کارت یک hover فیزیکی.

ساختار صفحه: Hero سه‌بعدیِ تمام‌صفحه (کریستالِ فرکتمل با noise-displacement + میدان ذرات + نور لبه) →
فرمول ۱۰ مرحله‌ای با کد قابل کپی → پلی‌گراند زنده (اسلایدرها پارامتر shader را تغییر دهند) →
معماری ۵ لایه به‌صورت استک ایزومتریک → گالری ضد‌الگو/باگ‌ها → چک‌لیست آمادگی با امتیاز زنده →
FAQ آکاردئونی → فوتر با فرمول. ناوبری چسبان با نوار پیشرفت اسکرول.

کیفیت بصری (نه تمپلیت): پالتِ لایه‌لایه با پس‌زمینه‌ی رادیال گرادیان + نویز overlay + خطوط اسکن؛
کنتراست شدید تایپوگرافی (display ۹۰۰ در برابر body ۳۰۰)؛ بدون گرادیان بنفش/صورتی؛ بدون همه‌جا-glass؛
حرکت‌ها ease-out-expo، ۲۰۰–۶۰۰ms، با.parallax ماوس و tilt سه‌بعدی روی کارت‌ها.

خروجی: کد کامل، فایل‌بندی‌شده، TypeScript، بدون TODO، بدون placeholder، بدون کتابخانه‌ای که نصب نشده.
قبل از تحویل، چک‌لیست ۱۰ ماده را خودت امضا کن و هر باگِ احتمالی را از لیست «قاتلان سایت سه‌بعدی» خفه کن.`;

export const PROMPT_VARIANTS = [
  {
    id: "react",
    label: "React + Three (کامل)",
    hint: "بهترین نتیجه — همان کاری که این سایت کرد",
    text: MASTER_PROMPT,
  },
  {
    id: "css",
    label: "فقط CSS — بدون کتابخانه",
    hint: "صفر وابستگی، کار روی همه‌ی مرورگرها، خروجی HTML تکی",
    text: `با «THE 3D FORMULA v4» فقط از HTML + CSS + vanilla JS استفاده کن (هیچ کتابخانه، هیچ build).

سه‌بعدی فقط با CSS 3D:
- .stage { perspective: 1200px } ، .layer { transform-style: preserve-3d }
- مکعب با ۶ وجه translateZ(±120px) و rotateY/X ؛ چرخش با @keyframes و animation-duration بر حسب زمان
- اسکرول: scrollY → یک متغیر CSS (--p: 0..1) با requestAnimationFrame بنویس،
  بعد transform‌ها را با calc() و آن متغیر بساز (JS فقط write، هیچ read در هر فریم)
- پارالاکس ماوس: --mx/--my روی ریشه، لایه‌ها با translateZ عمق واقعی بگیرند
- کارت‌ها: hover → rotateX/rotateY حداکثر ۸deg + translateZ(24px) + سایه‌ی نرم

قوانین ضد‌باگ:
- فقط transform/opacity انیمیشن شوند (بدون top/left/width)؛ will-change: transform روی لایه‌ی فعال
- @media (prefers-reduced-motion: reduce) → همه‌ی animation/transition خاموش
- پشتیبانی: @supports (transform-style: preserve-3d) با فالبکِ تخت
- RTL: dir=rtl، فاصله‌ها margin-inline، translateX‌ها علامت‌دار و آگاهانه
- موبایل: perspective را 900px کن، translateZ را ۴۰٪ کم کن، touch target ≥ 44px
- backdrop-filter فقط یک‌بار؛ blur ≤ 12px (قاتل FPS موبایل)

خروجی: یک فایل HTML کامل، تمیز، فارسی RTL، با تایپوگرافی قوی، بدون متن جعلی زیاد، بدون باگ اسکرول.`,
  },
  {
    id: "gsap",
    label: "GSAP + ScrollTrigger",
    hint: "بر سایت‌های اسکرول‌محور و agencies",
    text: `با «THE 3D FORMULA v4» از GSAP 3 + ScrollTrigger استفاده کن (WebGL اختیاری).

حرکتِ سه‌بعدی:
- gsap.set(el, { transformPerspective: 1100, rotateX: 0 }) و بعد از آن فقط gsap.to با transform
- هر section: ScrollTrigger.create({ start:'top 78%', end:'bottom 22%', scrub: 0.6 }) → rotateY/-Z و translateZ
- پینِ صحنه‌ی اصلی: pin: true, pinSpacing: true و scrub: 0.6 (میرایی = همان damping فرمول)
- ورودِ کارت‌ها: gsap.from('.card', { yPercent: 12, opacity: 0, rotateX: -12, stagger: 0.06, ease: 'power3.out' })
- پارالاکس ماوس: quickTo برای نرمی؛ هرگز مستقیم در mousemove ست نکن

قوانین ضد‌باگِ GSAP:
- مرزها: ScrollTrigger.refresh() بعد از بارگذاری فونت/تصویر؛ matchMedia برای موبایل (فقط یک‌بار)
- تمیزکاری: ctx = gsap.context(() => {...}, root) و ctx.revert() در unmount (SPA بدون باگ)
- reduced motion: if (matchMedia('(prefers-reduced-motion: reduce)').matches) → gsap.globalTimeline.timeScale(1000)
- scroller: body نه html؛ هیچ position: sticky تودرتو با pin ندارد
- موبایل: scrub را روی 0.5 بگذار، blur/box-shadow کم کن، will-change را بعد از end پاک کن

خروجی: کد کامل، RTL فارسی، mobile-first، بدون خطای کنسول.`,
  },
  {
    id: "three",
    label: "Three.js خالص (بدون React)",
    hint: "یک فایل JS + یک <canvas> — سبک‌ترین WebGL",
    text: `با «THE 3D FORMULA v4» یک صحنه‌ی Three.js خالص بساز؛ React لازم نیست.

اسکلت اجباری:
- const renderer = new THREE.WebGLRenderer({ canvas, antialias: window.devicePixelRatio < 2, powerPreference:'high-performance' })
- renderer.setPixelRatio(Math.min(devicePixelRatio, isMobile ? 1.5 : 2))
- حلقه: renderer.setAnimationLoop((t) => { const dt = (t - last)/1000; last = t; ... }) — requestAnimationFrame دستی نه
- دوربین: PerspectiveCamera(45, aspect, 0.1, 100)؛ عمق با fog: new THREE.Fog(bg, 6, 22)
- متریال: MeshPhysicalMaterial({ metalness:.9, roughness:.18, clearcoat:1 }) یا ShaderMaterial با fresnel
- ذرات: یک THREE.Points + BufferGeometry (نقطه‌ی max 4000 در موبایل، 9000 در دسکتاپ)
- resize: ResizeObserver روی container، نه window.scroll

ضد‌باگ:
- hasWebGL() با try/catch، و webglcontextlost → نمایش پیام/فالبک CSS
- در cleanup: geometry.dispose(), material.dispose(), renderer.dispose(), renderer.setAnimationLoop(null)
- IntersectionObserver → خارج از دید: setAnimationLoop(null)
- pointer: pointerdown/move/up با setPointerCapture؛ روی موبایل drag به‌جای hover
- بدون OrbitControls اگر UI می‌خواهد اسکرول کند؛ چرخش را با damping و scroll خودت بده

خروجی: index.html + main.js ماژولار، کامنت‌دار، بدون دارایی برون‌خطی.`,
  },
  {
    id: "next",
    label: "Next.js (App Router)",
    hint: "ضدِ هیدریشن — سه‌بعدی در React سروری بدون باگ",
    text: `با «THE 3D FORMULA v4» یک اپ Next.js (App Router + TypeScript + Tailwind) بساز که صحنه‌ی سه‌بعدی‌اش هرگز hydration error ندهد.

قراردادِ SSR (مهم‌ترین بخش):
- هر فایلِ دارای three/@react-three «use client» شروع شود و هرگز در renderِ سروری Canvas نسازد
- import dynamic from 'next/dynamic'
  const Scene = dynamic(() => import('@/components/Scene3D'), { ssr: false, loading: () => <SceneSkeleton /> })
- داخل Scene3D: const [mounted,setMounted]=useState(false); useEffect(()=>setMounted(true),[]) ; اگر !mounted → فالبکِ CSS-3D
- font از next/font (Vazirmatn برای فارسی + Space Grotesk برای لاتین) با CSS variables؛ بدون <link> بیرونی

بقیه‌ی فرمول، مو‌به‌مو:
- SCENE: حداکثر دو <Canvas> در کل صفحه؛ dpr=[1,1.5|2]؛ frameloop='never' خارج از دید
- DEPTH: یک کامپوننت <TiltCard> با perspective و preserve-3d که روی لایه‌های DOM عمق می‌سازد
- SCROLL: useScroll/useTransform از framer-motion (با 'use client') → rotateX، translateZ، مقیاس
- MOTION: delta-time + damp()؛ هیچ افزودنِ ثابت در فریم؛ Framer Motion = enter/exit فقط
- RULES: cleanup همه‌ی observer/listener؛ dispose هندسه؛ 'use client' در لبه‌ها نه در center؛ no unused imports
- COMPLEXITY: اگر یک افکت ۳۰ خطی سایت را می‌شکند، حذفش کن — نه بهینه‌سازی

ساختار صفحه: Hero تمام‌قد با کریستالِ noise-displaced → فرمول ۱۰ مرحله‌ای با کدِ کپی‌شدنی →
پلی‌گراندِ اسلایدری (پارامتر → uniform) → استکِ ایزومتریکِ لایه‌ها → گالریِ باگ‌ها → چک‌لیستِ امتیازی → FAQ → فوتر.
RTL با <html lang="fa" dir="rtl">، mobile-first، touch target ≥ 44px، prefers-reduced-motion.

تحویل: npm run build و next lint تمیز، کنسول بدون warning، بدون اسکرول افقی در ۳۲۰px، بدون خطای hydration.`,
  },
  {
    id: "nano",
    label: "نانو‌پرامپت (یک پاراگراف)",
    hint: "وقتی فقط ۳۰ ثانیه وقت داری",
    text: `یک سایت سه‌بعدی RTL و موبایل‌فرند بساز که این فرمول را مو‌به‌مو رعایت کند:
BUGFREE_3D = (SCENE × DEPTH) + (SCROLL × MOTION) + (RULES ÷ COMPLEXITY).
SCENE: فقط قهرمان با WebGL/Three، با try/catch و فالبک CSS-3D، بدون تکسچر برون‌خطی، dpr≤2 (موبایل 1.5).
DEPTH: perspective 1200px + preserve-3d + سه translateZ (-240/0/+90)؛ کارت‌ها hover → rotateX/Y≤8deg.
SCROLL: scrollYProgress 0..1 → چرخش/مکان/zoom؛ هیچ readِ layout در handler؛ فقط transform/opacity.
MOTION: delta-time + damping (1-exp(-k*dt))؛ زمان‌محور نه فریم‌محور؛ prefers-reduced-motion → توقف.
RULES: هر effect یک cleanup + dispose؛ frameloop خارج از دید خاموش؛ Touch ≥44px؛ فارسی با inset-inline.
COMPLEXITY: هر فیچر اضافه را حذف کن. تحویل: build بدون خطا، کنسول تمیز، بدون اسکرول افقی، ۶۰fps.`,
  },
];

/* ─────────── FAQ ─────────── */
export const FAQ = [
  {
    q: "چرا کل سایت را WebGL نمی‌سازی؟",
    a: "چون WebGL متن را نمی‌خواند، انتخاب متن را می‌کُشد، سئو را صفر می‌کند و روی موبایل باتری را می‌خورد. فرمول، WebGL را برای «چیزهایی که واقعاً سه‌بعدی‌اند» نگه می‌دارد و بقیه را به CSS 3D می‌دهد — همان عمق، یک‌دهم هزینه.",
  },
  {
    q: "روی موبایل واقعاً ۶۰fps می‌گیرد؟",
    a: "اگر چهار کلید را رعایت کنی بله: dpr روی ۱.۵ قفل شود، مثلث‌ها زیر ۱۵۰هزار بمانند، رندر بیرونِ دید خاموش شود، و backdrop-filter/box-shadow بزرگ حذف شوند. در همین سایت، میدان ذرات روی موبایل یک‌سوم است و صحنه با IntersectionObserver مدیریت می‌شود.",
  },
  {
    q: "این فرمول را چطور به AI دیگری بدهم؟",
    a: "از بخش «پرامپت مادر» کپی کن و در ChatGPT / Claude / Gemini / Cursor بچسبان. شش نسخه هست: React+Three، Next.js (App Router)، فقط CSS، GSAP، Three خالص، و نانو. هر شش نسخه همان ده قانون را دارند، فقط پشته‌ی فناوری فرق می‌کند — برای همین «به هر روشی» جواب می‌دهد.",
  },
  {
    q: "چرا StrictMode را نگه دارم؟",
    a: "چون StrictMode در توسعه دو بار effect را اجرا می‌کند و هر نشتی WebGL را فوراً لو می‌دهد. اگر صحنه‌ات با StrictMode خراب شد، مشکل cleanup توست — نه React. این ارزان‌ترین تستِ باگِ دنیای سه‌بعدی است.",
  },
  {
    q: "اسکرولِ سه‌بعدی بدون لگ چطور؟",
    a: "یک عدد نرمال‌شده بساز، با damping نرمش کن، و فقط به transform‌های GPU-دوست بده (rotate3d, translate3d, scale3d). هر چیز دیگری — height، background-position، filter در حال اسکرول — یعنی ری‌استایلایز و جانشینی.",
  },
  {
    q: "کدام کیفیت را قربانی نکنم؟",
    a: "کنتراست تایپوگرافی، easing، و زمان‌بندی. این سه، «گران‌نمایی» را می‌سازند و تقریباً رایگان‌اند. در مقابل، post-processing ملخ‌ملکی (bloom سنگین، DOF، SSAO) را روی موبایل قربانی کن.",
  },
];

/* ─────────── ماتریسِ روش‌ها: فرمول روی هر موتور جواب می‌دهد ─────────── */
export const METHODS = [
  { name: "three.js + R3F", depth: "WebGL", risk: "کم", note: "انتخابِ پیش‌فرضِ این سایت؛ دو بوم حداکثر", score: 98 },
  { name: "Babylon.js", depth: "WebGL", risk: "کم", note: "برای فیزیک و صحنه‌ی سنگین؛ همان ده قانون، GUI در DOM", score: 94 },
  { name: "CSS 3D فقط", depth: "GPU composited", risk: "بسیار کم", note: "بدون کتابخانه؛ کارت/مکعب/تئاتر اسکرول؛ SEO کامل", score: 99 },
  { name: "GSAP + ScrollTrigger", depth: "CSS 3D + WebGL", risk: "کم", note: "بهترین ابزارِ اسکرول؛ حتماً gsap.context و revert", score: 96 },
  { name: "Lenis + WebGL", depth: "مصرفِ مشترک", risk: "متوسط", note: "اسکرول نرم را یک‌لایه نگه دار؛ دو rAF رقابت نمی‌کنند", score: 88 },
  { name: "A-Frame / WebXR", depth: "WebGL", risk: "متوسط", note: "برای VR؛ entity-component را کم نگه دار، موبایل داغ می‌کند", score: 76 },
  { name: "Spline / Dora (no-code)", depth: "WebGL export", risk: "متوسط", note: "خروجی را با fallback بپیچ؛ تکسچرهای سنگین را کم کن", score: 72 },
  { name: "Canvas2D شبه‌سه‌بعدی", depth: "projected 2D", risk: "بسیار کم", note: "نمای سه‌بعدی با math؛ برای ذرات و تزئین، عالی و ارزان", score: 92 },
  { name: "R3F + Rapier", depth: "WebGL + فیزیک", risk: "زیاد", note: "حداکثر ۲۰ بدنه؛ world.step با delta؛ وگرنه ۳۰fps", score: 68 },
];

export const STATS = [
  { v: "۱۰", k: "قانونِ طلایی", en: "RULES" },
  { v: "۶", k: "نسخه‌ی پرامپت", en: "VARIANTS" },
  { v: "۸", k: "قاتلِ سایت سه‌بعدی", en: "BUG KILLERS" },
  { v: "۶۰", k: "فریم بر ثانیه، تضمینی", en: "FPS TARGET" },
];
