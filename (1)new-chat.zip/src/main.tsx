import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";
import App from "./App";

/* THE 3D FORMULA · §۰۳ — لودرِ پیشِ بوت (CSS-3D، صفر وابستگی) داخل #root است تا
   اولین پنت را سیاه نبینیم؛ App در اولین commit آن را fade و حذف می‌کند. */
createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <App />
  </StrictMode>
);
