import { useRef, useState } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { Boxes, Layers3, ScanEye } from "lucide-react";
import { LAYERS, METHODS } from "@/formula";
import { Chip, CodeBlock, Reveal, SectionHead } from "@/components/ui";
import { cn } from "@/utils/cn";

const CONTRACT = `// src/ — قراردادِ فایل‌بندی (قانون §۰۱ + §۰۹)
src/
├─ formula.ts          // منبع حقیقت: فرمول، قوانین، پرامپت‌ها
├─ three/Scene3D.tsx   // تنها ورودیِ WebGL (fallback + dispose + pause)
├─ components/ui.tsx   // Reveal · TiltCard · CodeBlock · SectionHead
├─ sections/*          // هر بخش = یک فایل، بدون state مشترک
└─ App.tsx             // فقط ترکیبِ بخش‌ها + پنلِ دیباگ

// قانونِ طلاییِ معماری:
// ۱) داده در .ts  →  ۲) رندر در .tsx  →  ۳) حرکت در ui.tsx
// ۴) WebGL در یک فایل  →  ۵) هیچ فایلِ دیگری three.js import نکند
// نتیجه: AI می‌تواند هر لایه را جدا عوض کند، بدون شکستن بقیه.`;

export default function Architecture() {
  const [sel, setSel] = useState<string | null>("L2");
  const [exploded, setExploded] = useState(true);
  const wrap = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: wrap, offset: ["start end", "end start"] });
  const tilt = useTransform(scrollYProgress, [0, 1], [24, 62]);
  const spin = useTransform(scrollYProgress, [0, 1], [-16, 12]);

  return (
    <section id="engine" className="relative mx-auto w-full max-w-[1400px] px-4 py-20 lg:px-8 lg:py-28">
      <SectionHead
        index="۰۲"
        kicker="معماری پنج‌لایه"
        en="ARCHITECTURE STACK · CSS-3D ISOMETRIC"
        title={
          <>
            سه‌بعدیِ بی‌باگ، یک <span className="text-jade">لایه‌بندی</span> می‌خواهد
            <br className="hidden md:block" /> نه یک صحنه‌ی شلوغ
          </>
        }
        lead="هر لایه مستقل تست می‌شود، مستقل قابل تعویض است و هیچ‌کدام متن را در canvas نمی‌سوزاند. روی لایه‌ها بزن تا در مدلِ ایزومتریک بالا بیاید."
      />

      <div ref={wrap} className="mt-12 grid gap-8 lg:grid-cols-[1.05fr_1fr] lg:gap-12">
        {/* ══ مدل ایزومتریک ══ */}
        <Reveal className="order-2 lg:order-1">
          <div className="panel relative overflow-hidden rounded-3xl p-4 md:p-8">
            <div className="pointer-events-none absolute inset-0 grid-floor opacity-25" />
            <div className="absolute right-5 top-5 z-10 flex items-center gap-2 font-mono text-[10px] tracking-[0.2em] text-mist/55">
              <ScanEye size={13} className="text-jade" /> SCROLL-DRIVEN · {exploded ? "EXPLODED" : "SEALED"}
            </div>

            <div className="relative mx-auto grid min-h-[380px] place-items-center [perspective:1400px] md:min-h-[500px]">
              <motion.div
                style={{
                  rotateX: tilt,
                  rotateZ: spin,
                  transformStyle: "preserve-3d",
                }}
                className="relative h-[240px] w-[240px] md:h-[330px] md:w-[330px]"
              >
                {LAYERS.map((l, i) => {
                  const active = sel === l.id;
                  const gap = exploded ? 62 : 22;
                  const z = (LAYERS.length - 1 - i) * gap;
                  return (
                    <motion.button
                      key={l.id}
                      onClick={() => setSel(active ? null : l.id)}
                      animate={{
                        z: active && exploded ? z + 42 : z,
                        scale: active ? 1.045 : 1,
                        opacity: sel && !active ? 0.45 : 1,
                      }}
                      transition={{ type: "spring", stiffness: 190, damping: 22 }}
                      initial={{ z }}
                      className="absolute inset-0 rounded-[26px] border text-start backdrop-blur-[2px] transition-colors duration-300"
                      style={{
                        borderColor: active ? l.color : "rgba(148,188,188,.2)",
                        background: `linear-gradient(150deg, ${l.color}22, rgba(4,20,27,.72) 62%)`,
                        boxShadow: active ? `0 22px 60px -18px ${l.color}55` : "none",
                      }}
                    >
                      <span className="flex h-full flex-col justify-between p-4 md:p-5">
                        <span className="flex items-center justify-between">
                          <span className="font-mono text-[10px] tracking-[0.22em]" style={{ color: l.color }}>
                            {l.id}
                          </span>
                          <span className="font-display text-[10px] uppercase tracking-[0.18em] text-mist/55">
                            {l.en}
                          </span>
                        </span>
                        <span>
                          <span className="block text-[14px] font-black text-sand md:text-[17px]">{l.name}</span>
                          <span className="mt-1.5 hidden gap-1.5 md:flex">
                            {l.tools.map((t) => (
                              <span
                                key={t}
                                className="rounded-md border border-mist/15 bg-abyss/50 px-1.5 py-0.5 font-mono text-[9px] text-mist/70"
                              >
                                {t}
                              </span>
                            ))}
                          </span>
                        </span>
                      </span>
                    </motion.button>
                  );
                })}
              </motion.div>
            </div>

            <div className="relative z-10 mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-mist/10 pt-4">
              <div className="flex flex-wrap gap-1.5">
                {LAYERS.map((l) => (
                  <button
                    key={l.id}
                    onClick={() => setSel(sel === l.id ? null : l.id)}
                    className={cn(
                      "rounded-lg border px-2.5 py-1 font-mono text-[10px] transition-all duration-300",
                      sel === l.id ? "text-ink" : "border-mist/18 text-mist/60 hover:text-sand"
                    )}
                    style={sel === l.id ? { background: l.color, borderColor: l.color } : undefined}
                  >
                    {l.id}
                  </button>
                ))}
              </div>
              <button
                onClick={() => setExploded((v) => !v)}
                className="flex items-center gap-2 rounded-xl border border-jade/35 bg-jade/10 px-3.5 py-1.5 text-[12px] font-bold text-jade transition-transform duration-300 hover:scale-[1.03] active:scale-95"
              >
                <Boxes size={13} /> {exploded ? "بستنِ لایه‌ها" : "بازکردنِ لایه‌ها"}
              </button>
            </div>
          </div>
        </Reveal>

        {/* ══ شرح لایه‌ها ══ */}
        <div className="order-1 space-y-3 lg:order-2">
          {LAYERS.map((l, i) => (
            <Reveal key={l.id} delay={i * 0.05}>
              <button
                onMouseEnter={() => setSel(l.id)}
                onFocus={() => setSel(l.id)}
                onClick={() => setSel(l.id)}
                className={cn(
                  "flex w-full items-start gap-4 rounded-2xl border p-4 text-start transition-all duration-400",
                  sel === l.id
                    ? "-translate-y-0.5 border-mist/25 bg-abyss/60 shadow-glow"
                    : "border-mist/10 hover:border-mist/20"
                )}
              >
                <span
                  className="mt-1 h-9 w-1.5 shrink-0 rounded-full transition-all duration-500"
                  style={{
                    background: l.color,
                    opacity: sel === l.id ? 1 : 0.4,
                    boxShadow: sel === l.id ? `0 0 20px ${l.color}` : "none",
                  }}
                />
                <span className="min-w-0 flex-1">
                  <span className="flex flex-wrap items-center gap-2">
                    <span className="text-[15px] font-black text-sand">{l.name}</span>
                    <span className="font-mono text-[9.5px] tracking-[0.18em] text-mist/45">{l.en}</span>
                  </span>
                  <span className="mt-1.5 block text-[12.5px] leading-6 text-mist/70">{l.note}</span>
                  <span className="mt-2 flex flex-wrap gap-1.5 md:hidden">
                    {l.tools.map((t) => (
                      <Chip key={t}>{t}</Chip>
                    ))}
                  </span>
                </span>
                <Layers3
                  size={16}
                  className={cn("mt-1 shrink-0 transition-colors duration-300", sel === l.id ? "text-amber" : "text-mist/30")}
                />
              </button>
            </Reveal>
          ))}
          <Reveal delay={0.3}>
            <CodeBlock code={CONTRACT} filename="src/ · layout contract" />
          </Reveal>
        </div>
      </div>

      {/* ══ ماتریسِ روش‌ها: فرمول، موتور‌محور نیست ══ */}
      <Reveal className="mt-14">
        <div className="panel overflow-hidden rounded-3xl">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-mist/10 bg-abyss/40 px-4 py-3.5 md:px-5">
            <p className="flex items-center gap-2 font-mono text-[10.5px] tracking-[0.2em] text-amber/85">
              <Layers3 size={13} /> METHOD MATRIX · هر روش، همان فرمول
            </p>
            <p className="font-mono text-[9.5px] text-mist/45">SCORE = سازگاریِ روش با ده قانون</p>
          </div>
          <div className="grid grid-cols-1 divide-y divide-mist/[0.07]">
            {METHODS.map((m, i) => (
              <motion.div
                key={m.name}
                initial={{ opacity: 0, x: -18 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, amount: 0.5 }}
                transition={{ duration: 0.5, delay: Math.min(i * 0.05, 0.4), ease: [0.16, 1, 0.3, 1] }}
                className="group grid grid-cols-[1fr_auto] items-center gap-x-4 px-4 py-3.5 transition-colors duration-300 hover:bg-jade/[0.05] md:grid-cols-[1.15fr_0.85fr_0.55fr_1.6fr_auto] md:px-5"
              >
                <span className="flex items-center gap-2.5 text-[13.5px] font-black text-sand md:text-[14.5px]">
                  <span className="h-1.5 w-1.5 rounded-full bg-jade/70 transition-transform duration-300 group-hover:scale-[1.8]" />
                  <span dir="ltr">{m.name}</span>
                </span>
                <span className="order-5 mt-1 font-mono text-[10px] tracking-[0.14em] text-mist/45 md:order-none md:mt-0">
                  {m.depth}
                </span>
                <span className="order-4 md:order-none">
                  <Chip tone={m.risk === "زیاد" ? "rust" : m.risk === "متوسط" ? "amber" : "jade"}>ریسک: {m.risk}</Chip>
                </span>
                <span className="col-span-2 mt-1 text-[12.5px] leading-6 text-mist/70 md:col-span-1 md:order-none md:mt-0">
                  {m.note}
                </span>
                <span className="flex w-24 items-center gap-2 md:order-none">
                  <span className="relative h-1 flex-1 overflow-hidden rounded-full bg-mist/12">
                    <motion.span
                      initial={{ scaleX: 0 }}
                      whileInView={{ scaleX: m.score / 100 }}
                      viewport={{ once: true }}
                      transition={{ duration: 0.9, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
                      className="absolute inset-y-0 right-0 origin-right rounded-full bg-linear-to-l from-amber to-jade"
                    />
                  </span>
                  <span className="font-mono text-[10.5px] text-sand/80">{m.score}</span>
                </span>
              </motion.div>
            ))}
          </div>
        </div>
      </Reveal>
    </section>
  );
}
