import { useMemo, useState } from "react";
import { motion, useReducedMotion } from "framer-motion";
import { Check, CircleDashed, ShieldCheck, Smartphone, Tablet, Monitor, Zap } from "lucide-react";
import { CHECKS, FORMULA_CORE } from "@/formula";
import { Chip, CodeBlock, Reveal, SectionHead } from "@/components/ui";
import { cn } from "@/utils/cn";

const fa = (n: number | string) => String(n).replace(/\d/g, (d) => "۰۱۲۳۴۵۶۷۸۹"[+d]);

/* ── گِیجِ سه‌بعدیِ امتیاز ── */
function Gauge({ score }: { score: number }) {
  const reduced = useReducedMotion();
  const color = score >= 85 ? "#35d0a0" : score >= 50 ? "#ffb347" : "#ff6b4a";
  return (
    <div className="[perspective:900px]">
      <motion.div
        animate={{ rotateX: reduced ? 0 : -14 + (score / 100) * 22, rotateZ: reduced ? 0 : -3 + (score / 100) * 6 }}
        transition={{ type: "spring", stiffness: 120, damping: 18 }}
        style={{ transformStyle: "preserve-3d" }}
        className="relative mx-auto grid h-40 w-40 place-items-center"
      >
        <div
          className="absolute inset-0 rounded-full"
          style={{
            background: `conic-gradient(from -90deg, ${color} ${score * 3.6}deg, rgba(148,188,188,.12) ${score * 3.6}deg)`,
            maskImage: "radial-gradient(circle, transparent 61%, #000 62%)",
            WebkitMaskImage: "radial-gradient(circle, transparent 61%, #000 62%)",
            boxShadow: `0 0 40px -8px ${color}66`,
            transition: "background .5s ease",
          }}
        />
        <div
          className="absolute inset-[14px] rounded-full border"
          style={{ borderColor: `${color}44`, transform: "translateZ(18px)" }}
        />
        <div className="relative text-center" style={{ transform: "translateZ(30px)" }}>
          <span className="block font-display text-[40px] font-bold leading-none" style={{ color }}>
            {fa(score)}
          </span>
          <span className="mt-1 block font-mono text-[9px] tracking-[0.2em] text-mist/55">READINESS</span>
        </div>
      </motion.div>
    </div>
  );
}

/* ── اثباتِ ریسپانسیو: دسکتاپ/تبلت/موبایل ── */
const FRAMES = [
  { id: "m", label: "۳۷۵px", icon: Smartphone, w: "max-w-[164px]", cols: "grid-cols-1", h: "h-[250px]" },
  { id: "t", label: "۷۶۸px", icon: Tablet, w: "max-w-[248px]", cols: "grid-cols-2", h: "h-[250px]" },
  { id: "d", label: "۱۴۴۰px", icon: Monitor, w: "max-w-[326px]", cols: "grid-cols-3", h: "h-[250px]" },
] as const;

function DeviceProof() {
  const [f, setF] = useState<(typeof FRAMES)[number]>(FRAMES[0]);
  return (
    <div className="panel rounded-3xl p-4 md:p-5">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
        <p className="flex items-center gap-2 font-mono text-[10.5px] tracking-[0.2em] text-jade/85">
          <Zap size={13} /> RESPONSIVE PROOF · قانون §۰۸
        </p>
        <div className="flex gap-1.5">
          {FRAMES.map((x) => (
            <button
              key={x.id}
              onClick={() => setF(x)}
              className={cn(
                "flex items-center gap-1.5 rounded-lg border px-2.5 py-1.5 font-mono text-[10px] transition-all duration-300",
                f.id === x.id
                  ? "border-amber/55 bg-amber/12 text-amber"
                  : "border-mist/15 text-mist/55 hover:border-mist/35 hover:text-sand"
              )}
            >
              <x.icon size={12} /> {x.label}
            </button>
          ))}
        </div>
      </div>

      <div className="grid-floor flex justify-center overflow-hidden rounded-2xl border border-mist/10 bg-abyss/50 p-4 [perspective:1000px]">
        <motion.div
          key={f.id}
          initial={{ opacity: 0, rotateY: -16, x: 12 }}
          animate={{ opacity: 1, rotateY: 0, x: 0 }}
          transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
          style={{ transformStyle: "preserve-3d" }}
          className={cn("w-full rounded-xl border border-jade/25 bg-ink/85 p-2.5 shadow-glow transition-all duration-500", f.w, f.h)}
        >
          <div className="mb-2 flex items-center justify-between">
            <span className="h-1.5 w-8 rounded-full bg-amber/80" />
            <div className="flex gap-1">
              {[0, 1, 2].map((i) => (
                <span key={i} className="h-1 w-4 rounded-full bg-mist/25" />
              ))}
            </div>
          </div>
          <div className="relative mb-2 grid h-[74px] place-items-center overflow-hidden rounded-lg bg-linear-to-bl from-shelf/70 to-abyss">
            <div className="h-9 w-9 animate-[spin_9s_linear_infinite] rounded-sm border border-jade/70" style={{ transform: "rotateX(28deg) rotateY(34deg)" }} />
            <div className="absolute inset-x-2 bottom-1.5 space-y-1">
              <div className="h-1 w-2/3 rounded-full bg-sand/60" />
              <div className="h-1 w-1/3 rounded-full bg-mist/30" />
            </div>
          </div>
          <div className={cn("grid gap-1.5", f.cols)}>
            {[0, 1, 2, 3, 4].map((i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.12 + i * 0.05 }}
                className="rounded-md border border-mist/12 bg-deep/60 p-1.5"
              >
                <div className="mb-1 h-1 w-1/2 rounded-full bg-jade/70" />
                <div className="h-1 w-full rounded-full bg-mist/25" />
                <div className="mt-1 h-1 w-3/4 rounded-full bg-mist/18" />
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>

      <ul className="mt-4 grid gap-2 text-[12px] leading-6 text-mist/70 sm:grid-cols-2">
        {[
          "منو روی موبایل: همبرگری + پنلِ چرخان",
          "لمسی: drag به‌جای hover، هدف ≥ ۴۴px",
          "ذراتِ صحنه روی موبایل یک‌سوم",
          "clamp() برای تایپوگرافی، بدون شکستِ خط",
        ].map((t) => (
          <li key={t} className="flex items-start gap-2">
            <Check size={13} className="mt-1 shrink-0 text-jade" />
            {t}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default function Audit() {
  const [on, setOn] = useState<string[]>(["c1", "c2", "c5", "c8", "c10"]);
  const toggle = (id: string) => setOn((v) => (v.includes(id) ? v.filter((x) => x !== id) : [...v, id]));

  const score = useMemo(() => {
    const total = CHECKS.reduce((a, c) => a + c.w, 0);
    const got = CHECKS.filter((c) => on.includes(c.id)).reduce((a, c) => a + c.w, 0);
    return Math.round((got / total) * 100);
  }, [on]);

  const missing = CHECKS.filter((c) => !on.includes(c.id));
  const repair = `فرمول: ${FORMULA_CORE}

این موارد از چک‌لیستِ سه‌بعدیِ من رعایت نشده — فقط همین‌ها را در کدِ موجود اصلاح کن، ساختار را نشکن، وابستگیِ جدید اضافه نکن، و برای هر مورد یک snippetِ قبل/بعد بده:

${missing.length ? missing.map((m) => `☐ ${m.label}  ← ${m.hint}`).join("\n") : "☑ همه‌ی موارد سبز است. فقط build را دوباره بگیر و کنسول را تأیید کن."}

قوانینِ غیرقابل‌مذاکره:
- delta-time در همه‌ی انیمیشن‌ها؛ هیچ افزودنِ ثابتی در هر فریم
- dpr = [1, موبایل?1.5:2]، هندسه زیر ۱۵۰هزار مثلث
- هر useEffect یک cleanup؛ dispose برای geometry/material/texture
- خارج از دید: frameloop = never
- fallback برای نبودِ WebGL (CSS 3D) — هرگز صفحه‌ی سفید
- prefers-reduced-motion → توقفِ چرخش
- RTL: inset-inline و rotate بی‌طرف؛ بدون اسکرول افقی
- خروجی: build بدون خطا، کنسول تمیز`;

  const verdict =
    score >= 90
      ? { t: "قابلِ تحویل", c: "text-jade", d: "سایت سه‌بعدی‌تو در موبایل هم نفس می‌کشد. برو فایلی رو بفرست." }
      : score >= 60
        ? { t: "تقریباً", c: "text-amber", d: "ریسک اصلی: کارایی روی موبایل و پاک‌سازی حافظه." }
        : { t: "خطرِ کرش", c: "text-rust", d: "با این وضعیت، صفحه‌ی سفید و لگِ اسکرول منتظرت هستند." };

  return (
    <section id="audit" className="relative mx-auto w-full max-w-[1400px] px-4 py-20 lg:px-8 lg:py-28">
      <SectionHead
        index="۰۶"
        kicker="چک‌لیستِ آمادگی"
        en="READINESS AUDIT · WEIGHTED SCORE"
        title={
          <>
            تیک بزن؛ امتیازت <span className="text-amber">زنده</span> حساب می‌شود
          </>
        }
        lead="هر مورد وزن دارد — چون بعضی باگ‌ها کشنده‌ترند. مواردِ تیک‌نخورده به یک پرامپتِ اصلاحی تبدیل می‌شوند که می‌توانی همین حالا به AI بدهی."
      />

      <div className="mt-10 grid gap-5 lg:mt-14 lg:grid-cols-[1fr_1fr] lg:gap-8">
        <div className="space-y-4">
          <Reveal>
            <div className="panel rounded-3xl p-4 md:p-5">
              <div className="flex flex-col items-center gap-5 sm:flex-row sm:items-center">
                <Gauge score={score} />
                <div className="min-w-0 flex-1 text-center sm:text-start">
                  <p className={cn("font-display text-[26px] font-bold leading-none", verdict.c)}>{verdict.t}</p>
                  <p className="mt-2 text-[13px] leading-7 text-mist/75">{verdict.d}</p>
                  <div className="mt-4 flex flex-wrap justify-center gap-2 sm:justify-start">
                    <Chip tone="jade">{fa(on.length)} از {fa(CHECKS.length)} سبز</Chip>
                    <button
                      onClick={() => setOn(CHECKS.map((c) => c.id))}
                      className="rounded-full border border-jade/40 bg-jade/10 px-2.5 py-1 font-mono text-[10.5px] text-jade transition-colors hover:bg-jade/20"
                    >
                      همه سبز
                    </button>
                    <button
                      onClick={() => setOn([])}
                      className="rounded-full border border-mist/18 px-2.5 py-1 font-mono text-[10.5px] text-mist/60 transition-colors hover:border-rust/40 hover:text-rust"
                    >
                      ریست
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </Reveal>

          <div className="grid gap-2">
            {CHECKS.map((c, idx) => {
              const checked = on.includes(c.id);
              return (
                <Reveal key={c.id} delay={Math.min(idx * 0.035, 0.25)}>
                  <button
                    onClick={() => toggle(c.id)}
                    aria-pressed={checked}
                    className={cn(
                      "flex w-full items-center gap-3 rounded-2xl border p-3 text-start transition-all duration-350 active:scale-[0.995]",
                      checked
                        ? "border-jade/40 bg-jade/[0.07]"
                        : "border-mist/10 bg-abyss/25 hover:border-amber/35 hover:bg-amber/[0.04]"
                    )}
                  >
                    <span
                      className={cn(
                        "grid h-7 w-7 shrink-0 place-items-center rounded-lg border transition-all duration-300",
                        checked ? "border-jade bg-jade text-ink" : "border-mist/30 text-transparent"
                      )}
                    >
                      {checked ? <Check size={15} strokeWidth={3} /> : <CircleDashed size={14} className="text-mist/35" />}
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className={cn("block text-[13.5px] font-bold", checked ? "text-sand" : "text-mist/80")}>
                        {c.label}
                      </span>
                      <span className="mt-0.5 block text-[11.5px] text-mist/45">{c.hint}</span>
                    </span>
                    <span className="shrink-0 font-mono text-[11px] text-amber/80">+{fa(c.w)}</span>
                  </button>
                </Reveal>
              );
            })}
          </div>
        </div>

        <div className="space-y-4">
          <Reveal delay={0.06}>
            <div className="flex items-center gap-2 rounded-2xl border border-amber/25 bg-amber/[0.06] p-3.5">
              <ShieldCheck size={16} className="shrink-0 text-amber" />
              <p className="text-[12.5px] leading-6 text-amber/95">
                پرامپتِ پایین خودکار از مواردِ تیک‌نخورده ساخته می‌شود — کپی‌اش کن و به AI بده تا همان چند مورد را
                درست کند.
              </p>
            </div>
          </Reveal>
          <Reveal delay={0.1}>
            <CodeBlock code={repair} filename="repair-prompt.md" lines={false} className="[&>pre]:max-h-[42vh]" />
          </Reveal>
          <Reveal delay={0.14}>
            <DeviceProof />
          </Reveal>
        </div>
      </div>
    </section>
  );
}
