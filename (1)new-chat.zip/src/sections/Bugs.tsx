import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Bug, CheckCircle2, Eye, Skull, Wrench } from "lucide-react";
import { BUGS } from "@/formula";
import { Chip, Reveal, SectionHead } from "@/components/ui";
import { cn } from "@/utils/cn";

export default function Bugs() {
  const [i, setI] = useState(0);
  const cur = BUGS[i];

  return (
    <section id="bugs" className="relative overflow-hidden py-20 lg:py-28">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(70%_40%_at_20%_0%,rgba(255,107,74,.1),transparent_60%)]" />
      <div className="relative mx-auto w-full max-w-[1400px] px-4 lg:px-8">
        <SectionHead
          index="۰۵"
          kicker="قاتلانِ سایت سه‌بعدی"
          en="FORENSICS · 8 CAUSES OF DEATH"
          title={
            <>
              سایت‌های سه‌بعدی نه از <span className="text-rust">قشنگی</span>، که از
              <span className="text-jade"> بی‌نظمی</span> می‌میرند
            </>
          }
          lead="هشت مرگِ پرتکرار، با علت و درمان. یک AI که این جدول را داشته باشد، به‌جای «ساختن»، اول «زنده‌ماندن» را تضمین می‌کند."
        />

        <div className="mt-10 grid gap-5 lg:mt-14 lg:grid-cols-[1fr_1.1fr] lg:gap-8">
          {/* لیستِ پرونده‌ها */}
          <div className="space-y-2">
            {BUGS.map((b, idx) => (
              <Reveal key={b.id} delay={Math.min(idx * 0.04, 0.28)}>
                <button
                  onMouseEnter={() => setI(idx)}
                  onClick={() => setI(idx)}
                  className={cn(
                    "group flex w-full items-center gap-3 rounded-2xl border px-3.5 py-3 text-start transition-all duration-350 md:px-4",
                    idx === i
                      ? "-translate-y-0.5 border-rust/45 bg-rust/[0.07] shadow-glow"
                      : "border-mist/10 bg-abyss/25 hover:border-mist/25"
                  )}
                >
                  <span
                    className={cn(
                      "grid h-8 w-8 shrink-0 place-items-center rounded-lg border font-mono text-[11px] transition-colors duration-300",
                      idx === i ? "border-rust/60 bg-rust/15 text-rust" : "border-mist/15 text-mist/50"
                    )}
                  >
                    <Skull size={14} />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-[13.5px] font-bold text-sand md:text-[15px]">
                      {b.symptom}
                    </span>
                    <span className="mt-0.5 block truncate font-mono text-[9.5px] tracking-[0.14em] text-mist/40">
                      {b.id.toUpperCase()} · FATAL
                    </span>
                  </span>
                  <Eye
                    size={15}
                    className={cn("shrink-0 transition-colors duration-300", idx === i ? "text-amber" : "text-mist/25")}
                  />
                </button>
              </Reveal>
            ))}
          </div>

          {/* پرونده */}
          <Reveal delay={0.1}>
            <div className="[perspective:1300px] lg:sticky lg:top-24">
              <AnimatePresence mode="wait">
                <motion.article
                  key={cur.id}
                  initial={{ opacity: 0, rotateY: 12, y: 18 }}
                  animate={{ opacity: 1, rotateY: 0, y: 0 }}
                  exit={{ opacity: 0, rotateY: -12, y: -14 }}
                  transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
                  style={{ transformStyle: "preserve-3d" }}
                  className="panel relative overflow-hidden rounded-3xl p-5 md:p-7"
                >
                  <div className="pointer-events-none absolute -left-16 -top-16 h-48 w-48 rounded-full bg-rust/12 blur-2xl" />
                  <div className="mb-5 flex items-center justify-between">
                    <Chip tone="rust">
                      <Bug size={11} className="ml-1 inline" /> CASE {cur.id.toUpperCase()}
                    </Chip>
                    <span className="font-mono text-[9.5px] tracking-[0.2em] text-mist/40">POST-MORTEM</span>
                  </div>

                  <h3 className="text-balance text-[19px] font-black leading-snug text-sand md:text-[26px]">
                    {cur.symptom}
                  </h3>

                  <dl className="mt-6 space-y-4">
                    <div className="rounded-2xl border border-mist/12 bg-abyss/45 p-4">
                      <dt className="mb-1.5 flex items-center gap-2 font-mono text-[10px] tracking-[0.2em] text-rust/85">
                        <Skull size={13} /> CAUSE · علتِ مرگ
                      </dt>
                      <dd className="text-[13.5px] leading-7 text-mist/80">{cur.cause}</dd>
                    </div>
                    <div className="rounded-2xl border border-jade/28 bg-jade/[0.06] p-4">
                      <dt className="mb-1.5 flex items-center gap-2 font-mono text-[10px] tracking-[0.2em] text-jade">
                        <Wrench size={13} /> FIX · درمان
                      </dt>
                      <dd className="text-[13.5px] leading-7 text-sand/90">{cur.fix}</dd>
                    </div>
                  </dl>

                  <div className="mt-6 flex items-center gap-2 border-t border-mist/10 pt-4">
                    <CheckCircle2 size={15} className="text-jade" />
                    <p className="text-[12px] text-mist/60">
                      اگر هر ۸ پرونده بسته شد، «سایت سه‌بعدیِ بدون باگ» دیگر شانس نیست؛ نتیجه است.
                    </p>
                  </div>
                </motion.article>
              </AnimatePresence>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
