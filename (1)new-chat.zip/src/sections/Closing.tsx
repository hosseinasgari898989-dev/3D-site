import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowUp, BookOpen, Code2, Heart, Plus, Send } from "lucide-react";
import { FAQ, FORMULA_CORE, FORMULA_LINES } from "@/formula";
import { Reveal, SectionHead } from "@/components/ui";
import { cn } from "@/utils/cn";

function Faq() {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <section id="faq" className="relative mx-auto w-full max-w-[1400px] px-4 py-20 lg:px-8 lg:py-28">
      <div className="grid gap-10 lg:grid-cols-[0.85fr_1.15fr] lg:gap-16">
        <div>
          <SectionHead
            index="۰۸"
            kicker="پرسش‌هایِ تلخ"
            en="OBJECTIONS · ANSWERED"
            title={
              <>
                سه‌بعدی، <span className="text-rust">بدون</span> قربانی کردنِ اسکرول؟
              </>
            }
            lead="شش پرسشی که هر بار باعث می‌شود پروژه‌ی سه‌بعدی نصفه بماند. جواب‌ها قانون‌اند، نه نظر."
          />
          <Reveal delay={0.2}>
            <div className="mt-8 panel rounded-2xl p-4">
              <p className="font-mono text-[10px] tracking-[0.2em] text-amber/80">REMINDER</p>
              <p className="mt-2 text-[13px] leading-7 text-mist/75">
                اگر مجبوری بین «خفن» و «سالم» یکی را انتخاب کنی، فرمول می‌گوید: <b className="text-sand">سالم</b>. یک
                صحنه‌ی ساده‌ی ۶۰fps بهتر از دو صحنه‌ی زیبارو ولی کرش‌کننده است.
              </p>
            </div>
          </Reveal>
        </div>

        <div className="space-y-2.5">
          {FAQ.map((f, i) => {
            const on = open === i;
            return (
              <Reveal key={f.q} delay={Math.min(i * 0.05, 0.3)}>
                <div
                  className={cn(
                    "panel overflow-hidden rounded-2xl transition-colors duration-400",
                    on ? "border-amber/30" : "hover:border-mist/25"
                  )}
                >
                  <button
                    onClick={() => setOpen(on ? null : i)}
                    aria-expanded={on}
                    className="flex w-full items-center gap-4 px-4 py-4 text-start md:px-5"
                  >
                    <span className="font-mono text-[11px] text-jade/70">{String(i + 1).padStart(2, "0")}</span>
                    <span className="flex-1 text-[14px] font-bold leading-6 text-sand md:text-[16px]">{f.q}</span>
                    <span
                      className={cn(
                        "grid h-7 w-7 shrink-0 place-items-center rounded-full border transition-all duration-400",
                        on ? "rotate-135 border-amber/50 bg-amber/12 text-amber" : "border-mist/20 text-mist/55"
                      )}
                    >
                      <Plus size={14} />
                    </span>
                  </button>
                  <AnimatePresence initial={false}>
                    {on && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.38, ease: [0.16, 1, 0.3, 1] }}
                        className="overflow-hidden"
                      >
                        <p className="border-t border-mist/10 px-4 py-4 text-[13px] leading-8 text-mist/80 md:px-5">
                          {f.a}
                        </p>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}

function Footer({ onOpenSource }: { onOpenSource: () => void }) {
  return (
    <footer className="relative overflow-hidden border-t border-mist/10">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(90%_70%_at_50%_120%,rgba(255,179,71,.16),transparent_60%)]" />
      <div className="relative mx-auto w-full max-w-[1400px] px-4 py-16 lg:px-8 lg:py-20">
        {/* فرمولِ بزرگ */}
        <Reveal>
          <div className="[perspective:1200px]">
            <p className="text-balance font-display text-[clamp(1.35rem,4.4vw,2.9rem)] font-bold leading-[1.25] tracking-tight text-sand">
              <span className="text-amber">BUGFREE_3D</span> = ( SCENE × DEPTH ) + ( SCROLL × MOTION ) +{" "}
              <span className="text-jade">( RULES ÷ COMPLEXITY )</span>
            </p>
            <p dir="ltr" className="mt-3 font-mono text-[10.5px] tracking-[0.16em] text-mist/45">
              {FORMULA_CORE} · v4.0 · copy freely, ship evidence
            </p>
          </div>
        </Reveal>

        <div className="mt-12 grid gap-10 lg:grid-cols-[1.2fr_1fr_1fr]">
          {/* اجزای فرمول */}
          <div>
            <p className="mb-4 font-mono text-[10px] tracking-[0.24em] text-jade/75">FORMULA PARTS</p>
            <ul className="space-y-2.5">
              {FORMULA_LINES.map((l, i) => (
                <Reveal key={l.key} delay={i * 0.04}>
                  <li className="group flex items-start gap-3 text-[12.5px] leading-6 text-mist/70 transition-colors hover:text-sand">
                    <span className="mt-0.5 h-1.5 w-1.5 shrink-0 rounded-full bg-amber/70 transition-transform duration-300 group-hover:scale-150" />
                    <span>
                      <b className="font-mono text-[11px] text-sand">{l.key}</b> — {l.fa}
                    </span>
                  </li>
                </Reveal>
              ))}
            </ul>
          </div>

          {/* مسیرِ استفاده */}
          <div>
            <p className="mb-4 font-mono text-[10px] tracking-[0.24em] text-jade/75">HOW TO USE THIS FORMULA</p>
            <ol className="space-y-3">
              {[
                { t: "پرامپت مادر را کپی کن", d: "بخشِ PROMPTS · نسخه‌ی React+Three" },
                { t: "به AI بده", d: "ChatGPT / Claude / Gemini / Cursor" },
                { t: "چک‌لیست را بخواه", d: "۱۰ موردِ ممیزی + گزارش" },
                { t: "روی موبایل تست کن", d: "اگر لرزید، فرمول را دوباره بچسبان" },
              ].map((s, i) => (
                <li key={s.t} className="flex gap-3">
                  <span className="grid h-6 w-6 shrink-0 place-items-center rounded-lg border border-mist/15 font-mono text-[10px] text-amber">
                    {fa(i + 1)}
                  </span>
                  <span>
                    <span className="block text-[13px] font-bold text-sand">{s.t}</span>
                    <span className="block text-[11.5px] text-mist/55">{s.d}</span>
                  </span>
                </li>
              ))}
            </ol>
          </div>

          {/* اقدام */}
          <div className="flex flex-col gap-3">
            <p className="mb-1 font-mono text-[10px] tracking-[0.24em] text-jade/75">SHIP IT</p>
            <a
              href="#prompts"
              className="group flex items-center justify-between gap-3 rounded-2xl bg-amber px-4 py-3.5 text-[13.5px] font-black text-ink transition-transform duration-300 hover:scale-[1.02] active:scale-95"
            >
              کپیِ پرامپتِ مادر
              <Send size={16} className="transition-transform duration-300 group-hover:-translate-x-1 group-hover:-translate-y-0.5" />
            </a>
            <button
              onClick={onOpenSource}
              className="flex items-center justify-between gap-3 rounded-2xl border border-mist/18 px-4 py-3.5 text-[13.5px] font-bold text-sand transition-colors duration-300 hover:border-jade/45 hover:text-jade"
            >
              فرمولِ پشتِ کد
              <Code2 size={16} />
            </button>
            <a
              href="https://threejs.org/docs/"
              target="_blank"
              rel="noreferrer noopener"
              className="flex items-center justify-between gap-3 rounded-2xl border border-mist/18 px-4 py-3.5 text-[13.5px] font-bold text-sand transition-colors duration-300 hover:border-sky/45 hover:text-sky"
            >
              مرجعِ رسمی Three.js
              <BookOpen size={16} />
            </a>
            <p className="mt-1 font-mono text-[10px] leading-5 text-mist/40">
              میان‌بُر: <span className="rounded border border-mist/20 px-1 py-0.5 text-sand/70">Ctrl</span>+
              <span className="rounded border border-mist/20 px-1 py-0.5 text-sand/70">Shift</span>+
              <span className="rounded border border-mist/20 px-1 py-0.5 text-sand/70">0</span>
            </p>
          </div>
        </div>

        <div className="mt-14 flex flex-col items-center justify-between gap-4 border-t border-mist/10 pt-6 md:flex-row">
          <p className="flex items-center gap-2 text-[11.5px] text-mist/50">
            ساخته‌شده با <Heart size={12} className="text-rust" /> برایِ اینکه یک بار بنویسی و هر جا ببری — بدونِ باگ
          </p>
          <div className="flex items-center gap-4 font-mono text-[10px] tracking-[0.16em] text-mist/40">
            <span>THREE · R3F</span>
            <span className="hidden h-3 w-px bg-mist/20 sm:block" />
            <span>TAILWIND 4</span>
            <span className="hidden h-3 w-px bg-mist/20 sm:block" />
            <span>MOTION</span>
          </div>
          <button
            onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
            className="group flex items-center gap-2 rounded-xl border border-mist/18 px-3 py-2 text-[12px] text-mist/70 transition-colors hover:border-amber/50 hover:text-amber"
          >
            بازگشت به بالا
            <span className="grid h-6 w-6 place-items-center rounded-lg bg-mist/10 transition-transform duration-500 group-hover:[transform:rotateX(360deg)]">
              <ArrowUp size={13} />
            </span>
          </button>
        </div>
      </div>
    </footer>
  );
}

const fa = (n: number) => String(n).replace(/\d/g, (d) => "۰۱۲۳۴۵۶۷۸۹"[+d]);

export default function Closing({ onOpenSource }: { onOpenSource: () => void }) {
  return (
    <>
      <Faq />
      <Footer onOpenSource={onOpenSource} />
    </>
  );
}
