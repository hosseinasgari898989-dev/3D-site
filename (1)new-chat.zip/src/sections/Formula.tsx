import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { AlertTriangle, ChevronDown, Copy, Sparkles } from "lucide-react";
import { FORMULA_CORE, STEPS } from "@/formula";
import { Chip, CodeBlock, Reveal, SectionHead } from "@/components/ui";
import { cn } from "@/utils/cn";

const TERMS = [
  { sym: "SCENE", fa: "یک بومِ WebGL", tone: "text-sky" },
  { sym: "×", op: true },
  { sym: "DEPTH", fa: "سه لایه‌ی عمق", tone: "text-jade" },
  { sym: "+", op: true },
  { sym: "SCROLL", fa: "اسکرول → دوربین", tone: "text-amber" },
  { sym: "×", op: true },
  { sym: "MOTION", fa: "حرکتِ زمان‌محور", tone: "text-rust" },
  { sym: "+", op: true },
  { sym: "RULES", fa: "ده قانونِ ایمنی", tone: "text-jade" },
  { sym: "÷", op: true },
  { sym: "COMPLEXITY", fa: "حذفِ فیچرِ اضافه", tone: "text-amber" },
];

function EquationTiles() {
  const [on, setOn] = useState<string | null>(null);
  return (
    <div className="panel rounded-3xl p-4 md:p-6">
      <div className="mb-4 flex items-center justify-between">
        <span className="font-mono text-[10px] tracking-[0.26em] text-jade/75">FACTOR VIEW · لمس/هاور کن</span>
        <span className="hidden font-mono text-[10px] text-mist/45 md:block">{FORMULA_CORE}</span>
      </div>
      <div className="flex flex-wrap items-stretch gap-2.5 [perspective:1000px]">
        {TERMS.map((t, i) =>
          t.op ? (
            <div key={i} className="grid w-6 place-items-center font-display text-xl text-mist/40 md:w-8 md:text-2xl">
              {t.sym}
            </div>
          ) : (
            <button
              key={t.sym}
              onPointerEnter={() => setOn(t.sym)}
              onPointerLeave={() => setOn((v) => (v === t.sym ? null : v))}
              onClick={() => setOn((v) => (v === t.sym ? null : t.sym))}
              className="preserve-3d group relative min-h-[64px] flex-1 rounded-2xl border border-mist/12 bg-abyss/45 transition-transform duration-500 ease-out hover:[transform:rotateX(76deg)]"
              style={{ transformOrigin: "center bottom" }}
            >
              <span className="flex h-full w-full flex-col items-center justify-center gap-1 backface-hidden px-2">
                <span className={cn("font-display text-[12.5px] font-bold tracking-tight md:text-[15px]", t.tone)}>
                  {t.sym}
                </span>
                <span className="text-[10.5px] text-mist/50 md:text-[11.5px]">{t.fa}</span>
              </span>
              <span
                className="absolute inset-0 grid place-items-center rounded-2xl bg-jade/12 px-2 text-center text-[11px] font-bold text-sand opacity-0 transition-opacity duration-300 group-hover:opacity-100"
                style={{ transform: "rotateX(90deg) translateZ(32px)", backfaceVisibility: "hidden" }}
              >
                {i === 0 ? "WebGL فقط برای قهرمان" : "متن در DOM، نه در canvas"}
              </span>
            </button>
          )
        )}
      </div>
      <AnimatePresence mode="wait">
        {on && (
          <motion.p
            key={on}
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            className="mt-4 rounded-xl border border-amber/25 bg-amber/8 px-3.5 py-2.5 text-[12.5px] text-amber/95"
          >
            <b className="font-mono text-[11px]">{on}</b> —{" "}
            {TERMS.find((t) => t.sym === on)?.fa} · این ضریب را کم کنی، سایت سه‌بعدی «قشنگ» می‌ماند ولی می‌شکند.
          </motion.p>
        )}
      </AnimatePresence>
    </div>
  );
}

export default function Formula() {
  const [open, setOpen] = useState<string>("۰۱");

  return (
    <section id="formula" className="relative mx-auto w-full max-w-[1400px] px-4 py-20 lg:px-8 lg:py-28">
      <SectionHead
        index="۰۱"
        kicker="ده قانونِ بنیادی"
        en="THE 10 RULES · COPY-PASTE READY FOR ANY AI"
        title={
          <>
            فرمول را مثلِ <span className="text-amber">قرارداد</span> به AI بده،
            <br className="hidden md:block" /> نه مثلِ سلیقه
          </>
        }
        lead={
          <>
            هر مرحله یک <b className="text-sand">کدِ مرجع</b> و یک <b className="text-rust">قاتلِ باگ</b> دارد. اگر یک
            هوش مصنوعی این ده بند را مو‌به‌مو اجرا کند، خروجی‌اش سه‌بعدیِ بدون‌باگ است — چون «سلیقه» حذف شده و
            «الزام» جايش را گرفته.
          </>
        }
      />

      <Reveal className="mt-10 lg:mt-12">
        <EquationTiles />
      </Reveal>

      <div className="mt-10 grid gap-4 lg:mt-14 lg:gap-5">
        {STEPS.map((s, i) => {
          const isOpen = open === s.n;
          return (
            <Reveal key={s.n} delay={Math.min(i * 0.04, 0.3)}>
              <article
                className={cn(
                  "panel relative overflow-hidden rounded-2xl transition-colors duration-400",
                  isOpen ? "border-jade/35 bg-jade/[0.045]" : "hover:border-mist/25"
                )}
              >
                <span
                  className={cn(
                    "absolute inset-y-0 right-0 w-[3px] transition-all duration-500",
                    isOpen ? "bg-linear-to-b from-amber via-jade to-sky" : "bg-mist/10"
                  )}
                />
                <button
                  onClick={() => setOpen(isOpen ? "" : s.n)}
                  className="flex w-full items-start gap-4 px-4 py-4 text-start md:gap-6 md:px-6 md:py-5"
                  aria-expanded={isOpen}
                >
                  <span
                    className={cn(
                      "mt-0.5 shrink-0 font-display text-2xl font-bold leading-none transition-colors duration-400 md:text-[34px]",
                      isOpen ? "text-amber" : "text-mist/35"
                    )}
                  >
                    {s.n}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="flex flex-wrap items-center gap-x-3 gap-y-1">
                      <h3 className="text-[16px] font-black leading-snug text-sand md:text-[20px]">{s.title}</h3>
                      <span className="font-mono text-[9.5px] tracking-[0.2em] text-jade/70">{s.en}</span>
                    </span>
                    <span className="mt-2 block text-[13px] leading-7 text-mist/75 md:text-[14px]">{s.body}</span>
                  </span>
                  <span
                    className={cn(
                      "mt-1 grid h-8 w-8 shrink-0 place-items-center rounded-full border transition-all duration-400",
                      isOpen ? "rotate-180 border-jade/50 bg-jade/15 text-jade" : "border-mist/18 text-mist/55"
                    )}
                  >
                    <ChevronDown size={15} />
                  </span>
                </button>

                <AnimatePresence initial={false}>
                  {isOpen && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.42, ease: [0.16, 1, 0.3, 1] }}
                      className="overflow-hidden"
                    >
                      <div className="grid gap-4 px-4 pb-5 md:grid-cols-[1.15fr_1fr] md:px-6 md:pb-6 lg:gap-6">
                        <CodeBlock code={s.code} filename={`rule-${i + 1}.snippet`} className="animate-none" />
                        <div className="flex flex-col gap-3">
                          <div className="rounded-2xl border border-rust/25 bg-rust/[0.06] p-4">
                            <p className="mb-2 flex items-center gap-2 font-mono text-[10px] tracking-[0.2em] text-rust/85">
                              <AlertTriangle size={13} /> ANTI-PATTERN
                            </p>
                            <p className="text-[13px] leading-7 text-sand/85">{s.fails}</p>
                          </div>
                          <div className="flex flex-wrap items-center gap-2">
                            <Chip tone="jade">قانون {s.n}</Chip>
                            <button
                              onClick={() => {
                                const txt = `قانون ${s.n} — ${s.title} (${s.en})\n\n${s.body}\n\nمرجع:\n${s.code}\n\nهشدار: ${s.fails}`;
                                navigator.clipboard?.writeText(txt).catch(() => undefined);
                              }}
                              className="ms-auto flex items-center gap-1.5 rounded-xl border border-mist/18 px-3 py-1.5 font-mono text-[10.5px] text-mist/70 transition-colors hover:border-amber/50 hover:text-amber"
                            >
                              <Copy size={12} /> کپیِ این بند
                            </button>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </article>
            </Reveal>
          );
        })}
      </div>

      <Reveal className="mt-10">
        <div className="flex flex-col items-start gap-3 rounded-3xl border border-jade/25 bg-linear-to-l from-jade/10 via-transparent to-amber/10 p-5 md:flex-row md:items-center md:justify-between md:p-6">
          <p className="flex items-center gap-3 text-[14px] leading-7 text-sand/90">
            <Sparkles className="shrink-0 text-amber" size={19} />
            <span>
              این ده بند را با «پرامپت مادر» ادغام کن: پرامپت، همان فرمول است در قالبِ دستورِ قابل‌اجرا برای هر AI.
            </span>
          </p>
          <a
            href="#prompts"
            className="shrink-0 rounded-xl bg-sand px-5 py-2.5 text-[13.5px] font-black text-ink transition-transform duration-300 hover:scale-[1.04] active:scale-95"
          >
            رفتن به پرامپت‌ها ↓
          </a>
        </div>
      </Reveal>
    </section>
  );
}
