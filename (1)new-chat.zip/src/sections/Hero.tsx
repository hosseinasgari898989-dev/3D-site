import { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { ArrowDown, Move3d, Radio, Zap } from "lucide-react";
import { DEFAULT_PARAMS, Scene3D } from "@/three/Scene3D";
import { FORMULA_CORE, FORMULA_LINES, STATS } from "@/formula";
import { Chip, TiltCard } from "@/components/ui";

export default function Hero() {
  const ref = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const copyY = useTransform(scrollYProgress, [0, 1], [0, 90]);
  const copyOp = useTransform(scrollYProgress, [0, 0.75], [1, 0]);
  const sceneScale = useTransform(scrollYProgress, [0, 1], [1, 0.82]);
  const markY = useTransform(scrollYProgress, [0, 1], [0, -70]);

  return (
    <section id="hero" ref={ref} className="relative isolate min-h-[100svh] overflow-hidden pt-16 md:pt-[70px]">
      {/* ══ WebGL ══ */}
      <motion.div style={{ scale: sceneScale }} className="absolute inset-0 z-0">
        <Scene3D params={DEFAULT_PARAMS} className="h-full w-full" />
      </motion.div>

      {/* ══ عمق‌دهیِ CSS ══ */}
      <div className="pointer-events-none absolute inset-0 z-[1]">
        <div className="grid-floor absolute inset-x-0 bottom-[-12%] h-[52vh] [transform:perspective(760px)_rotateX(66deg)] opacity-70" />
        <div className="absolute inset-0 bg-[radial-gradient(85%_60%_at_50%_120%,rgba(4,20,27,.96),transparent_65%)]" />
        <div className="absolute inset-y-0 right-0 w-2/3 bg-linear-to-l from-ink/85 via-ink/25 to-transparent md:w-1/2" />
        <motion.span
          style={{ y: markY }}
          className="outline-text absolute left-[-2vw] top-[16vh] hidden select-none font-display text-[19vw] font-bold leading-none tracking-tighter lg:block"
        >
          DEPTH
        </motion.span>
      </div>

      {/* ══ محتوای قهرمان — چپ‌چینِ راست‌محور، نه تریوی وسط ══ */}
      <div className="relative z-10 mx-auto flex min-h-[calc(100svh-4rem)] w-full max-w-[1400px] flex-col justify-between gap-8 px-4 pb-8 pt-10 lg:px-8 lg:pb-12 lg:pt-16">
        <div className="grid items-end gap-10 lg:grid-cols-12">
          <motion.div style={{ y: copyY, opacity: copyOp }} className="lg:col-span-7 xl:col-span-6">
            <motion.div
              initial={{ opacity: 0, x: 26 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
              className="mb-6 flex flex-wrap items-center gap-2"
            >
              <Chip tone="amber">
                <Radio size={11} className="ml-1 inline" /> نسخه ۴.۰ · آماده‌ی کپی
              </Chip>
              <Chip tone="jade">React 19 · Three · Tailwind · Framer</Chip>
              <Chip tone="sky">RTL · MOBILE-FIRST</Chip>
            </motion.div>

            <h1 className="text-balance font-sans text-[clamp(2.3rem,8.4vw,6rem)] font-black leading-[1.06] tracking-tight text-sand">
              <motion.span
                initial={{ opacity: 0, y: 34, rotateX: -22 }}
                animate={{ opacity: 1, y: 0, rotateX: 0 }}
                transition={{ duration: 0.95, delay: 0.08, ease: [0.16, 1, 0.3, 1] }}
                className="block [transform-style:preserve-3d]"
              >
                یک سایتِ
                <span className="glow-text text-amber"> کاملاً سه‌بعدی</span>
              </motion.span>
              <motion.span
                initial={{ opacity: 0, y: 34, rotateX: -22 }}
                animate={{ opacity: 1, y: 0, rotateX: 0 }}
                transition={{ duration: 0.95, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
                className="mt-2 block [transform-style:preserve-3d]"
              >
                که خودش <span className="text-jade">فرمولش</span> را حمل می‌کند
              </motion.span>
            </h1>

            <motion.p
              initial={{ opacity: 0, y: 22 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.36 }}
              className="mt-6 max-w-xl text-[15.5px] leading-8 text-mist/85 md:text-[17px]"
            >
              این صفحه فقط یک دمو نیست؛ یک <b className="text-sand">رابطِ ماشین‌به‌ماشین</b> است. فرمولِ پایین را
              کپی کن و به هر هوش مصنوعی بده — ChatGPT، Claude، Gemini، Cursor — همان اصول، همان قوانینِ ضد‌باگ،
              خروجیِ سه‌بعدیِ زنده، روی موبایل و دسکتاپ.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.46 }}
              className="mt-8 flex flex-wrap items-center gap-3"
            >
              <a
                href="#prompts"
                className="group relative flex min-h-[46px] items-center gap-2 overflow-hidden rounded-2xl bg-amber px-6 py-3 text-[14.5px] font-black text-ink transition-transform duration-300 hover:scale-[1.03] active:scale-[0.97]"
              >
                <span className="relative z-10 flex items-center gap-2">
                  <Move3d size={17} /> کپیِ فرمولِ مادر
                </span>
                <span className="absolute inset-0 z-0 translate-y-full bg-sand transition-transform duration-400 ease-out group-hover:translate-y-0" />
              </a>
              <a
                href="#playground"
                className="flex min-h-[46px] items-center gap-2 rounded-2xl border border-mist/22 px-5 py-3 text-[14px] font-bold text-sand transition-all duration-300 hover:border-jade/55 hover:bg-jade/8 hover:text-jade"
              >
                <Zap size={16} /> صحنه را زنده کنترل کن
              </a>
            </motion.div>
          </motion.div>

          {/* کارت معادله — CSS 3D واقعی */}
          <motion.div
            initial={{ opacity: 0, y: 40, rotateY: -14 }}
            animate={{ opacity: 1, y: 0, rotateY: 0 }}
            transition={{ duration: 1.05, delay: 0.3, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-5 xl:col-span-5 xl:col-start-8"
          >
            <TiltCard max={7} lift={18}>
              <div className="panel rounded-[22px] p-5 shadow-glow md:p-6">
                <div className="mb-4 flex items-center justify-between">
                  <span className="font-mono text-[10px] tracking-[0.24em] text-jade/80">THE EQUATION</span>
                  <span className="relative flex h-2.5 w-2.5">
                    <span className="absolute inset-0 animate-pulse-ring rounded-full bg-jade/60" />
                    <span className="relative h-2.5 w-2.5 rounded-full bg-jade" />
                  </span>
                </div>
                <p dir="ltr" className="rounded-xl border border-mist/10 bg-abyss/60 p-3 text-center font-mono text-[10.5px] leading-relaxed text-amber sm:text-[13px]">
                  {FORMULA_CORE}
                </p>
                <ul className="mt-4 space-y-2.5">
                  {FORMULA_LINES.map((l, i) => (
                    <motion.li
                      key={l.key}
                      initial={{ opacity: 0, x: 18 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.6 + i * 0.07, duration: 0.6 }}
                      className="flex items-start gap-3 text-[12.5px] leading-6 text-mist/80"
                    >
                      <span className="mt-0.5 shrink-0 rounded-md border border-amber/30 bg-amber/8 px-1.5 py-0.5 font-mono text-[9.5px] text-amber">
                        {l.key}
                      </span>
                      <span>{l.fa}</span>
                    </motion.li>
                  ))}
                </ul>
              </div>
            </TiltCard>
          </motion.div>
        </div>

        {/* آمار + راهنمای اسکرول */}
        <div className="flex flex-col gap-6 border-t border-mist/10 pt-6 md:flex-row md:items-center md:justify-between">
          <dl className="grid w-full grid-cols-2 gap-x-6 gap-y-4 sm:grid-cols-4 lg:max-w-3xl">
            {STATS.map((s, i) => (
              <motion.div
                key={s.en}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.8 + i * 0.09, duration: 0.6 }}
                className="flex items-baseline gap-2"
              >
                <dt className="font-display text-2xl font-bold text-sand md:text-3xl">{s.v}</dt>
                <dd className="text-[11.5px] leading-4 text-mist/60">
                  {s.k}
                  <span className="mt-0.5 block font-mono text-[8.5px] tracking-[0.2em] text-jade/60">{s.en}</span>
                </dd>
              </motion.div>
            ))}
          </dl>
          <motion.a
            href="#formula"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.3 }}
            className="group hidden items-center gap-3 self-end font-mono text-[10.5px] tracking-[0.22em] text-mist/55 transition-colors hover:text-jade md:flex"
          >
            SCROLL
            <span className="relative h-9 w-px overflow-hidden bg-mist/20">
              <span className="absolute inset-x-0 top-0 h-3 animate-[floaty_2.4s_ease-in-out_infinite] bg-jade" />
            </span>
            <ArrowDown size={13} className="transition-transform duration-300 group-hover:translate-y-1" />
          </motion.a>
        </div>
      </div>

      {/* نوار متحرکِ کلماتِ کلیدی */}
      <div className="relative z-10 border-y border-mist/10 bg-abyss/55 py-2.5">
        <div className="flex overflow-hidden [mask-image:linear-gradient(90deg,transparent,#000_12%,#000_88%,transparent)]">
          <div className="marquee-track flex shrink-0 items-center gap-8 pl-8 font-mono text-[11px] tracking-[0.2em] text-mist/45">
            {Array.from({ length: 2 }).flatMap((_, k) =>
              [
                "WEBGL",
                "◈",
                "PRESERVE-3D",
                "◈",
                "DELTA-TIME",
                "◈",
                "FRESNEL",
                "◈",
                "SCROLL DRIVER",
                "◈",
                "DISPOSE()",
                "◈",
                "DPR CLAMP",
                "◈",
                "REDUCE-MOTION",
                "◈",
                "RTL SAFE",
                "◈",
                "0 CONSOLE ERRORS",
                "◈",
              ].map((w, i) => (
                <span key={`${k}-${i}`} className={w === "◈" ? "text-amber/70" : ""}>
                  {w}
                </span>
              ))
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
