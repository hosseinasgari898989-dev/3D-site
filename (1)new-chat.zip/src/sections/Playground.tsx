import { useEffect, useMemo, useRef, useState } from "react";
import { motion } from "framer-motion";
import { Activity, Gauge, RotateCcw, SlidersHorizontal, Smartphone, Monitor } from "lucide-react";
import { DEFAULT_PARAMS, Scene3D, type SceneParams } from "@/three/Scene3D";
import { Chip, CodeBlock, Reveal, SectionHead } from "@/components/ui";
import { cn } from "@/utils/cn";

const fa = (n: number | string) => String(n).replace(/\d/g, (d) => "۰۱۲۳۴۵۶۷۸۹"[+d]);

const CONTROLS = [
  { key: "amplitude", label: "اعوجاج سطح", en: "DISPLACEMENT", min: 0, max: 1, step: 0.01 },
  { key: "frequency", label: "ریزبافت", en: "NOISE FREQ", min: 0.4, max: 3, step: 0.02 },
  { key: "speed", label: "سرعتِ زمان", en: "TIME SPEED", min: 0, max: 2, step: 0.01 },
  { key: "particles", label: "چگالی ذرات", en: "PARTICLES", min: 0, max: 1, step: 0.01 },
  { key: "metal", label: "فلز ↔ شیشه", en: "METALNESS", min: 0, max: 1, step: 0.01 },
  { key: "spin", label: "چرخشِ بنیادین", en: "BASE SPIN", min: -1, max: 1, step: 0.01 },
] as const;

const PRESETS: { name: string; hint: string; p: SceneParams }[] = [
  { name: "کریستالِ خفن", hint: "پیش‌فرضِ همین سایت", p: { ...DEFAULT_PARAMS } },
  {
    name: "مایعِ آرام",
    hint: "low freq · high amp",
    p: { amplitude: 0.62, frequency: 0.75, speed: 0.3, particles: 0.35, metal: 0.25, spin: 0.08 },
  },
  {
    name: "شیشه‌ی شکسته",
    hint: "faceted · sharp",
    p: { amplitude: 0.12, frequency: 2.6, speed: 0.9, particles: 0.8, metal: 0.95, spin: 0.55 },
  },
  {
    name: "موبایلِ کم‌مصرف",
    hint: "budget mode",
    p: { amplitude: 0.3, frequency: 1.2, speed: 0.42, particles: 0.22, metal: 0.5, spin: 0.2 },
  },
];

/** شمارنده‌ی FPS — قانون §۰۷: خارج از دید، خاموش */
function useFps(el: React.RefObject<HTMLElement | null>) {
  const [fps, setFps] = useState(60);
  useEffect(() => {
    const node = el.current;
    if (!node) return;
    let frames = 0;
    let last = performance.now();
    let raf = 0;
    let live = true;
    const loop = (t: number) => {
      frames++;
      if (t - last >= 500) {
        setFps(Math.round((frames * 1000) / (t - last)));
        frames = 0;
        last = t;
      }
      if (live) raf = requestAnimationFrame(loop);
    };
    const io =
      typeof IntersectionObserver !== "undefined"
        ? new IntersectionObserver(
            ([e]) => {
              const should = e.isIntersecting;
              if (should && !live) {
                live = true;
                last = performance.now();
                frames = 0;
                raf = requestAnimationFrame(loop);
              } else if (!should && live) {
                live = false;
                cancelAnimationFrame(raf);
              }
            },
            { threshold: 0.01 }
          )
        : null;
    io?.observe(node);
    if (!io) raf = requestAnimationFrame(loop);
    return () => {
      live = false;
      cancelAnimationFrame(raf);
      io?.disconnect();
    };
  }, [el]);
  return fps;
}

export default function Playground() {
  const [p, setP] = useState<SceneParams>(DEFAULT_PARAMS);
  const [device, setDevice] = useState<"auto" | "mobile" | "desktop">("auto");
  const panel = useRef<HTMLDivElement>(null);
  const fps = useFps(panel);

  const patch = (k: keyof SceneParams, v: number) => setP((old) => ({ ...old, [k]: v }));

  const code = useMemo(
    () => `<Scene3D
  params={{
    amplitude: ${p.amplitude.toFixed(2)},   // اعوجاج سطح (ساینز نویز)
    frequency: ${p.frequency.toFixed(2)},   // ریزبافتِ نویز
    speed:     ${p.speed.toFixed(2)},       // ضریبِ زمان — ۰ یعنی reduced-motion
    particles: ${p.particles.toFixed(2)},   // چگالی میدان ذرات (uDensity)
    metal:     ${p.metal.toFixed(2)},       // ۰ شیشه · ۱ فلز
    spin:      ${p.spin.toFixed(2)},        // چرخشِ پایه
  }}
  dpr={[1, ${device === "mobile" ? "1.5" : "2"}]}          // قانون §۰۷
  frameloop={inView ? "always" : "never"}   // قانون §۰۷ + §۰۹
  fallback="css-3d"                          // قانون §۰۳
/>`,
    [p, device]
  );

  const score = Math.round(
    100 - Math.abs(p.particles - 0.5) * 26 - Math.max(0, p.speed - 1.2) * 22 - Math.max(0, p.amplitude - 0.75) * 24
  );

  return (
    <section id="playground" className="relative overflow-hidden py-20 lg:py-28">
      <div className="pointer-events-none absolute inset-x-0 top-1/4 h-[46vh] bg-[radial-gradient(60%_50%_at_50%_50%,rgba(255,179,71,.12),transparent_70%)]" />
      <div className="relative mx-auto w-full max-w-[1400px] px-4 lg:px-8">
        <SectionHead
          index="۰۴"
          kicker="صحنه‌ی زنده تحتِ فرمانِ فرمول"
          en="LIVE SHADER PLAYGROUND · 60 FPS OR DELETE"
          title={
            <>
              هر پیچی که می‌چرخانی، یک <span className="text-sky">یونیفورمِ GLSL</span> است
            </>
          }
          lead="اینجا فرمول از حالتِ متن خارج می‌شود: اسلایدرها مستقیماً uTime/uAmp/uFreq/uMetal را در shaderMaterial عوض می‌کنند — بدون rebuild، بدون نشتی، با متریِ فریم."
        />

        <div className="mt-10 grid gap-5 lg:mt-14 lg:grid-cols-[1.06fr_1fr]">
          {/* ══ صحنه ══ */}
          <Reveal>
            <div ref={panel} className="panel relative overflow-hidden rounded-3xl">
              <div className="relative aspect-4/3 w-full sm:aspect-16/10 lg:aspect-4/3">
                <Scene3D params={p} className="absolute inset-0 h-full w-full" interactive />
                {/* HUD */}
                <div className="pointer-events-none absolute inset-0 flex flex-col justify-between p-3.5 md:p-4">
                  <div className="flex items-start justify-between gap-2">
                    <span className="rounded-lg border border-jade/30 bg-abyss/70 px-2 py-1 font-mono text-[9.5px] tracking-[0.16em] text-jade">
                      SCENE · WEBGL2
                    </span>
                    <span className="flex items-center gap-1.5 rounded-lg border border-mist/15 bg-abyss/70 px-2 py-1 font-mono text-[9.5px] text-sand">
                      <Activity size={11} className={fps > 45 ? "text-jade" : "text-rust"} />
                      {fa(fps)} FPS
                    </span>
                  </div>
                  <div className="flex items-end justify-between gap-2">
                    <span className="font-mono text-[9px] leading-4 text-mist/55">
                      drag-free parallax
                      <br />
                      pointer → damping(3.4)
                    </span>
                    <div className="rounded-lg border border-mist/15 bg-abyss/70 px-2.5 py-1 text-center">
                      <span className="block font-display text-[15px] font-bold text-amber">{fa(Math.max(0, Math.min(100, score)))}</span>
                      <span className="block font-mono text-[8px] tracking-[0.18em] text-mist/50">SAFE SCORE</span>
                    </div>
                  </div>
                </div>
                <div className="pointer-events-none absolute inset-0 rounded-3xl ring-1 ring-inset ring-mist/10" />
              </div>

              {/* کنترلِ دستگاه */}
              <div className="flex flex-wrap items-center gap-2 border-t border-mist/10 p-3.5 md:p-4">
                <span className="flex items-center gap-1.5 font-mono text-[10px] tracking-[0.16em] text-mist/55">
                  <Gauge size={12} /> VIEWPORT
                </span>
                {(
                  [
                    { id: "auto", label: "خودکار", icon: null },
                    { id: "mobile", label: "موبایل", icon: Smartphone },
                    { id: "desktop", label: "دسکتاپ", icon: Monitor },
                  ] as const
                ).map((d) => (
                  <button
                    key={d.id}
                    onClick={() => setDevice(d.id)}
                    className={cn(
                      "flex items-center gap-1.5 rounded-lg border px-2.5 py-1 text-[11.5px] font-bold transition-all duration-300",
                      device === d.id
                        ? "border-amber/55 bg-amber/12 text-amber"
                        : "border-mist/15 text-mist/60 hover:border-mist/30 hover:text-sand"
                    )}
                  >
                    {d.icon && <d.icon size={12} />} {d.label}
                  </button>
                ))}
                <button
                  onClick={() => setP(DEFAULT_PARAMS)}
                  className="ms-auto flex items-center gap-1.5 rounded-lg border border-mist/15 px-2.5 py-1 text-[11.5px] text-mist/70 transition-colors hover:border-jade/45 hover:text-jade"
                >
                  <RotateCcw size={12} /> بازنشانی
                </button>
              </div>
            </div>
          </Reveal>

          {/* ══ کنترل‌ها ══ */}
          <Reveal delay={0.08}>
            <div className="space-y-4">
              <div className="panel rounded-3xl p-4 md:p-5">
                <p className="mb-4 flex items-center gap-2 font-mono text-[10.5px] tracking-[0.2em] text-amber/85">
                  <SlidersHorizontal size={13} /> PARAM → UNIFORM
                </p>
                <div className="space-y-4">
                  {CONTROLS.map((c, i) => {
                    const v = p[c.key];
                    const pct = ((v - c.min) / (c.max - c.min)) * 100;
                    return (
                      <div key={c.key}>
                        <div className="mb-1.5 flex items-baseline justify-between gap-2">
                          <label htmlFor={`rng-${c.key}`} className="text-[13px] font-bold text-sand">
                            {c.label}
                            <span className="ms-2 font-mono text-[9px] tracking-[0.16em] text-mist/40">{c.en}</span>
                          </label>
                          <span className="font-mono text-[12px] text-jade">{fa(v.toFixed(2))}</span>
                        </div>
                        <div className="relative flex items-center">
                          <motion.span
                            className="pointer-events-none absolute inset-y-0 left-0 my-auto h-[3px] rounded-full bg-linear-to-l from-amber to-jade"
                            style={{ width: `${pct}%`, transition: "width .08s linear" }}
                          />
                          <input
                            id={`rng-${c.key}`}
                            dir="ltr"
                            type="range"
                            min={c.min}
                            max={c.max}
                            step={c.step}
                            value={v}
                            onChange={(e) => patch(c.key, parseFloat(e.target.value))}
                            className="relative z-10 h-6 cursor-grab active:cursor-grabbing"
                            style={{ accentColor: "#ffb347" }}
                          />
                        </div>
                        <motion.span
                          className="mt-1 block h-px origin-right bg-mist/10"
                          initial={{ scaleX: 0 }}
                          whileInView={{ scaleX: 1 }}
                          viewport={{ once: true }}
                          transition={{ duration: 0.5, delay: i * 0.03 }}
                        />
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="grid gap-2 sm:grid-cols-2">
                {PRESETS.map((pr) => {
                  const same = (Object.keys(DEFAULT_PARAMS) as (keyof SceneParams)[]).every(
                    (k) => Math.abs(pr.p[k] - p[k]) < 0.005
                  );
                  return (
                    <motion.button
                      key={pr.name}
                      whileTap={{ scale: 0.97 }}
                      onClick={() => setP(pr.p)}
                      className={cn(
                        "rounded-2xl border p-3 text-start transition-all duration-350 hover:-translate-y-0.5",
                        same ? "border-jade/55 bg-jade/10" : "border-mist/12 bg-abyss/40 hover:border-amber/40"
                      )}
                    >
                      <span className="block text-[13.5px] font-black text-sand">{pr.name}</span>
                      <span className="mt-0.5 block font-mono text-[9.5px] tracking-[0.14em] text-mist/45">
                        {pr.hint}
                      </span>
                    </motion.button>
                  );
                })}
              </div>

              <Chip tone="rust">
                نکته: speed = ۰ ⟶ همان رفتارِ prefers-reduced-motion؛ کاربرِ حساس به حرکت، صحنه‌ی ساکت می‌بیند
              </Chip>
            </div>
          </Reveal>
        </div>

        <Reveal className="mt-6">
          <CodeBlock code={code} filename="output → <Scene3D/> از دلِ فرمول" />
        </Reveal>
      </div>
    </section>
  );
}
