import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Bot, Braces, Check, Copy, Download, ExternalLink, FileCode2, Terminal } from "lucide-react";
import { BUGS, CHECKS, FORMULA_CORE, PROMPT_VARIANTS, STEPS } from "@/formula";
import { Chip, CodeBlock, Reveal, SectionHead } from "@/components/ui";
import { cn } from "@/utils/cn";

const fa = (s: string) => s.replace(/\d/g, (d) => "۰۱۲۳۴۵۶۷۸۹"[+d]);

export default function Prompts() {
  const [active, setActive] = useState(PROMPT_VARIANTS[0].id);
  const [copied, setCopied] = useState(false);
  const [showJson, setShowJson] = useState(false);
  const cur = useMemo(
    () => PROMPT_VARIANTS.find((v) => v.id === active) ?? PROMPT_VARIANTS[0],
    [active]
  );

  const stats = useMemo(() => {
    const chars = cur.text.length;
    return { chars, lines: cur.text.split("\n").length, words: cur.text.trim().split(/\s+/).length };
  }, [cur]);

  const json = useMemo(
    () =>
      JSON.stringify(
        {
          formula: "THE 3D FORMULA",
          version: "4.0",
          license: "public-domain",
          equation: FORMULA_CORE,
          stack: "React 19 · Vite · TypeScript · Tailwind · three/@react-three-fiber · framer-motion",
          rules: STEPS.map((s) => ({
            id: s.n,
            title: s.title,
            key: s.en,
            requires: s.body,
            reference: s.code,
            antiPattern: s.fails,
          })),
          bugKillers: BUGS.map((b) => ({ symptom: b.symptom, cause: b.cause, fix: b.fix })),
          auditChecklist: CHECKS.map((c) => ({ item: c.label, weight: c.w, why: c.hint })),
          deliveryGate: "npm run build بدون خطا · کنسول تمیز · ۶۰fps در اسکرول · بدون اسکرول افقی · تستِ موبایل",
        },
        null,
        2
      ),
    []
  );

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(cur.text);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      const ta = document.createElement("textarea");
      ta.value = cur.text;
      ta.style.position = "fixed";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.select();
      try {
        document.execCommand("copy");
        setCopied(true);
        window.setTimeout(() => setCopied(false), 2000);
      } catch {
        /* noop */
      }
      document.body.removeChild(ta);
    }
  };

  const download = () => {
    try {
      const blob = new Blob([cur.text], { type: "text/markdown;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `3d-formula-${cur.id}.md`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch {
      /* noop */
    }
  };

  return (
    <section id="prompts" className="relative mx-auto w-full max-w-[1400px] px-4 py-20 lg:px-8 lg:py-28">
      <SectionHead
        index="۰۳"
        kicker="پرامپتِ مادر + ۴ نسخه"
        en="MACHINE-TO-MACHINE INTERFACE"
        title={
          <>
            این متن را بده به هر AI؛ <span className="text-amber">همان سایت را می‌سازد</span>
          </>
        }
        lead="فرمول، بدون قالبِ دستور، فقط یک «شعار» است. شش نسخه‌ی زیر همان ده قانون‌اند با پشته‌ی فناوریِ متفاوت — React، Next.js، فقط CSS، GSAP، Three خالص و نانو. کپی کن، یا دانلود کن و در پروژه بگذار."
      />

      <Reveal className="mt-10 lg:mt-12">
        <div className="panel overflow-hidden rounded-[26px]">
          <div className="grid lg:grid-cols-[230px_1fr]">
            {/* ریلِ نسخه‌ها */}
            <div className="flex gap-1.5 overflow-x-auto border-b border-mist/10 bg-abyss/40 p-3 lg:flex-col lg:overflow-visible lg:border-b-0 lg:border-l lg:p-3.5">
              <p className="hidden items-center gap-2 px-2 pb-1 font-mono text-[9.5px] tracking-[0.2em] text-jade/70 lg:flex">
                <Terminal size={12} /> VARIANTS
              </p>
              {PROMPT_VARIANTS.map((v) => {
                const on = v.id === active;
                return (
                  <button
                    key={v.id}
                    onClick={() => setActive(v.id)}
                    className={cn(
                      "relative shrink-0 rounded-xl px-3 py-2.5 text-start text-[12.5px] font-bold transition-colors duration-300 lg:w-full",
                      on ? "text-ink" : "text-mist/70 hover:text-sand"
                    )}
                  >
                    {on && (
                      <motion.span
                        layoutId="prompt-tab"
                        transition={{ type: "spring", stiffness: 260, damping: 26 }}
                        className="absolute inset-0 rounded-xl bg-linear-to-l from-amber to-sand"
                      />
                    )}
                    <span className="relative z-10 block whitespace-nowrap lg:whitespace-normal">{v.label}</span>
                    <span
                      className={cn(
                        "relative z-10 mt-0.5 hidden font-mono text-[9px] font-normal leading-4 lg:block",
                        on ? "text-ink/60" : "text-mist/40"
                      )}
                    >
                      {v.hint}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* متنِ پرامپت */}
            <div className="flex min-w-0 flex-col">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-mist/10 px-4 py-3">
                <div className="flex items-center gap-2">
                  <FileCode2 size={14} className="text-amber" />
                  <span className="font-mono text-[11px] text-mist/65">prompt://{cur.id}.md</span>
                  <span className="hidden font-mono text-[10px] text-mist/35 sm:inline">
                    {fa(String(stats.lines))} خط · {fa(String(stats.words))} کلمه · ~{fa(String(Math.round(stats.chars / 3.4)))} توکن
                  </span>
                </div>
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={download}
                    className="flex items-center gap-1.5 rounded-lg border border-mist/18 px-2.5 py-1.5 font-mono text-[10.5px] text-mist/70 transition-colors hover:border-jade/45 hover:text-jade"
                  >
                    <Download size={12} /> دانلود .md
                  </button>
                  <button
                    onClick={copy}
                    className={cn(
                      "flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-[12px] font-black transition-all duration-300 active:scale-95",
                      copied ? "bg-jade text-ink" : "bg-amber text-ink hover:brightness-110"
                    )}
                  >
                    {copied ? <Check size={13} /> : <Copy size={13} />}
                    {copied ? "کپی شد ✓" : "کپیِ پرامپت"}
                  </button>
                </div>
              </div>

              <AnimatePresence mode="wait">
                <motion.pre
                  key={cur.id}
                  dir="rtl"
                  initial={{ opacity: 0, y: 14 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.36, ease: [0.16, 1, 0.3, 1] }}
                  className="scan-lines max-h-[54vh] min-h-[280px] overflow-auto whitespace-pre-wrap break-words p-4 text-[12.8px] leading-[1.95] text-sand/92 md:p-6"
                >
                  {cur.text}
                </motion.pre>
              </AnimatePresence>

              <div className="flex flex-wrap items-center gap-2 border-t border-mist/10 bg-abyss/45 px-4 py-3">
                <Chip tone="jade">
                  <Bot size={11} className="ml-1 inline" /> برای ChatGPT · Claude · Gemini · Cursor · Lovable
                </Chip>
                <Chip tone="amber">بهترین نتیجه: یک‌بار بفرست، بعد «ادامه بده» نگو</Chip>
                <a
                  href="https://chat.openai.com/"
                  target="_blank"
                  rel="noreferrer noopener"
                  className="ms-auto flex items-center gap-1.5 rounded-lg border border-mist/18 px-2.5 py-1.5 font-mono text-[10.5px] text-mist/60 transition-colors hover:border-sky/50 hover:text-sky"
                >
                  بازکردنِ یک چتِ تازه <ExternalLink size={11} />
                </a>
              </div>
            </div>
          </div>
        </div>
      </Reveal>

      {/* خروجیِ ماشین‌خوان */}
      <Reveal className="mt-6">
        <div className="panel rounded-3xl p-4 md:p-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <p className="flex items-center gap-2 font-mono text-[10.5px] tracking-[0.2em] text-sky/85">
              <Braces size={13} /> MACHINE READABLE · formula.json
            </p>
            <div className="flex items-center gap-1.5">
              <span className="hidden font-mono text-[10px] text-mist/45 sm:inline">
                {fa(String(json.length))} کاراکتر · برای agent / API / eval
              </span>
              <button
                onClick={() => setShowJson((v) => !v)}
                className="rounded-lg border border-mist/18 px-2.5 py-1.5 font-mono text-[10.5px] text-mist/70 transition-colors hover:border-sky/50 hover:text-sky"
              >
                {showJson ? "بستن" : "نمایشِ JSON"}
              </button>
            </div>
          </div>
          <p className="mt-2 text-[12.5px] leading-7 text-mist/70">
            همان ده قانون، در قالبِ ساختار‌یافته — برای هوش‌های مصنوعی‌ای که کد را از رویِ داده می‌سازند (agent،
            eval، fine-tune) نه از رویِ نصّ. همین را در system prompt بگذار.
          </p>
          <AnimatePresence initial={false}>
            {showJson && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
                className="overflow-hidden"
              >
                <div className="mt-4">
                  <CodeBlock code={json} filename="formula.json" lines={false} className="[&>pre]:max-h-[38vh]" />
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </Reveal>

      {/* دستورِ استفاده */}
      <div className="mt-6 grid gap-3 md:grid-cols-3">
        {[
          {
            t: "۱ · کپی و چسباندن",
            d: "پرامپت را کامل بفرست؛ هیچ پیغامِ اضافه‌ای قبلش ننویس. اولین خروجی باید ساختارِ فایل‌ها باشد، نه توضیح.",
          },
          {
            t: "۲ · یک‌بار اصلاح",
            d: "بعد از خروجی فقط بگو: «چک‌لیست ده‌ماده را اجرا و گزارش بده». اگر موردی قرمز بود، همان را بازنویسی کن.",
          },
          {
            t: "۳ · تستِ بی‌رحمانه",
            d: "روی یک موبایل واقعی باز کن؛ اگر اسکرول لرزید یا صحنه سفید شد، فرمول را دوباره در پیامِ بعد بچسبان.",
          },
        ].map((s, i) => (
          <Reveal key={s.t} delay={i * 0.07}>
            <div className="panel h-full rounded-2xl p-4 transition-transform duration-400 hover:-translate-y-1">
              <p className="font-display text-[13px] font-bold tracking-tight text-amber">{s.t}</p>
              <p className="mt-2 text-[12.5px] leading-7 text-mist/75">{s.d}</p>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
