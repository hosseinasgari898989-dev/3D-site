import { useEffect, useRef, useState } from "react";
import { motion, useScroll, useTransform, type MotionValue } from "framer-motion";
import { Contrast, Feather, Frame, Palette, Route, Sun, Wind } from "lucide-react";
import { Reveal, SectionHead } from "@/components/ui";

/* ══ THE 3D FORMULA · §۰۶ SCROLL × MOTION — اسکرول، راویِ صحنه ══ */
const CARDS = [
  {
    icon: Sun,
    t: "نورِ لبه، نه نورِ یکنواخت",
    d: "fresnel روی لبه‌ها + دو نورِ رنگیِ متقابل (کهربایی/فیروزه‌ای). صحنه «مدرن» به‌نظر می‌رسد بدون یک HDR دانلودی.",
    k: "RIM LIGHT",
  },
  {
    icon: Contrast,
    t: "کنتراستِ شدیدِ تایپو",
    d: "displayِ ۹۰۰ در برابر bodyِ ۳۰۰، با fclamp() روی اندازه. همین یک کار، «تمپلت» را از «طراحی» جدا می‌کند.",
    k: "TYPE SCALE",
  },
  {
    icon: Route,
    t: "easingِ امضا‌دار",
    d: "expo-out برای ورود، ease-outِ ۲۰۰–۶۰۰ms برای هاور. هیچ‌وقت linear، هیچ‌وقت bounce ارزان.",
    k: "EASING",
  },
  {
    icon: Frame,
    t: "لایه‌بندیِ عمق",
    d: "پس‌زمینه تار می‌ماند، میان‌بومی با اسکرول می‌چرخد، نمایان به ماوس واکنش می‌دهد. چشم، عمق را همین‌جا می‌خرد.",
    k: "PARALLAX",
  },
  {
    icon: Feather,
    t: "نویز و خطوط اسکن",
    d: "یک overlayِ svg-noise با mix-blend-mode: overlay روی کل صفحه. گران‌نماییِ چاپی، صفر هزینۀ رندر.",
    k: "TEXTURE",
  },
  {
    icon: Palette,
    t: "پالتِ سه‌رنگِ محدود",
    d: "کهربا + فیروزه + آسمانی روی زمینه‌ی نفتی. هر رنگِ چهارم، یعنی شلوغی — و شلوغی یعنی باگِ بصری.",
    k: "PALETTE",
  },
  {
    icon: Wind,
    t: "حرکتِ هدفمند",
    d: "هر انیمیشن یک کارکرد دارد: تأیید کلیک، راهنمای اسکرول، نمایش عمق. حرکتِ تزئینیِ خالص، لرزشِ اسکرول است.",
    k: "PURPOSE",
  },
];

function Face({
  card,
  index,
  radius,
  step,
  progress,
  on,
}: {
  card: (typeof CARDS)[number];
  index: number;
  radius: number;
  step: number;
  progress: MotionValue<number>;
  on: boolean;
}) {
  const opacity = useTransform(progress, [index - 1.1, index - 0.35, index + 0.35, index + 1.1], [0.18, 1, 1, 0.18]);
  const z = useTransform(progress, [index - 1, index, index + 1], [-40, 0, -40]);
  const Ico = card.icon;
  return (
    <motion.article
      style={{
        transform: `rotateY(${index * step}deg) translateZ(${radius}px)`,
        opacity: on ? opacity : 0.16,
        zIndex: 2,
      }}
      className="absolute inset-0 mx-auto w-[min(84vw,380px)] backface-hidden"
    >
      <motion.div style={{ z }} className="panel h-full rounded-[26px] p-5 shadow-glow md:p-6">
        <div className="flex items-center justify-between">
          <span className="grid h-10 w-10 place-items-center rounded-xl border border-amber/35 bg-amber/10 text-amber">
            <Ico size={18} />
          </span>
          <span className="font-mono text-[9.5px] tracking-[0.22em] text-jade/70">{card.k}</span>
        </div>
        <h3 className="mt-5 text-balance text-[19px] font-black leading-snug text-sand md:text-[22px]">{card.t}</h3>
        <p className="mt-3 text-[13px] leading-7 text-mist/80">{card.d}</p>
        <div className="mt-6 flex items-center gap-2 border-t border-mist/10 pt-4 font-mono text-[10px] text-mist/40">
          <span className="h-1.5 w-1.5 rounded-full bg-rust" />
          CARD {String(index + 1).padStart(2, "0")} / {String(CARDS.length).padStart(2, "0")}
        </div>
      </motion.div>
    </motion.article>
  );
}

export default function ScrollTheatre() {
  const wrap = useRef<HTMLDivElement>(null);
  const [radius, setRadius] = useState(360);
  const { scrollYProgress } = useScroll({ target: wrap, offset: ["start start", "end end"] });
  const rot = useTransform(scrollYProgress, [0, 1], [0, (CARDS.length - 1) * (360 / CARDS.length)]);
  const idx = useTransform(scrollYProgress, [0, 1], [0, CARDS.length - 1]);
  const dial = useTransform(scrollYProgress, [0, 1], [0, 360]);
  const [active, setActive] = useState(0);

  useEffect(() => {
    const on = () => {
      const w = window.innerWidth;
      setRadius(w < 640 ? 190 : w < 1024 ? 285 : 375);
    };
    on();
    window.addEventListener("resize", on, { passive: true });
    return () => window.removeEventListener("resize", on);
  }, []);

  useEffect(() => {
    const unsub = idx.on("change", (v) => setActive(Math.round(v as number)));
    return unsub;
  }, [idx]);

  const step = 360 / CARDS.length;

  return (
    <section id="theatre" className="relative">
      <div className="mx-auto w-full max-w-[1400px] px-4 pt-20 lg:px-8 lg:pt-28">
        <SectionHead
          index="۰۷"
          kicker="تئاترِ اسکرول"
          en="SCROLL-DRIVEN 3D CAROUSEL"
          title={
            <>
              اسکرول کن؛ کارت‌ها در <span className="text-sky">استوانه</span> می‌چرخند
            </>
          }
          lead="هفت حلقه‌ی اتصالِ «کیفیتِ گرافیک». هیچ layout‌ای در این حین بلرزد نمی‌شود: فقط rotateY روی یک container با preserve-3d — همان قانونِ §۰۶."
        />
      </div>

      <div ref={wrap} className="relative h-[280vh]">
        <div className="sticky top-0 flex h-[100svh] items-center overflow-hidden">
          <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(50%_50%_at_50%_50%,rgba(79,209,255,.11),transparent_70%)]" />
          <div className="mx-auto grid w-full max-w-[1400px] items-center gap-6 px-4 lg:grid-cols-[1fr_1.2fr] lg:px-8">
            {/* پنلِ متن */}
            <div className="order-2 max-w-md lg:order-1">
              <div className="mb-5 flex items-center gap-3">
                {CARDS.map((_, i) => (
                  <span
                    key={i}
                    className="h-1 rounded-full transition-all duration-500"
                    style={{
                      width: i === active ? 34 : 12,
                      background: i === active ? "#ffb347" : "rgba(148,188,188,.22)",
                    }}
                  />
                ))}
              </div>
              <Reveal>
                <motion.div
                  key={active}
                  initial={{ opacity: 0, y: 18 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
                >
                  <p className="font-mono text-[10.5px] tracking-[0.24em] text-jade/80">{CARDS[active].k}</p>
                  <h3 className="mt-3 text-balance text-[26px] font-black leading-tight text-sand md:text-[34px]">
                    {CARDS[active].t}
                  </h3>
                  <p className="mt-4 text-[14px] leading-8 text-mist/80">{CARDS[active].d}</p>
                </motion.div>
              </Reveal>
              <p className="mt-6 flex items-center gap-2 font-mono text-[10px] tracking-[0.18em] text-mist/40">
                <span className="inline-block h-2 w-2 animate-pulse rounded-full bg-rust" /> SCROLL = {(active + 1)} / {CARDS.length}
              </p>
            </div>

            {/* استوانه */}
            <div className="order-1 grid h-[300px] place-items-center [perspective:1500px] sm:h-[400px] lg:order-2 lg:h-[520px]">
              <motion.div
                style={{ rotateY: rot, transformStyle: "preserve-3d" }}
                className="relative h-[240px] w-[min(84vw,380px)] sm:h-[280px] lg:h-[300px]"
              >
                {CARDS.map((c, i) => (
                  <Face key={c.k} card={c} index={i} radius={radius} step={step} progress={idx} on={Math.abs(i - active) <= 1} />
                ))}
              </motion.div>
            </div>
          </div>
        </div>
      </div>

      {/* نشانگرِ چرخش */}
      <div className="pointer-events-none absolute inset-x-0 bottom-6 z-20 flex justify-center">
        <motion.div
          style={{ rotate: dial }}
          className="grid h-12 w-12 place-items-center rounded-full border border-mist/15 bg-abyss/70 font-mono text-[9px] text-jade/80 backdrop-blur-sm"
        >
          ⟳
        </motion.div>
      </div>
    </section>
  );
}
