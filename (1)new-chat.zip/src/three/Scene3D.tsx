/* ════════════════════════════════════════════════════════════════════════════
   THE 3D FORMULA · §03 SAFE BOOT + §04 MATERIAL + §05 TIME-BASED + §07 BUDGET
   صحنه‌ی WebGL قهرمان — بدون دارایی برون‌خطی، با fallback، با pause خارج از دید.
   ─────────────────────────────────────────────────────────────────────────────
   قوانینی که در همین فایل اجرا شده‌اند:
     • hasWebGL() با try/catch → اگر نشد، <CssFallback/> رندر می‌شود (نه صفحه سفید)
     • dpr = [1, mobile ? 1.5 : 2]
     • frameloop = "never" وقتی صحنه بیرونِ دید است (IntersectionObserver + cleanup)
     • همه‌ی حرکت‌ها delta-based: damp(cur, tgt, k, dt)
     • هندسه‌ها useMemo و dispose در cleanup؛ listenerها همه remove
     • prefers-reduced-motion → سرعت صفر
   ════════════════════════════════════════════════════════════════════════════ */
import {
  Component,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ErrorInfo,
  type MutableRefObject,
  type ReactNode,
} from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import * as THREE from "three";

export type SceneParams = {
  amplitude: number; // 0..1  — شدت اعوجاج سطح
  frequency: number; // 0.6..3 — ریزبافتی کریستال
  speed: number; // 0..2  — سرعت زمان
  particles: number; // 0..1  — چگالی میدان ذرات
  metal: number; // 0..1  — فلزی vs شیشه‌ای
  spin: number; // -1..1 — چرخش بنیادین
};

export const DEFAULT_PARAMS: SceneParams = {
  amplitude: 0.34,
  frequency: 1.35,
  speed: 0.62,
  particles: 0.6,
  metal: 0.72,
  spin: 0.35,
};

/* ─────────────── utilities ─────────────── */
export const damp = (cur: number, tgt: number, k: number, dt: number) =>
  cur + (tgt - cur) * (1 - Math.exp(-k * dt));

export function hasWebGL(): boolean {
  try {
    const c = document.createElement("canvas");
    return !!(
      window.WebGLRenderingContext &&
      (c.getContext("webgl2") || c.getContext("webgl") || c.getContext("experimental-webgl"))
    );
  } catch {
    return false;
  }
}

function usePrefersReducedMotion() {
  const [reduced, setReduced] = useState(false);
  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    const on = () => setReduced(mq.matches);
    on();
    mq.addEventListener?.("change", on);
    return () => mq.removeEventListener?.("change", on);
  }, []);
  return reduced;
}

function useIsMobile() {
  const [m, setM] = useState(false);
  useEffect(() => {
    const mq = window.matchMedia("(max-width: 860px), (pointer: coarse)");
    const on = () => setM(mq.matches);
    on();
    mq.addEventListener?.("change", on);
    return () => mq.removeEventListener?.("change", on);
  }, []);
  return m;
}

/** صحتِ دیده‌شدن — برای خاموش‌کردن رندر (قانون §۰۷) */
function useInView<T extends HTMLElement>(margin = "120px") {
  const ref = useRef<T | null>(null);
  const [inView, setInView] = useState(true);
  useEffect(() => {
    const el = ref.current;
    if (!el || typeof IntersectionObserver === "undefined") return;
    const io = new IntersectionObserver(
      (entries) => {
        for (const e of entries) setInView(e.isIntersecting);
      },
      { rootMargin: margin }
    );
    io.observe(el);
    return () => io.disconnect();
  }, [margin]);
  return { ref, inView };
}

/** اسکرول نرمال‌شده، بدون read در هر فریم — فقط write به یک ref (قانون §۰۶) */
export function useScrollProgress() {
  const p = useRef(0);
  useEffect(() => {
    let raf = 0;
    const read = () => {
      raf = 0;
      const max = Math.max(1, document.documentElement.scrollHeight - window.innerHeight);
      p.current = Math.min(1, Math.max(0, window.scrollY / max));
    };
    const onScroll = () => {
      if (!raf) raf = requestAnimationFrame(read);
    };
    read();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll, { passive: true });
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
      if (raf) cancelAnimationFrame(raf);
    };
  }, []);
  return p;
}

/** موقعیت ماوس نرمال‌شده روی کل صفحه (برای parallax) */
function usePointerTarget(enabled: boolean): MutableRefObject<{ x: number; y: number }> {
  const t = useRef({ x: 0, y: 0 });
  useEffect(() => {
    if (!enabled) return;
    const on = (e: PointerEvent) => {
      t.current.x = (e.clientX / window.innerWidth) * 2 - 1;
      t.current.y = (e.clientY / window.innerHeight) * 2 - 1;
    };
    const onOrient = (e: DeviceOrientationEvent) => {
      if (e.gamma == null || e.beta == null) return;
      t.current.x = Math.max(-1, Math.min(1, e.gamma / 34));
      t.current.y = Math.max(-1, Math.min(1, (e.beta - 42) / 34));
    };
    window.addEventListener("pointermove", on, { passive: true });
    window.addEventListener("deviceorientation", onOrient as EventListener);
    return () => {
      window.removeEventListener("pointermove", on);
      window.removeEventListener("deviceorientation", onOrient as EventListener);
    };
  }, [enabled]);
  return t;
}

/* ─────────────── GLSL: simplex noise 3D ─────────────── */
const SNOISE = /* glsl */ `
vec3 mod289(vec3 x){ return x - floor(x * (1.0/289.0)) * 289.0; }
vec4 mod289(vec4 x){ return x - floor(x * (1.0/289.0)) * 289.0; }
vec4 permute(vec4 x){ return mod289(((x*34.0)+1.0)*x); }
vec4 taylorInvSqrt(vec4 r){ return 1.79284291400159 - 0.85373472095314 * r; }
float snoise(vec3 v){
  const vec2 C = vec2(1.0/6.0, 1.0/3.0);
  const vec4 D = vec4(0.0, 0.5, 1.0, 2.0);
  vec3 i  = floor(v + dot(v, C.yyy));
  vec3 x0 = v - i + dot(i, C.xxx);
  vec3 g = step(x0.yzx, x0.xyz);
  vec3 l = 1.0 - g;
  vec3 i1 = min(g.xyz, l.zxy);
  vec3 i2 = max(g.xyz, l.zxy);
  vec3 x1 = x0 - i1 + C.xxx;
  vec3 x2 = x0 - i2 + C.yyy;
  vec3 x3 = x0 - D.yyy;
  i = mod289(i);
  vec4 p = permute(permute(permute(
             i.z + vec4(0.0, i1.z, i2.z, 1.0))
           + i.y + vec4(0.0, i1.y, i2.y, 1.0))
           + i.x + vec4(0.0, i1.x, i2.x, 1.0));
  float n_ = 0.142857142857;
  vec3 ns = n_ * D.wyz - D.xzx;
  vec4 j = p - 49.0 * floor(p * ns.z * ns.z);
  vec4 x_ = floor(j * ns.z);
  vec4 y_ = floor(j - 7.0 * x_);
  vec4 x = x_ *ns.x + ns.yyyy;
  vec4 y = y_ *ns.x + ns.yyyy;
  vec4 h = 1.0 - abs(x) - abs(y);
  vec4 b0 = vec4(x.xy, y.xy);
  vec4 b1 = vec4(x.zw, y.zw);
  vec4 s0 = floor(b0)*2.0 + 1.0;
  vec4 s1 = floor(b1)*2.0 + 1.0;
  vec4 sh = -step(h, vec4(0.0));
  vec4 a0 = b0.xzyw + s0.xzyw*sh.xxyy;
  vec4 a1 = b1.xzyw + s1.xzyw*sh.zzww;
  vec3 p0 = vec3(a0.xy, h.x);
  vec3 p1 = vec3(a0.zw, h.y);
  vec3 p2 = vec3(a1.xy, h.z);
  vec3 p3 = vec3(a1.zw, h.w);
  vec4 norm = taylorInvSqrt(vec4(dot(p0,p0), dot(p1,p1), dot(p2,p2), dot(p3,p3)));
  p0 *= norm.x; p1 *= norm.y; p2 *= norm.z; p3 *= norm.w;
  vec4 m = max(0.6 - vec4(dot(x0,x0), dot(x1,x1), dot(x2,x2), dot(x3,x3)), 0.0);
  m = m * m;
  return 42.0 * dot(m*m, vec4(dot(p0,x0), dot(p1,x1), dot(p2,x2), dot(p3,x3)));
}
`;

const CRYSTAL_VERT = /* glsl */ `
uniform float uTime, uAmp, uFreq, uSpeed, uTwist;
varying vec3 vView;
varying vec3 vWorld;
varying float vDisp;
${SNOISE}
void main(){
  float t = uTime * uSpeed;
  vec3 p = position;
  // چرخشِ پیچشی ملایم حول محور Y — حسِ «زنده بودن» بدون تورس‌کردن هندسه
  float ang = p.y * uTwist + t * 0.15;
  float c = cos(ang), s = sin(ang);
  p.xz = mat2(c, -s, s, c) * p.xz;

  float n1 = snoise(position * uFreq + vec3(0.0, t * 0.30, t * 0.18));
  float n2 = snoise(position * (uFreq * 2.35) + vec3(t * 0.42, 0.0, -t * 0.2));
  float d = (n1 * 0.68 + n2 * 0.28) * uAmp;
  p += normal * d;
  vDisp = d;

  vec4 mv = modelViewMatrix * vec4(p, 1.0);
  vView = -mv.xyz;
  vWorld = (modelMatrix * vec4(p, 1.0)).xyz;
  gl_Position = projectionMatrix * mv;
}
`;

const CRYSTAL_FRAG = /* glsl */ `
precision highp float;
uniform float uTime, uSpeed, uMetal, uOpacity;
uniform vec3 uColA, uColB, uColC;
varying vec3 vView;
varying vec3 vWorld;
varying float vDisp;

void main(){
  // نورمل از مشتقِ صفحه‌ای → facetsِ واقعی روی سطحِ جابه‌جا‌شده (ارزان و دقیق)
  vec3 N = normalize(cross(dFdx(vView), dFdy(vView)));
  vec3 V = normalize(vView);
  if (dot(N, V) < 0.0) N = -N;   // نورمل همیشه رو‌به‌بیننده → هیچ وجهی «واژگون» نور نمی‌گیرد
  vec3 L1 = normalize(vec3(0.55, 0.85, 0.45));
  vec3 L2 = normalize(vec3(-0.7, -0.25, 0.35));

  float fres = pow(1.0 - clamp(abs(dot(N, V)), 0.0, 1.0), 2.7);
  float d1 = clamp(dot(N, L1), 0.0, 1.0);
  float d2 = clamp(dot(N, L2), 0.0, 1.0);
  float spec = pow(clamp(dot(reflect(-L1, N), V), 0.0, 1.0), mix(18.0, 90.0, uMetal));

  // iridescence: طیفِ لبه‌ای که با عمقِ اعوجاج راه می‌رود
  float band = 0.5 + 0.5 * sin(fres * 7.0 + vDisp * 9.0 + uTime * uSpeed * 0.45);
  vec3 irid = mix(uColB, uColC, band) * 0.55 + 0.08;

  vec3 base = mix(uColA * 0.55, uColB, d1 * 0.75);
  base += uColC * d2 * 0.35;
  base += irid * (0.20 + fres * 0.85);
  base += vec3(1.0, 0.92, 0.78) * spec * mix(0.35, 1.7, uMetal);
  // رگه‌های داخلی — حسِ ضخامتِ شیشه
  float veins = smoothstep(0.72, 0.98, abs(sin(vWorld.y * 9.0 + vWorld.x * 4.0 + uTime * uSpeed * 0.6)));
  base += uColC * veins * 0.16;

  float alpha = mix(0.82, 1.0, fres * 0.6 + uMetal * 0.5) * uOpacity;
  gl_FragColor = vec4(base, alpha);
}
`;

const PART_VERT = /* glsl */ `
uniform float uTime, uSpeed, uSize, uDensity, uPr;
attribute float aSeed;
attribute float aScale;
varying float vA;
void main(){
  vec3 p = position;
  float t = uTime * uSpeed;
  float w = sin(t * 0.6 + aSeed * 6.2831);
  p.x += w * 0.32;
  p.y += cos(t * 0.45 + aSeed * 12.0) * 0.28;
  p.z += sin(t * 0.35 + aSeed * 3.0) * 0.30;
  vec4 mv = modelViewMatrix * vec4(p, 1.0);
  float alive = step(aSeed, uDensity);
  vA = alive * (0.32 + 0.68 * (0.5 + 0.5 * sin(t * 1.6 + aSeed * 20.0)));
  gl_PointSize = min(uSize * aScale * uPr / max(1.0, -mv.z), 16.0 * uPr);
  gl_Position = projectionMatrix * mv;
}
`;

const PART_FRAG = /* glsl */ `
precision highp float;
uniform vec3 uColA, uColB;
varying float vA;
void main(){
  vec2 uvp = gl_PointCoord - 0.5;
  float r = length(uvp);
  if (r > 0.5) discard;
  float a = smoothstep(0.5, 0.02, r) * vA;
  vec3 c = mix(uColA, uColB, smoothstep(0.0, 0.5, r));
  gl_FragColor = vec4(c, a * 0.85);
}
`;

/* ─────────────── meshes ─────────────── */
function Crystal({
  params,
  pointer,
  scroll,
  interactive,
  scale = 1,
}: {
  params: SceneParams;
  pointer: MutableRefObject<{ x: number; y: number }>;
  scroll: MutableRefObject<number>;
  interactive: boolean;
  scale?: number;
}) {
  const grp = useRef<THREE.Group>(null);
  const reduced = usePrefersReducedMotion();

  const geo = useMemo(() => new THREE.IcosahedronGeometry(1.28, 5), []);
  useEffect(() => () => geo.dispose(), [geo]);

  const uniforms = useMemo(
    () => ({
      uTime: { value: 0 },
      uAmp: { value: params.amplitude },
      uFreq: { value: params.frequency },
      uSpeed: { value: params.speed },
      uTwist: { value: 0.35 },
      uMetal: { value: params.metal },
      uOpacity: { value: 1 },
      uColA: { value: new THREE.Color("#062a34") },
      uColB: { value: new THREE.Color("#35d0a0") },
      uColC: { value: new THREE.Color("#ffb347") },
    }),
    // یونیفورم‌ها یک‌بار ساخته می‌شوند؛ مقادیر در effect به‌روز می‌شوند (بدون rebuild)
    []
  );

  useEffect(() => {
    uniforms.uAmp.value = params.amplitude;
    uniforms.uFreq.value = params.frequency;
    uniforms.uSpeed.value = reduced ? 0 : params.speed;
    uniforms.uMetal.value = params.metal;
    uniforms.uColB.value.set(params.metal > 0.5 ? "#35d0a0" : "#4fd1ff");
  }, [params.amplitude, params.frequency, params.speed, params.metal, reduced, uniforms]);

  useFrame((state, dt) => {
    const d = Math.min(dt, 0.05); // محافظت در برابر spike بعد از tab-switch
    uniforms.uTime.value = state.clock.elapsedTime;
    if (!grp.current) return;
    const s = reduced ? 0 : 1;
    grp.current.rotation.y = damp(
      grp.current.rotation.y,
      pointer.current.x * 0.6 * s + scroll.current * Math.PI * 1.5 + params.spin * state.clock.elapsedTime * s * 0.06,
      interactive ? 3.4 : 2.0,
      d
    );
    grp.current.rotation.x = damp(
      grp.current.rotation.x,
      -pointer.current.y * 0.34 * s + scroll.current * 0.5,
      2.6,
      d
    );
    const target = scale * (1 - scroll.current * 0.28);
    grp.current.scale.setScalar(damp(grp.current.scale.x, target, 4, d));
    grp.current.position.y = damp(
      grp.current.position.y,
      Math.sin(state.clock.elapsedTime * 0.6 * s) * 0.07 + scroll.current * 0.35,
      3,
      d
    );
  });

  return (
    <group ref={grp}>
      <mesh geometry={geo}>
        <shaderMaterial
          vertexShader={CRYSTAL_VERT}
          fragmentShader={CRYSTAL_FRAG}
          uniforms={uniforms}
          transparent
          depthWrite
        />
      </mesh>
      {/* پوسته‌ی سیمی — عمقِ دوم */}
      <mesh geometry={geo} scale={1.16}>
        <meshBasicMaterial wireframe color="#4fd1ff" transparent opacity={0.075} />
      </mesh>
    </group>
  );
}

function Particles({ params, pointer }: { params: SceneParams; pointer: MutableRefObject<{ x: number; y: number }> }) {
  const reduced = usePrefersReducedMotion();
  const isMobile = useIsMobile();
  const count = isMobile ? 1400 : 3800;
  const grp = useRef<THREE.Points>(null);

  const { geometry, material } = useMemo(() => {
    const g = new THREE.BufferGeometry();
    const pos = new Float32Array(count * 3);
    const seed = new Float32Array(count);
    const scl = new Float32Array(count);
    for (let i = 0; i < count; i++) {
      // پوسته‌ی کروی + کمی ضخامت → حسِ «مه‌ی مداری»
      const r = 2.1 + Math.pow(Math.random(), 0.6) * 6.4;
      const th = Math.random() * Math.PI * 2;
      const ph = Math.acos(2 * Math.random() - 1);
      pos[i * 3] = r * Math.sin(ph) * Math.cos(th);
      pos[i * 3 + 1] = r * Math.cos(ph) * 0.66;
      pos[i * 3 + 2] = r * Math.sin(ph) * Math.sin(th);
      seed[i] = Math.random();
      scl[i] = 0.35 + Math.random() * 1.5;
    }
    g.setAttribute("position", new THREE.BufferAttribute(pos, 3));
    g.setAttribute("aSeed", new THREE.BufferAttribute(seed, 1));
    g.setAttribute("aScale", new THREE.BufferAttribute(scl, 1));
    const m = new THREE.ShaderMaterial({
      vertexShader: PART_VERT,
      fragmentShader: PART_FRAG,
      uniforms: {
        uTime: { value: 0 },
        uSpeed: { value: 0.5 },
        uSize: { value: isMobile ? 34 : 44 },
        uDensity: { value: 0.6 },
        uPr: { value: Math.min(2, typeof window !== "undefined" ? window.devicePixelRatio || 1 : 1) },
        uColA: { value: new THREE.Color("#ffe6b8") },
        uColB: { value: new THREE.Color("#35d0a0") },
      },
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
    });
    return { geometry: g, material: m };
  }, [count, isMobile]);

  useEffect(() => {
    return () => {
      geometry.dispose();
      material.dispose();
    };
  }, [geometry, material]);

  useEffect(() => {
    material.uniforms.uDensity.value = Math.max(0.02, params.particles);
    material.uniforms.uSpeed.value = reduced ? 0 : params.speed;
  }, [params.particles, params.speed, reduced, material]);

  useFrame((state, dt) => {
    material.uniforms.uTime.value = state.clock.elapsedTime;
    if (!grp.current) return;
    const d = Math.min(dt, 0.05);
    grp.current.rotation.y = damp(grp.current.rotation.y, pointer.current.x * 0.12 + state.clock.elapsedTime * (reduced ? 0 : 0.02), 1.2, d);
  });

  return <points ref={grp} geometry={geometry} material={material} />;
}

/** تکه‌های فلزی مداری — نشان می‌دهد MeshStandardMaterial هم با همین فرمول کار می‌کند */
function Shards({ params, scroll }: { params: SceneParams; scroll: MutableRefObject<number> }) {
  const reduced = usePrefersReducedMotion();
  const grp = useRef<THREE.Group>(null);
  const items = useMemo(
    () =>
      Array.from({ length: 7 }, (_, i) => ({
        a: (i / 7) * Math.PI * 2,
        r: 2.15 + (i % 3) * 0.32,
        y: ((i % 4) - 1.5) * 0.55,
        s: 0.13 + (i % 3) * 0.055,
      })),
    []
  );
  useFrame((state) => {
    if (!grp.current) return;
    const t = reduced ? 0 : state.clock.elapsedTime * (0.16 + params.speed * 0.22);
    grp.current.rotation.y = t + scroll.current * 1.4;
    grp.current.rotation.z = Math.sin(t * 0.5) * 0.18;
  });
  return (
    <group ref={grp}>
      {items.map((it, i) => (
        <mesh
          key={i}
          position={[Math.cos(it.a) * it.r, it.y, Math.sin(it.a) * it.r]}
          scale={it.s}
          rotation={[it.a, it.a * 1.6, it.a * 0.4]}
        >
          <octahedronGeometry args={[1, 0]} />
          <meshStandardMaterial
            color={i % 3 === 0 ? "#ffb347" : i % 3 === 1 ? "#35d0a0" : "#4fd1ff"}
            metalness={0.92}
            roughness={0.22}
            emissive={new THREE.Color("#052026")}
            emissiveIntensity={0.6}
          />
        </mesh>
      ))}
    </group>
  );
}

/** حلقه‌های مداری — خطوطِ نورانی */
function Rings({ params }: { params: SceneParams }) {
  const reduced = usePrefersReducedMotion();
  const a = useRef<THREE.Group>(null);
  const b = useRef<THREE.Group>(null);
  useFrame((state) => {
    const t = state.clock.elapsedTime * (reduced ? 0 : params.speed);
    if (a.current) a.current.rotation.set(1.15, t * 0.18, 0.2);
    if (b.current) b.current.rotation.set(-0.55, -t * 0.14, 1.05);
  });
  return (
    <>
      <group ref={a}>
        <mesh scale={2.35}>
          <torusGeometry args={[1, 0.0045, 6, 160]} />
          <meshBasicMaterial color="#ffb347" transparent opacity={0.55} />
        </mesh>
      </group>
      <group ref={b}>
        <mesh scale={3.05}>
          <torusGeometry args={[1, 0.0035, 6, 160]} />
          <meshBasicMaterial color="#4fd1ff" transparent opacity={0.4} />
        </mesh>
      </group>
    </>
  );
}

function CameraRig({
  pointer,
  scroll,
  active,
}: {
  pointer: MutableRefObject<{ x: number; y: number }>;
  scroll: MutableRefObject<number>;
  active: boolean;
}) {
  const { camera } = useThree();
  useFrame((_, dt) => {
    const d = Math.min(dt, 0.05);
    const cam = camera as THREE.PerspectiveCamera;
    const tx = pointer.current.x * (active ? 0.5 : 0);
    const ty = -pointer.current.y * (active ? 0.32 : 0) + scroll.current * 0.4;
    cam.position.x = damp(cam.position.x, tx, 2.2, d);
    cam.position.y = damp(cam.position.y, ty, 2.2, d);
    cam.position.z = damp(cam.position.z, 5.6 - scroll.current * 1.15, 2, d);
    cam.lookAt(0, 0, 0);
  });
  return null;
}

/* ─────────────── public components ─────────────── */
function CssFallback({ children }: { children?: ReactNode }) {
  return (
    <div className="relative h-full w-full overflow-hidden">
      <div className="absolute inset-0 grid place-items-center [perspective:1100px]">
        <div className="relative h-52 w-52 animate-[spin_18s_linear_infinite] [transform-style:preserve-3d]">
          {Array.from({ length: 6 }).map((_, i) => (
            <div
              key={i}
              className="absolute inset-0 border border-jade/50 bg-sky/5"
              style={{ transform: `${["rotateY(0)", "rotateY(90deg)", "rotateY(180deg)", "rotateY(-90deg)", "rotateX(90deg)", "rotateX(-90deg)"][i]} translateZ(6.5rem)` }}
            />
          ))}
        </div>
      </div>
      {children}
    </div>
  );
}

/** حلقۀ خطا: اگر WebGLRenderer ساخت نتواند، فالبک می‌آید — نه صفحه‌ی سفید (قانون §۰۳) */
class SceneBoundary extends Component<{ fallback: ReactNode; children: ReactNode }, { failed: boolean }> {
  state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  componentDidCatch(err: Error, info: ErrorInfo) {
    if (typeof console !== "undefined") console.info("[3D-FORMULA] WebGL fallback engaged:", err.message, info.componentStack?.slice(0, 80));
  }
  render() {
    return this.state.failed ? this.props.fallback : this.props.children;
  }
}

export function Scene3D({
  params = DEFAULT_PARAMS,
  interactive = true,
  className = "",
  overlay,
}: {
  params?: SceneParams;
  interactive?: boolean;
  className?: string;
  overlay?: ReactNode;
}) {
  const [ok] = useState(() => hasWebGL());
  const [lost, setLost] = useState(false);
  const { ref, inView } = useInView<HTMLDivElement>();
  const pointer = usePointerTarget(interactive);
  const scroll = useScrollProgress();
  const isMobile = useIsMobile();
  const reduced = usePrefersReducedMotion();
  const running = ok && !lost && inView;

  if (!ok || lost) return <div ref={ref} className={className}>{overlay ?? <CssFallback />}</div>;

  return (
    <div
      ref={ref}
      className={className}
      data-motion={reduced ? "off" : "on"}
    >
      <SceneBoundary fallback={<CssFallback />}>
      <Canvas
        dpr={[1, isMobile ? 1.5 : 2]}
        frameloop={running ? "always" : "never"}
        gl={{
          antialias: !isMobile,
          alpha: true,
          powerPreference: "high-performance",
          preserveDrawingBuffer: false,
        }}
        camera={{ position: [0, 0, 5.6], fov: isMobile ? 58 : 45, near: 0.1, far: 60 }}
        onCreated={({ gl }) => {
          gl.setClearColor(0x000000, 0);
          gl.domElement.addEventListener("webglcontextlost", (e) => {
            e.preventDefault();
            setLost(true);
          });
        }}
      >
        <ambientLight intensity={0.55} color="#7fd7c8" />
        <pointLight position={[4, 3, 4]} intensity={28} color="#ffb347" distance={16} />
        <pointLight position={[-5, -2, 2]} intensity={20} color="#4fd1ff" distance={16} />
        <Crystal params={params} pointer={pointer} scroll={scroll} interactive={interactive} scale={isMobile ? 0.92 : 1} />
        <Rings params={params} />
        <Shards params={params} scroll={scroll} />
        <Particles params={params} pointer={pointer} />
        <CameraRig pointer={pointer} scroll={scroll} active={interactive} />
      </Canvas>
      </SceneBoundary>
      {overlay}
    </div>
  );
}
