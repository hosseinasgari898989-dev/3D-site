import { useEffect } from "react";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import Formula from "./components/Formula";
import Pillars from "./components/Pillars";
import Stack from "./components/Stack";
import Demos from "./components/Demos";
import Checklist from "./components/Checklist";
import Footer from "./components/Footer";
import { destroyLenis, initLenis } from "./lib/scroll";

/** پس‌زمینه ثابت: گرید، هاله‌های رنگی و بافت نویز */
function Backdrop() {
  return (
    <div className="pointer-events-none fixed inset-0 -z-10 overflow-hidden" aria-hidden>
      <div className="absolute inset-0 grid-bg" />
      <div className="absolute -top-48 right-[12%] h-[30rem] w-[30rem] rounded-full bg-neon/15 blur-[150px]" />
      <div className="absolute bottom-[-8rem] left-[10%] h-[26rem] w-[26rem] rounded-full bg-cyanic/10 blur-[150px]" />
      <div className="absolute left-1/2 top-1/3 h-[22rem] w-[22rem] -translate-x-1/2 rounded-full bg-roseo/[0.07] blur-[130px]" />
    </div>
  );
}

export default function App() {
  useEffect(() => {
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduced) return;
    initLenis();
    return () => destroyLenis();
  }, []);

  return (
    <div className="relative min-h-screen bg-abyss text-ink">
      <Backdrop />
      <Navbar />
      <main>
        <Hero />
        <Formula />
        <Pillars />
        <Stack />
        <Demos />
        <Checklist />
      </main>
      <Footer />
    </div>
  );
}
