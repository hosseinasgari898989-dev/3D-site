import { useState } from "react";
import { motion } from "framer-motion";
import { BadgeCheck, Check, ClipboardCheck } from "lucide-react";
import { SectionHeading } from "./SectionHeading";
import { Reveal } from "./Reveal";

const ITEMS = [
  "بدون اسکرول افقی و بدون پرش لِی‌اوت روی موبایل واقعی",
  "FPS بالای ۵۵ روی دسکتاپ و بالای ۴۰ روی موبایل میان‌رده",
  "کنسول کاملاً تمیز: صفر خطا و صفر هشدار WebGL",
  "انیمیشن‌ها با prefers-reduced-motion غیرفعال می‌شوند",
  "دسترسی کیبورد و فوکِس مرئی روی همه المان‌ها",
  "تصاویر lazy و LCP زیر ۲.۵ ثانیه",
  "fallback زیبا برای مرورگرهای بدون WebGL",
  "توقف خودکار صحنه‌های سه‌بعدی خارج از دید",
  "کنتراست حداقل AA روی همه متن‌ها",
  "عنوان، توضیحات متا و favicon اختصاصی",
  "تست‌شده از ۳۲۰ تا ۲۵۶۰ پیکسل",
  "بدون localhost، TODO یا console.log جامانده",
];

export default function Checklist() {
  const [done, setDone] = useState<Set<number>>(new Set());
  const total = ITEMS.length;
  const count = done.size;
  const percent = Math.round((count / total) * 100);
  const allDone = count === total;

  const toggle = (i: number) => {
    setDone((prev) => {
      const next = new Set(prev);
      if (next.has(i)) next.delete(i);
      else next.add(i);
      return next;
    });
  };

  return (
    <section id="checklist" className="relative mx-auto max-w-5xl scroll-mt-24 px-4 py-24 md:px-8 md:py-32">
      <SectionHeading
        kicker="آخرین سد"
        title={
          <>
            چک‌لیست <span className="text-grad">تحویل</span> — تیک بزن، منتشر کن
          </>
        }
        desc="پروژه فقط وقتی «تمام» است که هر ۱۲ آیتم تیک بخورد. همین چک‌لیست را به هوش مصنوعی هم نشان بده تا خودش را ممیزی کند."
      />

      <Reveal delay={0.1} className="mt-12">
        <div className="glass grad-ring rounded-3xl p-6 md:p-8">
          {/* نوار پیشرفت */}
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <span className={`grid h-11 w-11 place-items-center rounded-2xl transition-colors duration-500 ${allDone ? "bg-emerald-500 text-white" : "bg-white/8 text-neon-soft"}`}>
                {allDone ? <BadgeCheck size={22} /> : <ClipboardCheck size={22} />}
              </span>
              <div>
                <div className="text-sm font-black md:text-base">
                  {allDone ? "آماده انتشار است!" : `${count.toLocaleString("fa-IR")} از ${total.toLocaleString("fa-IR")} تیک خورد`}
                </div>
                <div className="text-xs text-muted">
                  {allDone ? "صفر اشکال — با خیال راحت دپلوی کن" : "روی آیتم‌ها بزن تا تیک بخورند"}
                </div>
              </div>
            </div>
            <span className="font-mono text-2xl font-extrabold text-grad md:text-3xl" dir="ltr">
              {percent.toLocaleString("fa-IR")}٪
            </span>
          </div>

          <div className="mt-4 h-2 overflow-hidden rounded-full bg-white/8">
            <motion.div
              className={`h-full rounded-full ${allDone ? "bg-gradient-to-l from-emerald-400 to-teal-400" : "bg-gradient-to-l from-neon to-cyanic"}`}
              animate={{ width: `${percent}%` }}
              transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
            />
          </div>

          {/* آیتم‌ها */}
          <div className="mt-6 grid gap-2.5 md:grid-cols-2">
            {ITEMS.map((item, i) => {
              const active = done.has(i);
              return (
                <motion.button
                  key={item}
                  onClick={() => toggle(i)}
                  whileTap={{ scale: 0.98 }}
                  className={`flex items-start gap-3 rounded-2xl border p-4 text-right transition-all duration-300 ${
                    active
                      ? "border-emerald-400/30 bg-emerald-400/10"
                      : "border-white/8 bg-white/[0.03] hover:border-neon/30 hover:bg-white/[0.05]"
                  }`}
                >
                  <span
                    className={`mt-0.5 grid h-5.5 w-5.5 shrink-0 place-items-center rounded-lg border transition-all duration-300 ${
                      active ? "border-emerald-400 bg-emerald-400 text-abyss" : "border-white/25 text-transparent"
                    }`}
                    style={{ width: 22, height: 22 }}
                  >
                    <Check size={13} strokeWidth={3.5} />
                  </span>
                  <span className={`text-[13px] font-semibold leading-6 transition-colors duration-300 ${active ? "text-emerald-200" : "text-ink/85"}`}>
                    {item}
                  </span>
                </motion.button>
              );
            })}
          </div>
        </div>
      </Reveal>
    </section>
  );
}
