import type { ReactNode } from "react";
import { Hand, MousePointerClick, Sparkles } from "lucide-react";
import { HoloDemo, JellyDemo, KnotDemo } from "./three/DemoScenes";
import { ErrorBoundary } from "./ErrorBoundary";
import { useInView } from "../hooks/useInView";
import { SectionHeading } from "./SectionHeading";
import { Reveal } from "./Reveal";

function DemoShell({
  title,
  desc,
  chip,
  chipIcon: ChipIcon,
  pointer,
  children,
}: {
  title: string;
  desc: string;
  chip: string;
  chipIcon: typeof Hand;
  pointer?: boolean;
  children: (state: { active: boolean }) => ReactNode;
}) {
  const { ref, inView } = useInView<HTMLDivElement>(0.2);
  return (
    <div ref={ref} className="glass grad-ring group flex h-full flex-col overflow-hidden rounded-3xl">
      <div className={`relative h-60 overflow-hidden md:h-72 ${pointer ? "cursor-pointer" : "cursor-grab active:cursor-grabbing"}`}>
        {children({ active: inView })}
      </div>
      <div className="flex flex-1 flex-col gap-2.5 p-5">
        <div className="flex items-center justify-between gap-3">
          <h3 className="text-base font-black md:text-lg">{title}</h3>
          <span className="inline-flex shrink-0 items-center gap-1.5 rounded-full border border-cyanic/25 bg-cyanic/10 px-3 py-1 text-[10px] font-bold text-cyanic">
            <ChipIcon size={12} />
            {chip}
          </span>
        </div>
        <p className="text-[13px] leading-7 text-muted">{desc}</p>
      </div>
    </div>
  );
}

export default function Demos() {
  return (
    <section id="demos" className="relative mx-auto max-w-7xl scroll-mt-24 px-4 py-24 md:px-8 md:py-32">
      <SectionHeading
        kicker="خروجی واقعی"
        title={
          <>
            سه دموی <span className="text-grad">زنده</span> — همین حالا تعامل کنید
          </>
        }
        desc="هر کدام از این صحنه‌ها با همان قواعد فرمول ساخته شده‌اند: dpr محدود، توقف رندر خارج از دید، dispose کامل و سپر ErrorBoundary."
      />

      <div className="mt-14 grid gap-5 md:grid-cols-3">
        <Reveal className="h-full">
          <DemoShell
            title="گره چرخان"
            desc="توروس‌نات با متریال فلزی و لایه وایرفریم نئونی؛ چرخش خودکار با damping و قابلیت درگ با ماوس و لمس."
            chip="بکشید و بچرخانید"
            chipIcon={Hand}
          >
            {({ active }) => <KnotDemo active={active} />}
          </DemoShell>
        </Reveal>

        <Reveal delay={0.1} className="h-full">
          <DemoShell
            title="ژله تعاملی"
            desc="کره‌ای با MeshWobbleMaterial که با هر کلیک فنری فشرده می‌شود و با damp نرم به حالت اول برمی‌گردد — تعامل بدون setState داخل useFrame."
            chip="کلیک کنید"
            chipIcon={MousePointerClick}
            pointer
          >
            {({ active }) => <JellyDemo active={active} />}
          </DemoShell>
        </Reveal>

        <Reveal delay={0.2} className="h-full">
          <DemoShell
            title="مکعب هولوگرافیک"
            desc="RoundedBox وایرفریم دور هسته درخشان با Float و Sparkles — نمونه‌ی «زنده بودن» صحنه بدون حتی یک خط تعامل."
            chip="خودش می‌رقصد"
            chipIcon={Sparkles}
          >
            {({ active }) => (
              <ErrorBoundary>
                <HoloDemo active={active} />
              </ErrorBoundary>
            )}
          </DemoShell>
        </Reveal>
      </div>
    </section>
  );
}
