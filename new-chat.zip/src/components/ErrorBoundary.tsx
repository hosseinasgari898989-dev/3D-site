import { Component, type ReactNode } from "react";

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
}

interface State {
  hasError: boolean;
}

/**
 * سپر ضد باگ — اگر هر صحنه سه‌بعدی خطا داد یا WebGL نبود،
 * به‌جای صفحه سفید، یک جایگزین زیبا نشان داده می‌شود.
 */
export class ErrorBoundary extends Component<Props, State> {
  state: State = { hasError: false };

  static getDerivedStateFromError(): State {
    return { hasError: true };
  }

  componentDidCatch(error: unknown) {
    console.error("[SceneGuard] خطای صحنه سه‌بعدی:", error);
  }

  render() {
    if (this.state.hasError) {
      return (
        this.props.fallback ?? (
          <div className="flex h-full w-full items-center justify-center rounded-2xl border border-white/10 bg-gradient-to-br from-neon/15 via-transparent to-cyanic/15">
            <span className="px-4 text-center text-xs leading-6 text-muted">
              مرورگر شما WebGL ندارد — نسخه جایگزین فعال است
            </span>
          </div>
        )
      );
    }
    return this.props.children;
  }
}
