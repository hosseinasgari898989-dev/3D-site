import { Boxes, Code2, ExternalLink, Heart, Layers } from "lucide-react";
import { scrollToId } from "../lib/scroll";

const NAV = [
  { id: "formula", label: "فرمول مادر" },
  { id: "pillars", label: "قوانین آهنین" },
  { id: "stack", label: "استک" },
  { id: "demos", label: "دموهای زنده" },
  { id: "checklist", label: "چک‌لیست" },
];

const RESOURCES = [
  { label: "مستندات three.js", href: "https://threejs.org/docs" },
  { label: "مستندات React Three Fiber", href: "https://r3f.docs.pmnd.rs" },
  { label: "مستندات drei", href: "https://drei.docs.pmnd.rs" },
  { label: "مستندات framer-motion", href: "https://motion.dev" },
];

export default function Footer() {
  return (
    <footer className="relative border-t border-white/5 bg-panel/60">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-l from-transparent via-neon/60 to-transparent" />
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 md:grid-cols-3 md:px-8">
        {/* برند */}
        <div>
          <div className="flex items-center gap-3">
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-neon to-cyanic text-white">
              <Boxes size={20} />
            </span>
            <span className="text-lg font-black">فرمول سه‌بُعدی</span>
          </div>
          <p className="mt-4 max-w-xs text-sm leading-7 text-muted">
            این سایت دقیقاً با همین فرمولی که می‌بینید ساخته شده — فرمولی که همیشه جواب می‌دهد:
            برای هوش مصنوعی‌ها و برای انسان‌ها.
          </p>
          <div className="mt-5 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.04] px-4 py-2 text-[11px] font-bold text-muted">
            <Heart size={13} className="text-roseo" />
            ساخته‌شده با ۱۲ فاز و صفر حدس
          </div>
        </div>

        {/* ناوبری */}
        <div>
          <h4 className="flex items-center gap-2 text-sm font-black text-ink">
            <Layers size={15} className="text-cyanic" />
            بخش‌های سایت
          </h4>
          <ul className="mt-4 flex flex-col gap-2.5">
            {NAV.map((n) => (
              <li key={n.id}>
                <button
                  onClick={() => scrollToId(n.id)}
                  className="text-sm text-muted transition-colors hover:text-neon-soft"
                >
                  {n.label}
                </button>
              </li>
            ))}
          </ul>
        </div>

        {/* منابع */}
        <div>
          <h4 className="text-sm font-black text-ink">منابع رسمی</h4>
          <ul className="mt-4 flex flex-col gap-2.5">
            {RESOURCES.map((r) => (
              <li key={r.href}>
                <a
                  href={r.href}
                  target="_blank"
                  rel="noreferrer"
                  className="group inline-flex items-center gap-1.5 text-sm text-muted transition-colors hover:text-cyanic"
                >
                  {r.label}
                  <ExternalLink size={12} className="opacity-0 transition-opacity group-hover:opacity-100" />
                </a>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="border-t border-white/5">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-3 px-4 py-5 text-[11px] text-muted md:flex-row md:px-8">
          <span>© ۲۰۲۵ فرمول سه‌بُعدی — نسخه ۲.۰</span>
          <span className="inline-flex items-center gap-2 font-mono" dir="ltr">
            <Code2 size={13} />
            React + R3F + Lenis + Tailwind
          </span>
        </div>
      </div>
    </footer>
  );
}
