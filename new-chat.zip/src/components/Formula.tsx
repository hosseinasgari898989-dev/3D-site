import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { BadgeCheck, Check, ClipboardCopy, FileText, Zap } from "lucide-react";
import { FORMULA, SHORT_PROMPT, SHORT_PROMPT_TITLE } from "../data/formula";
import { copyText } from "../lib/clipboard";
import { Reveal } from "./Reveal";
import { SectionHeading } from "./SectionHeading";

/* ---------- پارسر سبک برای رندر فرمول ---------- */
type Block = { kind: "h2" | "p"; text: string } | { kind: "list"; items: string[] };
type Phase = { index: number; title: string; blocks: Block[] };

function parseFormula(src: string): { intro: string; lede: string; phases: Phase[] } {
  const lines = src.split("\n");
  let intro = "";
  let lede = "";
  const phases: Phase[] = [];
  let current: Phase | null = null;
  let list: string[] | null = null;
  const flushList = () => {
    if (list && current) current.blocks.push({ kind: "list", items: list });
    list = null;
  };
  for (const raw of lines) {
    const line = raw.trim();
    if (!line) {
      flushList();
      continue;
    }
    if (line.startsWith("# ")) {
      intro = line.slice(2);
      continue;
    }
    if (line.startsWith("## ")) {
      flushList();
      current = { index: phases.length, title: line.slice(3), blocks: [] };
      phases.push(current);
      continue;
    }
    if (line.startsWith("- ")) {
      if (!list) list = [];
      list.push(line.slice(2));
      continue;
    }
    flushList();
    if (current) current.blocks.push({ kind: "p", text: line });
    else if (!intro) intro = line;
    else lede += (lede ? " " : "") + line;
  }
  flushList();
  return { intro: intro.trim(), lede: lede.trim(), phases };
}

function renderInline(text: string) {
  return text.split(/(\*\*[^*]+\*\*)/g).map((p, i) =>
    p.startsWith("**") && p.endsWith("**") ? (
      <strong key={i} className="font-extrabold text-ink">
        {p.slice(2, -2)}
      </strong>
    ) : (
      <span key={i}>{p}</span>
    )
  );
}

/* ---------- دکمه کپی قابل استفاده مجدد ---------- */
function CopyButton({
  text,
  label,
  copiedLabel,
  big = false,
}: {
  text: string;
  label: string;
  copiedLabel: string;
  big?: boolean;
}) {
  const [copied, setCopied] = useState(false);
  const doCopy = async () => {
    const ok = await copyText(text);
    if (ok) {
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2400);
    }
  };
  return (
    <motion.button
      onClick={doCopy}
      whileTap={{ scale: 0.96 }}
      className={`group relative inline-flex items-center justify-center gap-2.5 overflow-hidden rounded-2xl font-black text-white transition-all duration-300 ${
        big
          ? "bg-gradient-to-l from-neon via-[#6d5df0] to-cyanic px-8 py-4 text-sm shadow-[0_18px_55px_-14px_rgba(139,92,246,0.85)] hover:scale-[1.03] md:text-base"
          : "glass px-5 py-2.5 text-xs hover:border-neon/40"
      } ${copied ? "!from-emerald-500 !via-emerald-500 !to-emerald-400 !bg-gradient-to-l" : ""}`}
    >
      {copied ? <Check size={big ? 18 : 15} /> : <ClipboardCopy size={big ? 18 : 15} />}
      {copied ? copiedLabel : label}
    </motion.button>
  );
}

/* ============================================================ */
export default function Formula() {
  const { intro, lede, phases } = useMemo(() => parseFormula(FORMULA), []);

  const stats = useMemo(() => {
    const words = FORMULA.split(/\s+/).filter(Boolean).length;
    return [
      { icon: FileText, value: `${phases.length}`, label: "فاز اجرایی" },
      { icon: Zap, value: `${words.toLocaleString("fa-IR")}`, label: "واژه دستور" },
      { icon: BadgeCheck, value: "۱۰۰٪", label: "قابل کپی و اجرا" },
    ];
  }, [phases]);

  return (
    <section id="formula" className="relative mx-auto max-w-5xl scroll-mt-24 px-4 py-24 md:px-8 md:py-32">
      <SectionHeading
        kicker="دلِ ماجرا"
        title={
          <>
            فرمولِ <span className="text-grad">مادر</span> — کپی کن، بده به AI، تحویل بگیر
          </>
        }
        desc="این متن یک پرامپت مهندسی‌شده است. کلش را کپی کن و به هر هوش مصنوعی بده؛ خروجی، یک سایت سه‌بُعدی بی‌نقص خواهد بود — همان‌طور که این سایت ساخته شد."
      />

      {/* کارت آمار + کپی */}
      <Reveal delay={0.1} className="mt-12">
        <div className="glass grad-ring relative overflow-hidden rounded-3xl p-6 md:p-8">
          <div className="pointer-events-none absolute -left-20 -top-20 h-56 w-56 rounded-full bg-neon/25 blur-[90px]" />
          <div className="pointer-events-none absolute -bottom-20 -right-20 h-56 w-56 rounded-full bg-cyanic/20 blur-[90px]" />
          <div className="relative flex flex-col items-start justify-between gap-6 md:flex-row md:items-center">
            <div>
              <h3 className="text-lg font-black leading-8 md:text-xl">{intro}</h3>
              <p className="mt-2 max-w-xl text-sm leading-7 text-muted">
                {lede || "هیچ فازی را حذف نکن؛ اگر منابع محدود بود، از انتهای فهرست قربانی بده، نه از ابتدا."}
              </p>
            </div>
            <CopyButton text={FORMULA} label="کپی فرمول کامل" copiedLabel="فرمول کپی شد!" big />
          </div>
          <div className="relative mt-7 grid grid-cols-3 gap-3">
            {stats.map((s) => (
              <div key={s.label} className="flex flex-col items-center gap-1.5 rounded-2xl border border-white/5 bg-white/[0.03] px-3 py-4 text-center">
                <s.icon size={17} className="text-cyanic" />
                <span className="font-mono text-xl font-extrabold text-grad" dir="ltr">{s.value}</span>
                <span className="text-[10px] font-semibold text-muted md:text-xs">{s.label}</span>
              </div>
            ))}
          </div>
        </div>
      </Reveal>

      {/* ناوبری فازها */}
      <Reveal delay={0.15} className="mt-10">
        <div className="flex flex-wrap items-center justify-center gap-2" dir="rtl">
          {phases.map((p) => (
            <button
              key={p.index}
              onClick={() => document.getElementById(`phase-${p.index}`)?.scrollIntoView({ behavior: "smooth", block: "start" })}
              className="rounded-full border border-white/10 bg-white/[0.04] px-3.5 py-1.5 text-[11px] font-bold text-muted transition-all hover:border-neon/50 hover:bg-neon/10 hover:text-ink"
            >
              فاز {p.index.toLocaleString("fa-IR")}
            </button>
          ))}
        </div>
      </Reveal>

      {/* کارت فازها */}
      <div className="mt-10 flex flex-col gap-5">
        {phases.map((p, i) => (
          <Reveal key={p.index} delay={Math.min(i * 0.04, 0.3)}>
            <article
              id={`phase-${p.index}`}
              className="glass scroll-mt-28 rounded-3xl p-6 transition-colors duration-300 hover:border-neon/30 md:p-8"
            >
              <div className="flex items-center gap-4">
                <span
                  className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-neon to-cyanic font-mono text-lg font-extrabold text-white shadow-[0_10px_30px_-8px_rgba(139,92,246,0.7)]"
                  dir="ltr"
                >
                  {String(p.index).padStart(2, "0")}
                </span>
                <h3 className="text-lg font-extrabold leading-8 md:text-xl">{p.title}</h3>
              </div>
              <div className="mt-5 flex flex-col gap-3.5 border-r-2 border-dashed border-white/10 pr-5">
                {p.blocks.map((b, bi) =>
                  b.kind === "list" ? (
                    <ul key={bi} className="flex flex-col gap-3">
                      {b.items.map((it, ii) => (
                        <li key={ii} className="flex items-start gap-3 text-sm leading-7 text-ink/80 md:text-[15px]">
                          <span className="mt-2.5 h-2 w-2 shrink-0 rotate-45 rounded-[3px] bg-gradient-to-br from-neon to-cyanic" />
                          <span>{renderInline(it)}</span>
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p key={bi} className="text-sm font-semibold leading-7 text-neon-soft md:text-[15px]">
                      {renderInline(b.text)}
                    </p>
                  )
                )}
              </div>
            </article>
          </Reveal>
        ))}
      </div>

      {/* پرامپت سریع */}
      <Reveal delay={0.1} className="mt-14">
        <div className="glass grad-ring relative overflow-hidden rounded-3xl p-6 md:p-8">
          <div className="pointer-events-none absolute -right-16 -top-16 h-44 w-44 rounded-full bg-roseo/20 blur-[80px]" />
          <div className="relative flex flex-col items-start justify-between gap-5 md:flex-row md:items-center">
            <div>
              <span className="mb-2 inline-block rounded-full bg-roseo/15 px-3 py-1 text-[10px] font-black text-roseo">
                نسخه فشرده
              </span>
              <h3 className="text-lg font-black md:text-xl">{SHORT_PROMPT_TITLE}</h3>
              <p className="mt-1 text-sm text-muted">وقتی وقت نیست، فقط همین را بفرست — ۹۰٪ افکت، ۱۰٪ حجم.</p>
            </div>
            <CopyButton text={SHORT_PROMPT} label="کپی پرامپت سریع" copiedLabel="کپی شد!" />
          </div>
          <div className="relative mt-5 rounded-2xl border border-white/8 bg-abyss/70 p-5">
            <pre className="whitespace-pre-wrap font-vazir text-[13px] leading-8 text-ink/85" dir="rtl">
              {SHORT_PROMPT}
            </pre>
          </div>
        </div>
      </Reveal>
    </section>
  );
}
