import { motion } from "framer-motion";
import { ChevronDown, FileCode2, Play, Sparkles } from "lucide-react";
import HeroScene from "./three/HeroScene";
import { ErrorBoundary } from "./ErrorBoundary";
import { useInView } from "../hooks/useInView";
import { scrollToId } from "../lib/scroll";
import { MARQUEE_ITEMS } from "../data/formula";
import { EASE } from "./Reveal";
import type { Variants } from "framer-motion";

const STATS = [
  { value: "۱۲", label: "فاز اجرایی" },
  { value: "۶۰", label: "فریم بر ثانیه" },
  { value: "۰", label: "باگ قابل قبول" },
  { value: "۱۰۰٪", label: "ریسپانسیو" },
];

const container: Variants = {
  hidden: {},
  show: { transition: { staggerChildren: 0.12, delayChildren: 0.25 } },
};
const item: Variants = {
  hidden: { opacity: 0, y: 34 },
  show: { opacity: 1, y: 0, transition: { duration: 0.9, ease: EASE } },
};

export default function Hero() {
  const { ref, inView } = useInView<HTMLElement>(0.05);

  return (
    <section
      ref={ref}
      id="home"
      className="noise relative flex min-h-[100svh] flex-col overflow-hidden"
    >
      {/* پس‌زمینه سه‌بُعدی زنده */}
      <div className="absolute inset-0">
        <ErrorBoundary>
          <HeroScene active={inView} />
        </ErrorBoundary>
      </div>

      {/* تایپوگرافی غول‌پیکر پس‌زمینه */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-x-0 top-1/2 hidden -translate-y-1/2 select-none justify-center md:flex"
      >
        <span
          className="text-[19vw] font-black leading-none tracking-tight"
          style={{ WebkitTextStroke: "1.5px rgba(167,139,250,0.13)", color: "transparent" }}
        >
          سه‌بُعدی
        </span>
      </div>

      {/* هاله‌های رنگی */}
      <div aria-hidden className="pointer-events-none absolute -left-40 top-1/4 h-96 w-96 rounded-full bg-neon/25 blur-[130px]" />
      <div aria-hidden className="pointer-events-none absolute -right-40 bottom-1/4 h-96 w-96 rounded-full bg-cyanic/20 blur-[130px]" />

      {/* محتوا */}
      <motion.div
        variants={container}
        initial="hidden"
        animate="show"
        className="pointer-events-none relative z-10 mx-auto flex w-full max-w-5xl flex-1 flex-col items-center justify-center gap-7 px-5 pb-28 pt-36 text-center md:pt-40"
      >
        <motion.div variants={item} className="pointer-events-auto">
          <span className="glass inline-flex items-center gap-2 rounded-full px-5 py-2 text-xs font-bold text-neon-soft md:text-sm">
            <Sparkles size={15} className="text-cyanic" />
            فرمول مادر — نسخه ۲.۰
            <span className="h-1 w-1 rounded-full bg-roseo" />
            قابل کپی برای هر هوش مصنوعی
          </span>
        </motion.div>

        <motion.h1
          variants={item}
          className="max-w-4xl text-[clamp(2.4rem,7.5vw,5.4rem)] font-black leading-[1.12]"
        >
          سایتِ سه‌بُعدیِ بی‌نقص،
          <br />
          دیگر <span className="text-grad">شانس</span> نیست؛ <span className="text-grad">فرمول</span> است.
        </motion.h1>

        <motion.p
          variants={item}
          className="max-w-2xl text-sm leading-8 text-muted md:text-lg md:leading-9"
        >
          یک دستورالعمل ۱۲ فازی که هر هوش مصنوعی — یا انسان — با اجرای دقیقش به یک وب‌سایت
          سه‌بُعدیِ خیره‌کننده، روان، موبایل‌فرست و بدون باگ می‌رسد. همین سایتی که در آن
          هستید، خودش نمونه‌ی اجرای همین فرمول است.
        </motion.p>

        <motion.div variants={item} className="pointer-events-auto flex flex-wrap items-center justify-center gap-3">
          <button
            onClick={() => scrollToId("formula")}
            className="group inline-flex items-center gap-2.5 rounded-full bg-gradient-to-l from-neon to-cyanic px-7 py-3.5 text-sm font-black text-white shadow-[0_16px_50px_-12px_rgba(139,92,246,0.8)] transition-all duration-300 hover:scale-[1.04] hover:shadow-[0_20px_60px_-10px_rgba(34,211,238,0.6)] active:scale-95 md:text-base"
          >
            <FileCode2 size={18} className="transition-transform duration-300 group-hover:-translate-y-0.5" />
            دریافت فرمول کامل
          </button>
          <button
            onClick={() => scrollToId("demos")}
            className="glass inline-flex items-center gap-2.5 rounded-full px-7 py-3.5 text-sm font-black text-ink transition-all duration-300 hover:scale-[1.04] hover:border-cyanic/40 active:scale-95 md:text-base"
          >
            <Play size={17} className="text-cyanic" />
            دموهای زنده
          </button>
        </motion.div>

        {/* آمار */}
        <motion.div variants={item} className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4 md:gap-5">
          {STATS.map((s) => (
            <div key={s.label} className="glass grad-ring rounded-2xl px-6 py-4">
              <div className="font-mono text-2xl font-extrabold text-grad md:text-3xl" dir="ltr">
                {s.value}
              </div>
              <div className="mt-1 text-[11px] font-semibold text-muted md:text-xs">{s.label}</div>
            </div>
          ))}
        </motion.div>
      </motion.div>

      {/* نشانگر اسکرول */}
      <motion.button
        onClick={() => scrollToId("formula")}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.6, duration: 1 }}
        className="absolute bottom-16 left-1/2 z-10 -translate-x-1/2"
        aria-label="اسکرول به پایین"
      >
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut" }}
          className="flex flex-col items-center gap-1.5 text-muted transition-colors hover:text-ink"
        >
          <span className="text-[10px] font-bold tracking-[0.3em]">اسکرول</span>
          <ChevronDown size={18} />
        </motion.div>
      </motion.button>

      {/* نوار متحرک کلیدواژه‌ها */}
      <div className="marquee-mask absolute inset-x-0 bottom-0 z-10 border-t border-white/5 bg-abyss/60 py-3.5 backdrop-blur-md">
        <div className="marquee-track flex items-center gap-8 pl-8">
          {[...MARQUEE_ITEMS, ...MARQUEE_ITEMS].map((w, i) => (
            <span key={i} className="flex items-center gap-8 whitespace-nowrap text-xs font-bold text-muted" dir="rtl">
              {w}
              <span className="h-1.5 w-1.5 rounded-full bg-gradient-to-l from-neon to-cyanic" />
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}
