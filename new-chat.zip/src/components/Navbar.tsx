import { useEffect, useState } from "react";
import { AnimatePresence, motion, useScroll, useSpring } from "framer-motion";
import { Boxes, Check, Copy, Menu, X } from "lucide-react";
import { scrollToId } from "../lib/scroll";
import { copyText } from "../lib/clipboard";
import { FORMULA } from "../data/formula";

const LINKS = [
  { id: "formula", label: "فرمول" },
  { id: "pillars", label: "قوانین" },
  { id: "stack", label: "استک" },
  { id: "demos", label: "دموهای زنده" },
  { id: "checklist", label: "چک‌لیست" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const { scrollYProgress } = useScroll();
  const progress = useSpring(scrollYProgress, { stiffness: 90, damping: 24, mass: 0.4 });

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const go = (id: string) => {
    setOpen(false);
    scrollToId(id);
  };

  const copyAll = async () => {
    const ok = await copyText(FORMULA);
    if (ok) {
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2200);
    }
  };

  return (
    <header className="fixed inset-x-0 top-0 z-50">
      {/* نوار پیشرفت اسکرول — در RTL از راست پر می‌شود */}
      <motion.div
        className="h-[2.5px] origin-right bg-gradient-to-l from-neon via-cyanic to-roseo"
        style={{ scaleX: progress }}
      />
      <div
        className={`transition-all duration-500 ${
          scrolled ? "glass border-b border-white/5" : "bg-transparent"
        }`}
      >
        <nav className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 md:h-[72px] md:px-8">
          {/* لوگو */}
          <button
            onClick={() => go("home")}
            className="group flex items-center gap-3"
            aria-label="بازگشت به بالای صفحه"
          >
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-neon to-cyanic text-white shadow-[0_8px_30px_-6px_rgba(139,92,246,0.7)] transition-transform duration-500 group-hover:rotate-[15deg]">
              <Boxes size={20} strokeWidth={2.2} />
            </span>
            <span className="flex flex-col items-start leading-none">
              <span className="text-base font-black tracking-tight">فرمول سه‌بُعدی</span>
              <span className="mt-1 font-mono text-[9px] uppercase tracking-[0.28em] text-muted" dir="ltr">
                3D&nbsp;Formula&nbsp;v2.0
              </span>
            </span>
          </button>

          {/* لینک‌ها - دسکتاپ */}
          <div className="hidden items-center gap-1 lg:flex">
            {LINKS.map((l) => (
              <button
                key={l.id}
                onClick={() => go(l.id)}
                className="rounded-full px-4 py-2 text-sm font-semibold text-muted transition-colors hover:bg-white/5 hover:text-ink"
              >
                {l.label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={copyAll}
              className={`grad-ring hidden items-center gap-2 rounded-full px-5 py-2.5 text-sm font-bold transition-all duration-300 hover:scale-[1.03] active:scale-95 sm:inline-flex ${
                copied ? "bg-cyanic/20 text-cyanic" : "bg-white/5 text-ink"
              }`}
            >
              {copied ? <Check size={16} /> : <Copy size={16} />}
              {copied ? "کپی شد!" : "کپی فرمول"}
            </button>

            {/* منوی موبایل */}
            <button
              onClick={() => setOpen((v) => !v)}
              className="glass grid h-10 w-10 place-items-center rounded-xl text-ink lg:hidden"
              aria-label="باز و بسته کردن منو"
            >
              {open ? <X size={18} /> : <Menu size={18} />}
            </button>
          </div>
        </nav>

        {/* پنل موبایل */}
        <AnimatePresence>
          {open && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
              className="glass overflow-hidden border-b border-white/5 lg:hidden"
            >
              <div className="flex flex-col gap-1 px-4 py-4">
                {LINKS.map((l, i) => (
                  <motion.button
                    key={l.id}
                    initial={{ opacity: 0, x: 24 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.05 * i }}
                    onClick={() => go(l.id)}
                    className="rounded-xl px-4 py-3 text-right text-sm font-bold text-ink/90 transition-colors hover:bg-white/5"
                  >
                    {l.label}
                  </motion.button>
                ))}
                <button
                  onClick={() => {
                    setOpen(false);
                    copyAll();
                  }}
                  className="mt-2 inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-l from-neon to-cyanic px-4 py-3 text-sm font-black text-white"
                >
                  {copied ? <Check size={16} /> : <Copy size={16} />}
                  {copied ? "فرمول کپی شد!" : "کپی فرمول کامل"}
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </header>
  );
}
