import { motion } from "framer-motion";
import {
  Accessibility,
  ArrowDownWideNarrow,
  Bug,
  Gauge,
  MousePointerClick,
  ShieldCheck,
  Smartphone,
  Type,
} from "lucide-react";
import { SectionHeading } from "./SectionHeading";
import { Reveal } from "./Reveal";

const PILLARS = [
  {
    icon: ShieldCheck,
    title: "قوانین آهنین",
    desc: "هیچ API ای حدس زده نمی‌شود؛ مستندات قبل از کد خوانده می‌شود و خروجی نیمه‌کاره ممنوع است.",
    color: "from-violet-500 to-purple-700",
  },
  {
    icon: Gauge,
    title: "بودجه ۶۰ فریم",
    desc: "dpr محدود، ذرات تطبیقی و توقف خودکار صحنه‌های خارج از دید؛ GPU فقط وقتی کار می‌کند که ببینی.",
    color: "from-cyan-400 to-sky-600",
  },
  {
    icon: Smartphone,
    title: "موبایل‌فرست واقعی",
    desc: "طراحی از ۳۲۰ پیکسل شروع می‌شود، نه تمام. تراکم چندضلعی و ذرات روی موبایل خودکار کم می‌شوند.",
    color: "from-fuchsia-500 to-pink-600",
  },
  {
    icon: Bug,
    title: "ضد باگ ساختاریافته",
    desc: "ErrorBoundary دور هر Canvas، dispose کامل، cleanup تمام listener ها و کنسول کاملاً تمیز.",
    color: "from-emerald-400 to-teal-600",
  },
  {
    icon: MousePointerClick,
    title: "انیمیشن زنده",
    desc: "حرکت با damp و delta-time؛ هیچ حرکت خطی خشکی. صحنه ثابت یعنی صحنه مرده.",
    color: "from-amber-400 to-orange-600",
  },
  {
    icon: ArrowDownWideNarrow,
    title: "اسکرول سینمایی",
    desc: "Lenis با lerp دقیق، پارالاکس چندلایه و reveal های یک‌بارمصرف با easing سینمایی.",
    color: "from-indigo-400 to-blue-600",
  },
  {
    icon: Type,
    title: "تایپوگرافی فارسی",
    desc: "وزیرمتن با ۹ وزن، اندازه‌های سیال با clamp و RTL کامل؛ کدها و اعداد با JetBrains Mono.",
    color: "from-rose-400 to-red-600",
  },
  {
    icon: Accessibility,
    title: "برای همه",
    desc: "کنتراست AA، دسترسی کیبورد و احترام جدی به prefers-reduced-motion؛ خفن بودن به پای خوانایی لگد نمی‌زند.",
    color: "from-lime-400 to-green-600",
  },
];

export default function Pillars() {
  return (
    <section id="pillars" className="relative mx-auto max-w-7xl scroll-mt-24 px-4 py-24 md:px-8 md:py-32">
      <SectionHeading
        kicker="ستون‌های فرمول"
        title={
          <>
            ۸ ستونی که <span className="text-grad">بی‌نقص بودن</span> را تضمین می‌کنند
          </>
        }
        desc="این‌ها اصولی هستند که هیچ‌وقت قربانی نمی‌شوند. اگر بین زیبایی و یکی از این‌ها تعارض افتاد، این ستون‌ها برنده‌اند."
      />

      <div className="mt-14 grid gap-4 sm:grid-cols-2 lg:grid-cols-4 md:gap-5">
        {PILLARS.map((p, i) => (
          <Reveal key={p.title} delay={Math.min(i * 0.06, 0.4)} className="h-full">
            <motion.div
              whileHover={{ y: -8, transition: { duration: 0.35 } }}
              className="glass grad-ring group relative h-full overflow-hidden rounded-3xl p-6"
            >
              <div
                className={`pointer-events-none absolute -right-10 -top-10 h-28 w-28 rounded-full bg-gradient-to-br ${p.color} opacity-0 blur-[60px] transition-opacity duration-500 group-hover:opacity-30`}
              />
              <div
                className={`relative grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br ${p.color} text-white shadow-lg transition-transform duration-500 group-hover:-rotate-6 group-hover:scale-110`}
              >
                <p.icon size={22} strokeWidth={2.1} />
              </div>
              <h3 className="relative mt-5 text-base font-black md:text-lg">{p.title}</h3>
              <p className="relative mt-2.5 text-[13px] leading-7 text-muted">{p.desc}</p>
            </motion.div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
