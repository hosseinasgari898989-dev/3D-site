import type { ReactNode } from "react";
import { Reveal } from "./Reveal";

interface SectionHeadingProps {
  kicker: string;
  title: ReactNode;
  desc?: ReactNode;
  align?: "center" | "start";
}

export function SectionHeading({ kicker, title, desc, align = "center" }: SectionHeadingProps) {
  const alignCls = align === "center" ? "items-center text-center" : "items-start text-right";
  return (
    <div className={`flex flex-col gap-4 ${alignCls}`}>
      <Reveal>
        <span className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-1.5 text-xs font-semibold tracking-wide text-neon-soft">
          <span className="h-1.5 w-1.5 rounded-full bg-gradient-to-r from-neon to-cyanic shadow-[0_0_10px_2px_rgba(139,92,246,0.7)]" />
          {kicker}
        </span>
      </Reveal>
      <Reveal delay={0.08}>
        <h2 className="max-w-3xl text-[clamp(1.9rem,4.5vw,3.2rem)] font-black leading-[1.15]">
          {title}
        </h2>
      </Reveal>
      {desc && (
        <Reveal delay={0.16}>
          <p className="max-w-2xl text-base leading-8 text-muted md:text-lg">{desc}</p>
        </Reveal>
      )}
    </div>
  );
}
