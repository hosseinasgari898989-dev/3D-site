import {
  ArrowDownUp,
  Atom,
  Box,
  Feather,
  FileCode2,
  Orbit,
  Package,
  Wand2,
  Wind,
  Zap,
} from "lucide-react";
import { SectionHeading } from "./SectionHeading";
import { Reveal } from "./Reveal";

const STACK = [
  { icon: Atom, name: "React 19", desc: "رابط کاربری کامپوننتی با Concurrent Rendering" },
  { icon: FileCode2, name: "TypeScript", desc: "strict mode — نوع any در هر جای کد ممنوع" },
  { icon: Zap, name: "Vite", desc: "بیلد برق‌آسا و HMR فوری در حین توسعه" },
  { icon: Wind, name: "Tailwind v4", desc: "توکن‌های design در @theme؛ بدون فایل CSS شلخته" },
  { icon: Box, name: "three.js", desc: "موتور رندر WebGL زیر همه صحنه‌ها" },
  { icon: Orbit, name: "React Three Fiber", desc: "پل idiomatیک React و سه‌بُعدی" },
  { icon: Package, name: "drei", desc: "ابزارهای آماده: Float، Stars، OrbitControls و…" },
  { icon: Wand2, name: "framer-motion", desc: "reveal، ژست و انیمیشن layout برای DOM" },
  { icon: ArrowDownUp, name: "Lenis", desc: "اسکرول نرم با lerp 0.1 — کره‌ای روی یخ" },
  { icon: Feather, name: "lucide-react", desc: "آیکون‌های خطی؛ جایگزین همیشگی ایموجی" },
];

export default function Stack() {
  return (
    <section id="stack" className="relative mx-auto max-w-7xl scroll-mt-24 px-4 py-24 md:px-8 md:py-32">
      <SectionHeading
        kicker="ابزار جنگ"
        title={
          <>
            استکی که <span className="text-grad">همیشه جواب می‌دهد</span>
          </>
        }
        desc="همه با آخرین نسخه پایدارِ سازگار. نکته حیاتی: React 18 با fiber 8 + drei 9 و React 19 با fiber 9 + drei 10 جفت می‌شوند — قاطی‌شان نکن."
      />

      <div className="mt-14 grid grid-cols-2 gap-3 sm:grid-cols-3 md:gap-4 lg:grid-cols-5">
        {STACK.map((s, i) => (
          <Reveal key={s.name} delay={Math.min(i * 0.05, 0.35)} className="h-full">
            <div className="glass group flex h-full flex-col items-center gap-3 rounded-3xl p-5 text-center transition-all duration-300 hover:border-cyanic/40 hover:bg-white/[0.06]">
              <div className="grid h-11 w-11 place-items-center rounded-xl border border-white/10 bg-white/5 text-neon-soft transition-all duration-300 group-hover:border-neon/40 group-hover:text-cyanic">
                <s.icon size={20} strokeWidth={2} />
              </div>
              <div>
                <div className="font-mono text-sm font-extrabold text-ink" dir="ltr">
                  {s.name}
                </div>
                <p className="mt-2 text-[11px] leading-6 text-muted">{s.desc}</p>
              </div>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
