import { Canvas, useFrame } from "@react-three/fiber";
import {
  Float,
  MeshWobbleMaterial,
  OrbitControls,
  RoundedBox,
  Sparkles,
} from "@react-three/drei";
import * as THREE from "three";
import { useRef, type ReactElement } from "react";
import { useIsMobile } from "../../hooks/useInView";
import { ErrorBoundary } from "../ErrorBoundary";

/* ---------- زیرساخت مشترک دموها: dpr محدود + نور رنگی ---------- */
function DemoLights() {
  return (
    <>
      <ambientLight intensity={0.4} />
      <pointLight position={[5, 5, 5]} intensity={40} distance={26} color="#8b5cf6" />
      <pointLight position={[-5, -2, 4]} intensity={30} distance={26} color="#22d3ee" />
    </>
  );
}

function makeDemoCanvas(
  // eslint-disable-next-line react-refresh/only-export-components
  Scene: (props: { active: boolean; mobile: boolean }) => ReactElement,
  cameraZ = 5
) {
  return function Demo({ active }: { active: boolean }) {
    const mobile = useIsMobile();
    return (
      <ErrorBoundary>
        <Canvas
          frameloop={active ? "always" : "never"}
          dpr={[1, mobile ? 1.5 : 1.75]}
          camera={{ position: [0, 0, cameraZ], fov: 45 }}
          gl={{ antialias: true, alpha: true, powerPreference: "high-performance" }}
          style={{ position: "absolute", inset: 0 }}
        >
          <DemoLights />
          <Scene active={active} mobile={mobile} />
        </Canvas>
      </ErrorBoundary>
    );
  };
}

/* ---------- دمو ۱: گره چرخان (درگ برای چرخش) ---------- */
function KnotBody({ mobile }: { mobile: boolean }) {
  const g = useRef<THREE.Group>(null);
  useFrame((_, dt) => {
    if (g.current) g.current.rotation.z += dt * 0.15;
  });
  return (
    <group ref={g}>
      <mesh>
        <torusKnotGeometry args={[1.02, 0.3, mobile ? 110 : 220, mobile ? 14 : 28]} />
        <meshStandardMaterial
          color="#22d3ee"
          emissive="#0e7490"
          emissiveIntensity={0.55}
          metalness={0.7}
          roughness={0.3}
          wireframe
        />
      </mesh>
      <mesh scale={0.985}>
        <torusKnotGeometry args={[1.02, 0.29, mobile ? 90 : 180, mobile ? 12 : 24]} />
        <meshStandardMaterial color="#07070f" metalness={0.9} roughness={0.35} />
      </mesh>
    </group>
  );
}

export const KnotDemo = makeDemoCanvas(({ mobile }) => (
  <>
    <KnotBody mobile={mobile} />
    <OrbitControls
      autoRotate
      autoRotateSpeed={1.4}
      enableZoom={false}
      enablePan={false}
      enableDamping
      dampingFactor={0.08}
    />
  </>
));

/* ---------- دمو ۲: ژله تعاملی (کلیک کنید) ---------- */
function JellyBody({ mobile }: { mobile: boolean }) {
  const mesh = useRef<THREE.Mesh>(null);
  const target = useRef(1);
  useFrame((state, dt) => {
    const m = mesh.current;
    if (!m) return;
    m.rotation.y += dt * 0.4;
    target.current = THREE.MathUtils.damp(target.current, 1, 3.2, dt);
    const s = THREE.MathUtils.damp(m.scale.x, target.current, 7, dt);
    m.scale.setScalar(s);
    m.position.y = Math.sin(state.clock.elapsedTime * 1.2) * 0.12;
  });
  return (
    <mesh
      ref={mesh}
      onPointerDown={() => {
        target.current = 1.45;
      }}
    >
      <sphereGeometry args={[1.15, mobile ? 40 : 72, mobile ? 40 : 72]} />
      <MeshWobbleMaterial
        factor={0.55}
        color="#8b5cf6"
        emissive="#312e81"
        emissiveIntensity={0.45}
        metalness={0.35}
        roughness={0.2}
        speed={2.2}
      />
    </mesh>
  );
}

export const JellyDemo = makeDemoCanvas(({ mobile }) => <JellyBody mobile={mobile} />);

/* ---------- دمو ۳: مکعب هولوگرافیک ---------- */
function HoloBody() {
  const g = useRef<THREE.Group>(null);
  useFrame((state, dt) => {
    const grp = g.current;
    if (!grp) return;
    grp.rotation.y += dt * 0.55;
    grp.rotation.x = Math.sin(state.clock.elapsedTime * 0.4) * 0.22;
  });
  return (
    <Float speed={2.2} rotationIntensity={0.5} floatIntensity={1.2}>
      <group ref={g}>
        <RoundedBox args={[1.75, 1.75, 1.75]} radius={0.16} smoothness={4}>
          <meshBasicMaterial color="#22d3ee" transparent opacity={0.4} wireframe />
        </RoundedBox>
        <RoundedBox args={[1.02, 1.02, 1.02]} radius={0.12} smoothness={4}>
          <meshStandardMaterial
            color="#7c3aed"
            emissive="#8b5cf6"
            emissiveIntensity={0.9}
            metalness={0.6}
            roughness={0.2}
          />
        </RoundedBox>
      </group>
    </Float>
  );
}

export const HoloDemo = makeDemoCanvas(
  ({ mobile }) => (
    <>
      <HoloBody />
      <Sparkles count={mobile ? 30 : 70} scale={4.5} size={2} speed={0.5} color="#22d3ee" opacity={0.8} />
    </>
  ),
  5.5
);
