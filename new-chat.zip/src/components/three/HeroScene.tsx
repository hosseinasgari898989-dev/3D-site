import { Canvas, useFrame } from "@react-three/fiber";
import { Float, MeshDistortMaterial, Sparkles, Stars } from "@react-three/drei";
import * as THREE from "three";
import { useEffect, useRef, type ReactNode } from "react";
import { useIsMobile } from "../../hooks/useInView";

/* ----------------------------------------------------------
 * پارالاکس ماوس از سطح window گرفته می‌شود تا overlay ها
 * هرگز جلوی تعقیب نشانگر توسط صحنه را نگیرند.
 * ---------------------------------------------------------- */
const pointer = { x: 0, y: 0 };

function usePointerTracker(active: boolean) {
  useEffect(() => {
    if (!active) return;
    const onMove = (e: PointerEvent) => {
      pointer.x = (e.clientX / window.innerWidth) * 2 - 1;
      pointer.y = (e.clientY / window.innerHeight) * 2 - 1;
    };
    window.addEventListener("pointermove", onMove, { passive: true });
    return () => window.removeEventListener("pointermove", onMove);
  }, [active]);
}

/** دوربین نرم: چرخش خودکار آرام + تعقیب damped ماوس */
function Rig({ children }: { children: ReactNode }) {
  const ref = useRef<THREE.Group>(null);
  const auto = useRef(0);
  useFrame((_, dt) => {
    const g = ref.current;
    if (!g) return;
    auto.current += dt * 0.045;
    g.rotation.y = THREE.MathUtils.damp(g.rotation.y, auto.current + pointer.x * 0.42, 2.2, dt);
    g.rotation.x = THREE.MathUtils.damp(g.rotation.x, pointer.y * 0.26, 2.2, dt);
  });
  return <group ref={ref}>{children}</group>;
}

/** هسته مرکزی — ایکوزاهدرون مذاب با متریال فلزی */
function Core({ mobile }: { mobile: boolean }) {
  const mesh = useRef<THREE.Mesh>(null);
  useFrame((_, dt) => {
    if (!mesh.current) return;
    mesh.current.rotation.y += dt * 0.12;
    mesh.current.rotation.z += dt * 0.06;
  });
  return (
    <Float speed={1.4} rotationIntensity={0.35} floatIntensity={0.9}>
      <mesh ref={mesh}>
        <icosahedronGeometry args={[1.55, mobile ? 12 : 24]} />
        <MeshDistortMaterial
          color="#7c3aed"
          emissive="#2e1065"
          emissiveIntensity={0.45}
          metalness={0.55}
          roughness={0.22}
          distort={mobile ? 0.32 : 0.4}
          speed={1.8}
        />
      </mesh>
    </Float>
  );
}

/** حلقه‌های مداری سینمایی */
function Rings() {
  const a = useRef<THREE.Mesh>(null);
  const b = useRef<THREE.Mesh>(null);
  useFrame((state, dt) => {
    const t = state.clock.elapsedTime;
    if (a.current) {
      a.current.rotation.z += dt * 0.18;
      a.current.rotation.x = Math.PI / 2.15 + Math.sin(t * 0.3) * 0.08;
    }
    if (b.current) {
      b.current.rotation.z -= dt * 0.12;
      b.current.rotation.x = Math.PI / 1.85 + Math.cos(t * 0.22) * 0.07;
    }
  });
  return (
    <group>
      <mesh ref={a} rotation={[Math.PI / 2.15, 0.3, 0]}>
        <torusGeometry args={[2.7, 0.012, 8, 160]} />
        <meshBasicMaterial color="#22d3ee" transparent opacity={0.55} />
      </mesh>
      <mesh ref={b} rotation={[Math.PI / 1.85, -0.4, 0.4]}>
        <torusGeometry args={[3.35, 0.008, 8, 160]} />
        <meshBasicMaterial color="#a78bfa" transparent opacity={0.38} />
      </mesh>
    </group>
  );
}

/** قمرهای شناور روی مدارهای مختلف */
function Satellite({
  radius,
  speed,
  offset,
  color,
  size,
  yAmp = 0.6,
}: {
  radius: number;
  speed: number;
  offset: number;
  color: string;
  size: number;
  yAmp?: number;
}) {
  const ref = useRef<THREE.Mesh>(null);
  useFrame((state) => {
    const m = ref.current;
    if (!m) return;
    const t = state.clock.elapsedTime * speed + offset;
    m.position.set(Math.cos(t) * radius, Math.sin(t * 1.4) * yAmp, Math.sin(t) * radius);
    m.rotation.x = t * 0.8;
    m.rotation.y = t * 0.6;
  });
  return (
    <mesh ref={ref}>
      <octahedronGeometry args={[size, 0]} />
      <meshStandardMaterial
        color={color}
        emissive={color}
        emissiveIntensity={0.8}
        roughness={0.25}
        metalness={0.4}
      />
    </mesh>
  );
}

export default function HeroScene({ active }: { active: boolean }) {
  const mobile = useIsMobile();
  usePointerTracker(active);

  return (
    <Canvas
      frameloop={active ? "always" : "never"}
      dpr={[1, mobile ? 1.5 : 1.75]}
      camera={{ position: [0, 0.3, 9], fov: 45 }}
      gl={{ antialias: true, alpha: true, powerPreference: "high-performance" }}
      style={{ position: "absolute", inset: 0 }}
    >
      <fog attach="fog" args={["#05050d", 11, 26]} />
      <ambientLight intensity={0.35} />
      <pointLight position={[6, 4, 6]} intensity={55} distance={30} color="#8b5cf6" />
      <pointLight position={[-6, -3, -4]} intensity={45} distance={28} color="#22d3ee" />
      <pointLight position={[0, 6, -8]} intensity={30} distance={30} color="#f472b6" />

      <Rig>
        <Core mobile={mobile} />
        <Rings />
        <Satellite radius={3.1} speed={0.5} offset={0} color="#22d3ee" size={0.09} />
        <Satellite radius={3.1} speed={0.5} offset={Math.PI} color="#f472b6" size={0.07} />
        <Satellite radius={3.7} speed={-0.35} offset={1.2} color="#a78bfa" size={0.12} />
        <Satellite radius={2.2} speed={0.8} offset={2.4} color="#e879f9" size={0.06} yAmp={0.9} />
      </Rig>

      <Stars
        radius={70}
        depth={40}
        count={mobile ? 1400 : 4200}
        factor={3.6}
        saturation={0.5}
        fade
        speed={0.6}
      />
      <Sparkles
        count={mobile ? 50 : 120}
        scale={[11, 7, 11]}
        size={2.4}
        speed={0.35}
        color="#a78bfa"
        opacity={0.7}
      />
    </Canvas>
  );
}
