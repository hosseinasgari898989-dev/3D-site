import Lenis from "lenis";

let lenis: Lenis | null = null;
let rafId = 0;

export function initLenis(): Lenis {
  if (lenis) return lenis;
  const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  lenis = new Lenis({
    lerp: 0.1,
    smoothWheel: !reduced,
    wheelMultiplier: 1,
    touchMultiplier: 1.4,
  });

  const raf = (time: number) => {
    if (lenis) lenis.raf(time);
    rafId = requestAnimationFrame(raf);
  };
  rafId = requestAnimationFrame(raf);
  return lenis;
}

export function destroyLenis() {
  cancelAnimationFrame(rafId);
  if (lenis) {
    lenis.destroy();
    lenis = null;
  }
}

export function scrollToId(id: string) {
  const target = document.getElementById(id);
  if (!target) return;
  if (lenis) {
    lenis.scrollTo(target, { offset: -72, duration: 1.5 });
  } else {
    target.scrollIntoView({ behavior: "smooth", block: "start" });
  }
}
